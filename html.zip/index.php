<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'includes/config.php';
require_once 'includes/functions.php';

echo "<!-- Session ID: " . session_id() . " -->";
echo "<!-- User ID: " . ($_SESSION['user_id'] ?? 'none') . " -->";

?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ArtFolio - Portfolio Nghệ Thuật</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
</head>
<body>
    <div id="loading">
        <div class="spinner"></div>
    </div>
    <?php include 'includes/header.php'; ?>
    
  <main>
            <?php include 'sections/blog.php'; ?>
            <?php include 'sections/gallery.php'; ?>
            <?php include 'sections/home.php'; ?>
            <?php include 'sections/contact.php'; ?>
            <?php include 'sections/chat.php'; ?>
  </main>

            <?php include 'includes/modals.php'; ?>         
            <?php include 'includes/footer.php'; ?>
    <button class="back-to-top" id="backToTop" aria-label="Back to top">
         <i class="fas fa-chevron-up"></i>
    </button>    
         <!-- Upload Button (chỉ hiện khi đã login) -->
    <?php if (isset($_SESSION['user_id'])): ?>
    <button class="upload-float-btn" id="uploadFloatBtn" aria-label="Upload artwork">
        <span style="font-size: 32px; line-height: 0;">+</span>
    </button>
    <?php endif; ?>

    <!-- Upload Modal -->
    <div class="modal" id="uploadModal">
        <div class="modal-content">
            <span class="close" id="closeUpload">&times;</span>
            <h2>📤 Upload Tác Phẩm Mới</h2>
            
            <div class="upload-tabs">
                <button class="tab-btn active" data-tab="url">URL Hình Ảnh</button>
                <button class="tab-btn" data-tab="file">Upload File</button>
            </div>
            
            <form id="uploadFormHome" enctype="multipart/form-data">
                <!-- Tab 1: URL -->
                <div class="tab-content active" data-tab-content="url">
                    <div class="form-group">
                        <label for="upload_image_url">URL Hình Ảnh *</label>
                        <input type="url" id="upload_image_url" placeholder="https://example.com/image.jpg">
                        <small style="color: #666;">Nhập URL của hình ảnh từ internet</small>
                    </div>
                </div>
                
                <!-- Tab 2: Upload File -->
                <div class="tab-content" data-tab-content="file">
                    <div class="form-group">
                        <label for="upload_image_file">Chọn Ảnh Từ Thiết Bị *</label>
                        <div class="file-upload-area" id="fileUploadArea">
                            <input type="file" id="upload_image_file" accept="image/*" style="display: none;">
                            <div class="file-upload-placeholder">
                                <span style="font-size: 48px;">📷</span>
                                <p>Click để chọn ảnh hoặc kéo thả vào đây</p>
                                <small>JPG, PNG, GIF (Max 5MB)</small>
                            </div>
                            <div class="file-preview" id="filePreview" style="display: none;">
                                <img id="previewImage" alt="Preview">
                                <button type="button" class="remove-preview" id="removePreview">✕</button>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Common fields -->
                <div class="form-group">
                    <label for="upload_title">Tiêu Đề *</label>
                    <input type="text" id="upload_title" required>
                </div>
                
                <div class="form-group">
                    <label for="upload_description">Mô Tả</label>
                    <textarea id="upload_description" rows="3"></textarea>
                </div>
                
                <div class="form-group">
                    <label for="upload_category">Danh Mục *</label>
                    <select id="upload_category" required>
                        <option value="">-- Chọn danh mục --</option>
                        <option value="painting">Tranh Sơn Dầu</option>
                        <option value="digital">Nghệ Thuật Số</option>
                        <option value="photography">Nhiếp Ảnh</option>
                        <option value="sculpture">Điêu Khắc</option>
                    </select>
                </div>
                
                <button type="submit" class="submit-btn">Upload Tác Phẩm</button>
            </form>
        </div>
    </div>

    <!-- User Data for JavaScript -->
    <script>
        window.userData = <?php 
            if (isset($_SESSION['user_id']) && !empty($_SESSION['user_id'])) {
                echo json_encode([
                    'id' => $_SESSION['user_id'],
                    'username' => $_SESSION['username'] ?? '',
                    'email' => $_SESSION['user_email'] ?? '',
                    'role' => $_SESSION['user_role'] ?? 'user'
                ], JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP);
            } else {
                echo 'null';
            }
        ?>;
        
        console.log('User data loaded:', window.userData);
    </script>
</body>
</html>