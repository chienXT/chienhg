-- Tạo database
CREATE DATABASE IF NOT EXISTS `3843044_chienhg` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE `3843044_chienhg`;

-- Tạo database
CREATE DATABASE artfolio_db;
USE artfolio_db;

-- Bảng users
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('user', 'admin') DEFAULT 'user',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Bảng contacts
CREATE TABLE contacts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    message TEXT NOT NULL,
    status ENUM('pending', 'read', 'replied') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Bảng gallery
CREATE TABLE gallery (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    description TEXT,
    image_url VARCHAR(500),
    category VARCHAR(50) NOT NULL,
    tags TEXT,
    featured BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Chèn dữ liệu mẫu
INSERT INTO users (username, email, password, role) VALUES 
('admin', 'admin@artfolio.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin');

INSERT INTO gallery (title, description, image_url, category, tags, featured) VALUES 
('Tranh Sơn Dầu Phong Cảnh', 'Tác phẩm sơn dầu mô tả phong cảnh thiên nhiên tươi đẹp', 'images/painting1.jpg', 'painting', 'landscape,nature', TRUE),
('Nghệ Thuật Số Hiện Đại', 'Tác phẩm digital art với phong cách hiện đại', 'images/digital1.jpg', 'digital', 'modern,abstract', TRUE),
('Nhiếp Ảnh Đường Phố', 'Bộ ảnh chân thực về cuộc sống đường phố', 'images/photo1.jpg', 'photography', 'street,urban', FALSE),
('Tượng Điêu Khắc Gỗ', 'Tác phẩm điêu khắc từ gỗ tự nhiên', 'images/sculpture1.jpg', 'sculpture', 'wood,handmade', TRUE);

-- Tạo indexes để tối ưu hiệu suất
CREATE INDEX idx_posts_status ON posts(status);
CREATE INDEX idx_posts_category ON posts(category);
CREATE INDEX idx_posts_created_at ON posts(created_at);
CREATE INDEX idx_users_username ON users(username);