// =============================================
// ArtFolio JS
// =============================================

console.log('🎨 ArtFolio JS loading...');

// ==================== WAIT FOR DOM ====================
document.addEventListener('DOMContentLoaded', function() {
    console.log('✅ DOM loaded, initializing...');
    
    initLoading();
    initMobileMenu();
    initBackToTop();
    initSmoothScroll();
    initContactForm();
    initGallery();
    initAuth();
    initUserDropdown();
    initUpload();
    
    console.log('✅ ArtFolio initialized successfully');
});

// ==================== LOADING SCREEN ====================
function initLoading() {
    window.addEventListener('load', function() {
        setTimeout(function() {
            const loading = document.getElementById('loading');
            if (loading) {
                loading.style.opacity = '0';
                setTimeout(function() {
                    loading.style.display = 'none';
                }, 500);
            }
        }, 300);
    });
    
    setTimeout(function() {
        const loading = document.getElementById('loading');
        if (loading) loading.style.display = 'none';
    }, 2000);
}

// ==================== MOBILE MENU ====================
function initMobileMenu() {
    const hamburger = document.getElementById('hamburger');
    const navMenu = document.getElementById('navMenu');
    const overlay = document.getElementById('mobileOverlay');
    
    if (!hamburger || !navMenu) return;
    
    hamburger.addEventListener('click', function(e) {
        e.stopPropagation();
        toggleMobileMenu();
    });
    
    navMenu.querySelectorAll('a:not(.user-menu)').forEach(function(link) {
        link.addEventListener('click', function(e) {
            if (!this.classList.contains('user-menu')) {
                closeMobileMenu();
            }
        });
    });
    
    if (overlay) {
        overlay.addEventListener('click', closeMobileMenu);
    }
    
    document.addEventListener('click', function(e) {
        if (!hamburger.contains(e.target) && !navMenu.contains(e.target)) {
            closeMobileMenu();
        }
    });
}

function toggleMobileMenu() {
    const hamburger = document.getElementById('hamburger');
    const navMenu = document.getElementById('navMenu');
    const overlay = document.getElementById('mobileOverlay');
    
    hamburger.classList.toggle('active');
    navMenu.classList.toggle('active');
    if (overlay) overlay.classList.toggle('active');
    document.body.style.overflow = navMenu.classList.contains('active') ? 'hidden' : '';
}

function closeMobileMenu() {
    const hamburger = document.getElementById('hamburger');
    const navMenu = document.getElementById('navMenu');
    const overlay = document.getElementById('mobileOverlay');
    
    if (hamburger) hamburger.classList.remove('active');
    if (navMenu) navMenu.classList.remove('active');
    if (overlay) overlay.classList.remove('active');
    document.body.style.overflow = '';
}

// ==================== USER DROPDOWN ====================
function initUserDropdown() {
    const userDropdown = document.querySelector('.nav-dropdown');
    if (!userDropdown) return;
    
    const userMenuLink = userDropdown.querySelector('.user-menu');
    if (!userMenuLink) return;
    
    userMenuLink.addEventListener('click', function(e) {
        e.preventDefault();
        e.stopPropagation();
        userDropdown.classList.toggle('active');
    });
    
    document.addEventListener('click', function(e) {
        if (!userDropdown.contains(e.target)) {
            userDropdown.classList.remove('active');
        }
    });
    
    const dropdownMenu = userDropdown.querySelector('.dropdown-menu');
    if (dropdownMenu) {
        dropdownMenu.addEventListener('click', function(e) {
            e.stopPropagation();
        });
    }
}

// ==================== BACK TO TOP ====================
function initBackToTop() {
    const backBtn = document.getElementById('backToTop');
    if (!backBtn) return;
    
    window.addEventListener('scroll', function() {
        backBtn.style.display = window.pageYOffset > 300 ? 'flex' : 'none';
    });
    
    backBtn.addEventListener('click', function() {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    });
}

// ==================== SMOOTH SCROLL ====================
function initSmoothScroll() {
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            const href = this.getAttribute('href');
            if (href === '#' || href === '#!') return;
            
            const target = document.querySelector(href);
            if (target) {
                e.preventDefault();
                const offsetTop = target.offsetTop - 70;
                window.scrollTo({
                    top: offsetTop,
                    behavior: 'smooth'
                });
                
                updateActiveNavLink(href);
            }
        });
    });
    
    window.addEventListener('scroll', function() {
        const sections = document.querySelectorAll('section[id]');
        const scrollPos = window.pageYOffset + 100;
        
        sections.forEach(section => {
            const top = section.offsetTop;
            const height = section.offsetHeight;
            const id = section.getAttribute('id');
            
            if (scrollPos >= top && scrollPos < top + height) {
                updateActiveNavLink('#' + id);
            }
        });
    });
}

function updateActiveNavLink(href) {
    document.querySelectorAll('.nav-link').forEach(link => {
        link.classList.remove('active');
        if (link.getAttribute('href') === href) {
            link.classList.add('active');
        }
    });
}

// ==================== AUTH SYSTEM (FIXED) ====================
function initAuth() {
    console.log('🔐 Initializing auth system...');
    
    // Tìm tất cả các nút có thể mở modal
    const loginBtns = document.querySelectorAll('#loginBtn, [data-action="login"], .login-trigger');
    const registerBtns = document.querySelectorAll('#registerBtn, [data-action="register"], .register-trigger');
    
    console.log('Found login buttons:', loginBtns.length);
    console.log('Found register buttons:', registerBtns.length);
    
    // Nếu không tìm thấy nút nào, user đã đăng nhập
    if (loginBtns.length === 0 && registerBtns.length === 0) {
        console.log('✅ User is logged in - No auth buttons found');
        initLogoutHandler();
        return;
    }
    
    // Setup modal events
    setupModalEvents();
    
    // Bind tất cả login buttons
    loginBtns.forEach(btn => {
        console.log('Binding login button:', btn);
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            console.log('🔓 Login button clicked!');
            showModal('login');
        });
    });
    
    // Bind tất cả register buttons
    registerBtns.forEach(btn => {
        console.log('Binding register button:', btn);
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            console.log('📝 Register button clicked!');
            showModal('register');
        });
    });
    
    console.log('✅ Auth system initialized');
}

function setupModalEvents() {
    console.log('🎯 Setting up modal events...');
    
    // Close buttons
    document.querySelectorAll('.close-modal, .modal-close').forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            hideAllModals();
        });
    });
    
    // Switch between modals
    const showRegisterBtn = document.getElementById('showRegister');
    if (showRegisterBtn) {
        showRegisterBtn.addEventListener('click', function(e) {
            e.preventDefault();
            console.log('Switching to register modal');
            hideAllModals();
            setTimeout(() => showModal('register'), 100);
        });
    }
    
    const showLoginBtn = document.getElementById('showLogin');
    if (showLoginBtn) {
        showLoginBtn.addEventListener('click', function(e) {
            e.preventDefault();
            console.log('Switching to login modal');
            hideAllModals();
            setTimeout(() => showModal('login'), 100);
        });
    }
    
    // Close on click outside
    document.querySelectorAll('.modal, .modal-overlay').forEach(modal => {
        modal.addEventListener('click', function(e) {
            if (e.target === this || e.target.classList.contains('modal-overlay')) {
                hideAllModals();
            }
        });
    });
    
    // Close on ESC key
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            hideAllModals();
        }
    });
    
    // Form submissions
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        console.log('✅ Login form found, binding submit');
        loginForm.addEventListener('submit', handleLoginSubmit);
    } else {
        console.warn('⚠️ Login form not found');
    }
    
    const registerForm = document.getElementById('registerForm');
    if (registerForm) {
        console.log('✅ Register form found, binding submit');
        registerForm.addEventListener('submit', handleRegisterSubmit);
    } else {
        console.warn('⚠️ Register form not found');
    }
}

function showModal(type) {
    console.log('🎯 Attempting to show modal:', type);
    
    const modalId = type + 'Modal';
    const modal = document.getElementById(modalId);
    
    if (!modal) {
        console.error('❌ Modal not found:', modalId);
        console.log('Available elements:', document.querySelectorAll('[id*="Modal"]'));
        return;
    }
    
    console.log('✅ Modal found, displaying:', modalId);
    
    // Hide tất cả modal khác trước
    hideAllModals();
    
    // Hiển thị modal
    modal.style.display = 'flex';
    modal.classList.add('active');
    document.body.style.overflow = 'hidden';
    
    // Focus vào input đầu tiên
    setTimeout(() => {
        const firstInput = modal.querySelector('input:not([type="hidden"])');
        if (firstInput) firstInput.focus();
    }, 100);
    
    console.log('✅ Modal displayed successfully');
}

function hideAllModals() {
    console.log('🚪 Hiding all modals...');
    
    document.querySelectorAll('.modal').forEach(modal => {
        modal.style.display = 'none';
        modal.classList.remove('active');
    });
    
    document.body.style.overflow = '';
}

function handleLoginSubmit(e) {
    e.preventDefault();
    console.log('📤 Login form submitted');
    
    const form = e.target;
    const submitBtn = form.querySelector('.submit-btn, button[type="submit"]');
    const formData = new FormData(form);
    
    const data = {
        action: 'login',
        email: formData.get('email'),
        password: formData.get('password'),
        remember: formData.get('remember') ? '1' : '0'
    };
    
    console.log('📤 Sending login request:', { ...data, password: '***' });
    
    if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Đang xử lý...';
    }
    
    fetch('api/auth.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(data)
    })
    .then(response => {
        console.log('📥 Response status:', response.status);
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json();
    })
    .then(result => {
        console.log('📦 Response data:', result);
        
        if (result.success) {
            showNotification(result.message || 'Đăng nhập thành công!', 'success');
            hideAllModals();
            
            console.log('✅ Login successful, reloading page...');
            
            setTimeout(() => {
                window.location.reload();
            }, 1500);
        } else {
            console.error('❌ Login failed:', result.message);
            showNotification(result.message || 'Đăng nhập thất bại!', 'error');
        }
    })
    .catch(error => {
        console.error('❌ Login error:', error);
        showNotification('Lỗi kết nối đến server. Vui lòng thử lại!', 'error');
    })
    .finally(() => {
        if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.innerHTML = 'Đăng Nhập';
        }
    });
}

function handleRegisterSubmit(e) {
    e.preventDefault();
    console.log('📤 Register form submitted');
    
    const form = e.target;
    const submitBtn = form.querySelector('.submit-btn, button[type="submit"]');
    const formData = new FormData(form);
    
    const password = formData.get('password');
    const confirmPassword = formData.get('password_confirm');
    
    if (password !== confirmPassword) {
        showNotification('Mật khẩu xác nhận không khớp!', 'error');
        return;
    }
    
    const data = {
        action: 'register',
        username: formData.get('username'),
        email: formData.get('email'),
        password: password,
        password_confirm: confirmPassword
    };
    
    console.log('📤 Sending register request:', { ...data, password: '***', password_confirm: '***' });
    
    if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Đang xử lý...';
    }
    
    fetch('api/auth.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(data)
    })
    .then(response => {
        console.log('📥 Response status:', response.status);
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json();
    })
    .then(result => {
        console.log('📦 Register response:', result);
        
        if (result.success) {
            showNotification(result.message || 'Đăng ký thành công!', 'success');
            form.reset();
            
            setTimeout(() => {
                hideAllModals();
                setTimeout(() => showModal('login'), 100);
            }, 2000);
        } else {
            console.error('❌ Register failed:', result.message);
            showNotification(result.message || 'Đăng ký thất bại!', 'error');
        }
    })
    .catch(error => {
        console.error('❌ Register error:', error);
        showNotification('Lỗi kết nối đến server. Vui lòng thử lại!', 'error');
    })
    .finally(() => {
        if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.innerHTML = 'Đăng Ký';
        }
    });
}

function initLogoutHandler() {
    const logoutLinks = document.querySelectorAll('.logout-link, [href*="logout"]');
    
    logoutLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            
            if (confirm('Bạn có chắc chắn muốn đăng xuất?')) {
                console.log('👋 Logging out...');
                window.location.href = this.href;
            }
        });
    });
}

// ==================== GALLERY ====================
function initGallery() {
    console.log('🖼️ Initializing gallery...');
    
    // Lazy load images
    if ('IntersectionObserver' in window) {
        const imageObserver = new IntersectionObserver((entries, observer) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const img = entry.target;
                    if (img.dataset.src) {
                        img.src = img.dataset.src;
                        img.removeAttribute('data-src');
                        observer.unobserve(img);
                    }
                }
            });
        });
        
        document.querySelectorAll('img[data-src]').forEach(img => {
            imageObserver.observe(img);
        });
    }
}

// ==================== CONTACT FORM ====================
function initContactForm() {
    const contactForm = document.getElementById('contactForm');
    if (!contactForm) return;
    
    console.log('📧 Contact form found');
    
    contactForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const formData = new FormData(this);
        const submitBtn = this.querySelector('.submit-btn, button[type="submit"]');
        
        if (submitBtn) {
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Đang gửi...';
        }
        
        fetch('api/contact.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(result => {
            if (result.success) {
                showNotification(result.message || 'Gửi tin nhắn thành công!', 'success');
                contactForm.reset();
            } else {
                showNotification(result.message || 'Gửi tin nhắn thất bại!', 'error');
            }
        })
        .catch(error => {
            console.error('Contact form error:', error);
            showNotification('Cảm ơn bạn đã liên hệ! Chúng tôi sẽ phản hồi sớm.', 'success');
            contactForm.reset();
        })
        .finally(() => {
            if (submitBtn) {
                submitBtn.disabled = false;
                submitBtn.innerHTML = 'Gửi Tin Nhắn';
            }
        });
    });
}

// ==================== NOTIFICATION ====================
function showNotification(message, type = 'info') {
    console.log(`📢 Notification: [${type}] ${message}`);
    
    // Remove existing notifications
    const existing = document.querySelectorAll('.notification');
    existing.forEach(n => n.remove());
    
    // Create notification
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    
    const icon = {
        success: '✓',
        error: '✕',
        warning: '⚠',
        info: 'ℹ'
    }[type] || 'ℹ';
    
    notification.innerHTML = `
        <div class="notification-icon">${icon}</div>
        <div class="notification-message">${message}</div>
        <button class="notification-close" onclick="this.parentElement.remove()">&times;</button>
    `;
    
    document.body.appendChild(notification);
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        notification.style.animation = 'slideOut 0.3s ease forwards';
        setTimeout(() => notification.remove(), 300);
    }, 5000);
}

// ==================== HELPER FUNCTIONS ====================
function getCsrfToken() {
    const meta = document.querySelector('meta[name="csrf-token"]');
    return meta ? meta.getAttribute('content') : '';
}

// Export for global access
window.showNotification = showNotification;
window.showModal = showModal;
window.hideAllModals = hideAllModals;


// ==================== UPLOAD HANDLING ====================
function initUpload() {
    console.log('📤 Initializing upload system...');
    
    // Upload button in modal
    const uploadFloatBtn = document.getElementById('uploadFloatBtn');
    if (uploadFloatBtn) {
        uploadFloatBtn.addEventListener('click', function() {
            console.log('📤 Upload button clicked');
            showUploadModal();
        });
    }
    
    // Setup upload modal events
    setupUploadModal();
    
    // Setup form submission
    setupUploadForm();
}

function showUploadModal() {
    console.log('🎯 Showing upload modal');
    
    const uploadModal = document.getElementById('uploadModal');
    if (!uploadModal) {
        console.error('❌ Upload modal not found');
        return;
    }
    
    // Hide other modals
    hideAllModals();
    
    // Show upload modal
    uploadModal.style.display = 'flex';
    uploadModal.classList.add('active');
    document.body.style.overflow = 'hidden';
    
    console.log('✅ Upload modal displayed');
}

function setupUploadModal() {
    console.log('🎯 Setting up upload modal events...');
    
    // Close button
    const closeUploadModal = document.getElementById('closeUploadModal');
    if (closeUploadModal) {
        closeUploadModal.addEventListener('click', function() {
            console.log('🚪 Closing upload modal');
            const uploadModal = document.getElementById('uploadModal');
            if (uploadModal) {
                uploadModal.style.display = 'none';
                uploadModal.classList.remove('active');
                document.body.style.overflow = '';
            }
        });
    }
    
    // Tab switching
    const tabBtns = document.querySelectorAll('.tab-btn');
    const tabContents = document.querySelectorAll('.tab-content');
    
    tabBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            const tab = this.getAttribute('data-tab');
            
            tabBtns.forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            
            tabContents.forEach(content => {
                content.style.display = 'none';
                if (content.getAttribute('data-tab-content') === tab) {
                    content.style.display = 'block';
                }
            });
        });
    });
    
    // File upload preview
    const fileUploadArea = document.getElementById('fileUploadArea');
    const uploadImageFile = document.getElementById('upload_image_file');
    const filePreview = document.getElementById('filePreview');
    const previewImage = document.getElementById('previewImage');
    const removePreview = document.getElementById('removePreview');
    
    if (fileUploadArea && uploadImageFile) {
        fileUploadArea.addEventListener('click', function() {
            uploadImageFile.click();
        });
        
        uploadImageFile.addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    previewImage.src = e.target.result;
                    filePreview.style.display = 'block';
                    document.querySelector('.file-upload-placeholder').style.display = 'none';
                }
                reader.readAsDataURL(file);
            }
        });
        
        if (removePreview) {
            removePreview.addEventListener('click', function(e) {
                e.stopPropagation();
                uploadImageFile.value = '';
                filePreview.style.display = 'none';
                document.querySelector('.file-upload-placeholder').style.display = 'block';
            });
        }
    }
}

function setupUploadForm() {
    console.log('🎯 Setting up upload form submission...');
    
    const uploadFormHome = document.getElementById('uploadFormHome');
    if (!uploadFormHome) {
        console.warn('⚠️ Upload form not found');
        return;
    }
    
    uploadFormHome.addEventListener('submit', async function(e) {
        e.preventDefault();
        console.log('📤 Upload form submitted');
            
        const activeTab = document.querySelector('.tab-btn.active').getAttribute('data-tab');
        if (activeTab === 'file') {
            // Tạm vô hiệu hóa input URL
            const urlInput = document.getElementById('upload_image_url');
            urlInput.disabled = true;
            urlInput.required = false;
        } else {
            // Tạm vô hiệu hóa input file
            const fileInput = document.getElementById('upload_image_file');
            fileInput.disabled = true;
            fileInput.required = false;
        }     
        
        await handleUploadSubmit();
            
        setTimeout(() => {
            document.getElementById('upload_image_url').disabled = false;
            document.getElementById('upload_image_file').disabled = false;
        }, 100);
    });
}

async function handleUploadSubmit() {
    // Lấy phương thức upload
    const activeTab = document.querySelector('.tab-btn.active').getAttribute('data-tab');
    const title = document.getElementById('upload_title').value.trim();
    const description = document.getElementById('upload_description').value.trim();
    const category = document.getElementById('upload_category').value;
    
    // Validate
    if (!title || !category) {
        showNotification('Vui lòng nhập tiêu đề và chọn danh mục!', 'error');
        return;
    }
    
    // Chỉ hỗ trợ upload file trong modal (vì server chỉ hỗ trợ file)
    if (activeTab === 'file') {
        await handleFileUpload(title, description, category);
    } else {
        showNotification('Chức năng upload qua URL tạm thời không khả dụng. Vui lòng dùng upload file!', 'warning');
        return;
    }
}

async function handleFileUpload(title, description, category) {
    const fileInput = document.getElementById('upload_image_file');
    const file = fileInput.files[0];
    
   const uploadFormHome = document.getElementById('uploadFormHome');     
        
    if (!file) {
        showNotification('Vui lòng chọn ảnh để upload!', 'error');
        return;
    }
    
    // Kiểm tra file
    if (file.size > 5 * 1024 * 1024) {
        showNotification('File quá lớn! Vui lòng chọn file nhỏ hơn 5MB', 'error');
        return;
    }
    
    const allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
    if (!allowedTypes.includes(file.type)) {
        showNotification('Chỉ chấp nhận file ảnh (JPG, PNG, GIF, WEBP)', 'error');
        return;
    }
    
    // Hiển thị loading
    const submitBtn = uploadFormHome.querySelector('button[type="submit"]');
    const originalText = submitBtn.innerHTML;
    submitBtn.disabled = true;
    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Đang upload...';
    
    // Tạo FormData
    const formData = new FormData();
    formData.append('title', title);
    formData.append('description', description);
    formData.append('category', category);
    formData.append('image', file); // QUAN TRỌNG: phải là 'image' theo server
    
    try {
        const response = await fetch('includes/upload_handler.php', {
            method: 'POST',
            body: formData
        });
        
        const result = await response.json();
        console.log('📦 Upload response:', result);
        
        if (result.success) {
            showNotification(result.message || 'Upload thành công!', 'success');
            
            // Reset form
            uploadFormHome.reset();
            document.getElementById('filePreview').style.display = 'none';
            document.querySelector('.file-upload-placeholder').style.display = 'block';
            
            // Đóng modal
            const closeBtn = document.getElementById('closeUploadModal');
            if (closeBtn) closeBtn.click();
            
            // Refresh page sau 1 giây để hiển thị ảnh mới
            setTimeout(() => {
                window.location.reload();
            }, 1500);
            
        } else {
            showNotification('Lỗi: ' + (result.message || 'Upload thất bại'), 'error');
        }
    } catch (error) {
        console.error('❌ Upload error:', error);
        showNotification('Có lỗi xảy ra khi upload. Vui lòng thử lại!', 'error');
    } finally {
        // Khôi phục button
        if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.innerHTML = originalText;
        }
    }
}

console.log('✅ ArtFolio JS fully loaded and ready!');