// =============================================
// ArtFolio Gallery JavaScript
// File: assets/js/gallery.js
// Updated to match new Blue CSS theme
// =============================================

console.log('🖼️ Gallery JS loading...');

// ==================== GALLERY FUNCTIONS ====================
function initGallery() {
    console.log('🖼️ Initializing gallery...');
    
    // Kiểm tra xem có gallery trên trang không
    const galleryGrid = document.getElementById('galleryGrid');
    const filterBtns = document.querySelectorAll('.filter-btn');
    
    if (!galleryGrid) {
        console.log('⚠️ Gallery not found on this page');
        return;
    }
    
    console.log('✅ Gallery found, setting up...');
    
    // Load gallery từ API
    loadGallery();
    
    // Setup filter nếu có
    if (filterBtns.length > 0) {
        initGalleryFilters();
    }
}

function loadGallery() {
    console.log('📡 Loading gallery from API...');
    
    const galleryGrid = document.getElementById('galleryGrid');
    if (!galleryGrid) return;
    
    // Show loading with new blue color
    galleryGrid.innerHTML = `
        <div class="loading-gallery" style="grid-column: 1 / -1; text-align: center; padding: 50px;">
            <div class="spinner" style="border: 3px solid rgba(0, 132, 255, 0.1); border-left-color: #0084ff; border-radius: 50%; width: 40px; height: 40px; animation: spin 1s linear infinite; margin: 0 auto;"></div>
            <p style="margin-top: 20px; color: #0084ff; font-weight: 600;">Đang tải gallery...</p>
        </div>
    `;
    
    // Load từ API thật
    fetch('api/gallery.php?action=get_all&limit=12')
        .then(response => {
            if (!response.ok) throw new Error('API không khả dụng');
            return response.json();
        })
        .then(result => {
            console.log('📦 API Response:', result);
            
            if (result.success && result.data && result.data.length > 0) {
                console.log(`✅ Loaded ${result.data.length} items from API`);
                displayGallery(result.data);
            } else {
                // Không có dữ liệu thật
                console.log('⚠️ No artwork data available');
                showNoDataMessage();
            }
        })
        .catch(error => {
            console.log('❌ API error:', error);
            showErrorMessage('Không thể kết nối đến server');
        });
}

function displayGallery(items) {
    const galleryGrid = document.getElementById('galleryGrid');
    if (!galleryGrid) return;
    
    if (!items || items.length === 0) {
        showNoDataMessage();
        return;
    }
    
    galleryGrid.innerHTML = items.map((item, index) => `
        <div class="gallery-item" data-category="${item.category || 'all'}" style="opacity: 0; animation-delay: ${index * 0.1}s;">
            <a href="pages/image-detail.php?id=${item.id}" class="gallery-link">
                <div class="gallery-img-container">
                    ${getGalleryImageHTML(item)}
                    <div class="gallery-overlay">
                        <h3 class="gallery-title">${escapeHtml(item.title)}</h3>
                        <p class="gallery-artist">${escapeHtml(item.username || 'Nghệ sĩ')}</p>
                    </div>
                </div>
                <div class="gallery-content">
                    <h3 class="gallery-title">${escapeHtml(item.title)}</h3>
                    ${item.description ? `<p class="gallery-description">${escapeHtml(item.description)}</p>` : ''}
                    <div class="gallery-meta">
                        <span><i class="fas fa-eye"></i> ${formatNumber(item.views || 0)}</span>
                        <span><i class="fas fa-heart"></i> ${formatNumber(item.likes || 0)}</span>
                        <span><i class="fas fa-comment"></i> ${formatNumber(item.comments || 0)}</span>
                    </div>
                </div>
            </a>
        </div>
    `).join('');
    
    // Add animation
    setTimeout(() => {
        document.querySelectorAll('.gallery-item').forEach((item) => {
            item.style.animation = 'fadeInUp 0.5s forwards';
        });
    }, 100);
}

function getGalleryImageHTML(item) {
    // Nếu có ảnh thật
    if (item.image_path && item.image_path.trim() !== '' && item.image_path !== 'null') {
        const imageUrl = item.image_path.includes('http') ? 
            item.image_path : 
            `uploads/gallery/${item.image_path}`;
            
        return `<img src="${imageUrl}" 
                     alt="${escapeHtml(item.title)}" 
                     class="gallery-img"
                     loading="lazy"
                     onerror="this.onerror=null; this.parentElement.innerHTML='${getPlaceholderHTML(item.category)}';">`;
    } else {
        // Placeholder với màu gradient mới
        return getPlaceholderHTML(item.category);
    }
}

function getPlaceholderHTML(category) {
    const gradient = getGradientColor(category);
    return `<div class="gallery-img-placeholder" 
                 style="background: linear-gradient(135deg, ${gradient}); 
                        width: 100%; 
                        height: 250px; 
                        display: flex; 
                        align-items: center; 
                        justify-content: center;">
                <i class="fas fa-image" style="font-size: 48px; color: rgba(255,255,255,0.5);"></i>
            </div>`;
}

function getPlaceholderImage(category) {
    // Tạo placeholder URL với màu mới (blue theme)
    const colors = {
        'painting': '0084ff',
        'digital': '00c851',
        'photography': '00c6ff',
        'sculpture': 'ffbb33',
        'illustration': 'ff4444',
        'other': '0084ff'
    };
    
    const color = colors[category] || colors.other;
    return `https://via.placeholder.com/400x300/${color}/ffffff?text=ArtFolio`;
}

function showNoDataMessage() {
    const galleryGrid = document.getElementById('galleryGrid');
    if (!galleryGrid) return;
    
    galleryGrid.innerHTML = `
        <div class="no-images" style="grid-column: 1 / -1; text-align: center; padding: 50px; color: #666;">
            <i class="fas fa-paint-brush" style="font-size: 48px; margin-bottom: 20px; color: #0084ff; opacity: 0.5;"></i>
            <h3 style="color: #1a1a2e; margin-bottom: 10px;">Chưa có tác phẩm nào</h3>
            <p style="color: #666;">Hãy là người đầu tiên đăng tải tác phẩm!</p>
            <a href="pages/upload.php" class="btn-upload" style="display: inline-block; margin-top: 15px; padding: 12px 30px; background: #0084ff; color: white; text-decoration: none; border-radius: 50px; font-weight: 600; transition: all 0.3s; box-shadow: 0 2px 10px rgba(0, 132, 255, 0.2);">
                <i class="fas fa-upload"></i> Đăng ảnh ngay
            </a>
        </div>
    `;
}

function showErrorMessage(message) {
    const galleryGrid = document.getElementById('galleryGrid');
    if (!galleryGrid) return;
    
    galleryGrid.innerHTML = `
        <div class="error-message" style="grid-column: 1 / -1; text-align: center; padding: 50px; color: #ff4444;">
            <i class="fas fa-exclamation-triangle" style="font-size: 48px; margin-bottom: 20px; color: #ff4444;"></i>
            <h3 style="color: #1a1a2e; margin-bottom: 10px;">Không thể tải gallery</h3>
            <p style="color: #666;">${message}</p>
            <button onclick="loadGallery()" style="margin-top: 15px; padding: 12px 30px; background: #0084ff; color: white; border: none; border-radius: 50px; cursor: pointer; font-weight: 600; transition: all 0.3s; box-shadow: 0 2px 10px rgba(0, 132, 255, 0.2);">
                <i class="fas fa-redo"></i> Thử lại
            </button>
        </div>
    `;
}

function initGalleryFilters() {
    const filterBtns = document.querySelectorAll('.filter-btn');
    if (filterBtns.length === 0) return;
    
    filterBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            // Remove active class from all
            filterBtns.forEach(b => b.classList.remove('active'));
            
            // Add active to clicked
            this.classList.add('active');
            
            // Get filter
            const filter = this.getAttribute('data-filter');
            
            // Filter items
            filterGalleryItems(filter);
        });
    });
}

function filterGalleryItems(filter) {
    const items = document.querySelectorAll('.gallery-item');
    
    items.forEach((item, index) => {
        const category = item.getAttribute('data-category');
        
        if (filter === 'all' || category === filter) {
            item.style.display = 'block';
            // Add animation
            item.style.animation = `fadeIn 0.5s forwards ${index * 0.05}s`;
        } else {
            item.style.display = 'none';
        }
    });
}

// ==================== HELPER FUNCTIONS ====================
function getGradientColor(category) {
    // Updated colors to match new CSS blue theme
    const colors = {
        'painting': '#0084ff, #0066cc',      // Blue gradient
        'digital': '#00c851, #007e33',       // Green gradient
        'photography': '#0084ff, #00c6ff',   // Blue to cyan
        'sculpture': '#ffbb33, #ff8800',     // Orange gradient
        'illustration': '#ff4444, #cc0000',  // Red gradient
        'other': '#0084ff, #0066cc'          // Default blue
    };
    return colors[category] || colors.other;
}

function formatNumber(num) {
    if (num >= 1000000) {
        return (num / 1000000).toFixed(1) + 'M';
    }
    if (num >= 1000) {
        return (num / 1000).toFixed(1) + 'k';
    }
    return num;
}

function escapeHtml(text) {
    if (!text) return '';
    const map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    };
    return text.toString().replace(/[&<>"']/g, m => map[m]);
}

// ==================== ADD STYLES ====================
function addGalleryStyles() {
    if (document.getElementById('gallery-styles')) return;
    
    const style = document.createElement('style');
    style.id = 'gallery-styles';
    style.textContent = `
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        
        @keyframes spin {
            to { transform: rotate(360deg); }
        }
        
        .gallery-item {
            opacity: 0;
            animation-fill-mode: forwards;
        }
        
        .btn-upload:hover {
            background: #0066cc !important;
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(0, 132, 255, 0.3) !important;
        }
        
        .error-message button:hover {
            background: #0066cc !important;
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(0, 132, 255, 0.3) !important;
        }
    `;
    
    document.head.appendChild(style);
}

// ==================== INITIALIZATION ====================
// Initialize when DOM is ready
document.addEventListener('DOMContentLoaded', function() {
    console.log('✅ DOM loaded, initializing gallery...');
    addGalleryStyles();
    initGallery();
});

// Export functions for global access
window.initGallery = initGallery;
window.loadGallery = loadGallery;
window.filterGalleryItems = filterGalleryItems;

console.log('✅ Gallery JS loaded successfully');