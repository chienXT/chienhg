// =============================================
// Image Detail Page JavaScript
// =============================================

document.addEventListener('DOMContentLoaded', function() {
    console.log('🖼️ Image detail page initialized');
    
    initImageActions();
    initCommentForm();
    initCommentActions();
    initShareButton();
});

// ==================== IMAGE ACTIONS ====================
function initImageActions() {
    // Like button
    const likeBtn = document.getElementById('likeBtn');
    if (likeBtn) {
        likeBtn.addEventListener('click', function() {
            const imageId = this.getAttribute('data-image-id');
            toggleLike(imageId, this);
        });
    }

    // Save button
    const saveBtn = document.getElementById('saveBtn');
    if (saveBtn) {
        saveBtn.addEventListener('click', function() {
            toggleSave(this);
        });
    }

    // Download button
    const downloadBtn = document.getElementById('downloadBtn');
    if (downloadBtn) {
        downloadBtn.addEventListener('click', function() {
            downloadImage();
        });
    }

    // Follow button
    const followBtn = document.querySelector('.btn-follow');
    if (followBtn) {
        followBtn.addEventListener('click', function() {
            const authorId = this.getAttribute('data-author-id');
            toggleFollow(authorId, this);
        });
    }

    // Login prompt button
    const loginPromptBtn = document.getElementById('loginPromptBtn');
    if (loginPromptBtn) {
        loginPromptBtn.addEventListener('click', function() {
            if (typeof showModal === 'function') {
                showModal('login');
            } else {
                window.location.href = '../index.php#login';
            }
        });
    }
}

function toggleLike(imageId, button) {
    const isLiked = button.classList.contains('liked');
    
    // Optimistic UI update
    button.classList.toggle('liked');
    const span = button.querySelector('span');
    if (span) {
        span.textContent = isLiked ? 'Thích' : 'Đã thích';
    }

    // Send to server
    fetch('../api/likes.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            action: isLiked ? 'unlike' : 'like',
            image_id: imageId,
            type: 'image'
        })
    })
    .then(response => response.json())
    .then(result => {
        if (result.success) {
            showNotification(result.message || (isLiked ? 'Đã bỏ thích' : 'Đã thích tác phẩm'), 'success');
            
            // Update like count if provided
            if (result.data && result.data.likes_count) {
                updateLikeCount(result.data.likes_count);
            }
        } else {
            // Revert on error
            button.classList.toggle('liked');
            if (span) {
                span.textContent = isLiked ? 'Đã thích' : 'Thích';
            }
            showNotification(result.message || 'Có lỗi xảy ra', 'error');
        }
    })
    .catch(error => {
        console.error('Like error:', error);
        // Revert on error
        button.classList.toggle('liked');
        if (span) {
            span.textContent = isLiked ? 'Đã thích' : 'Thích';
        }
        showNotification('Lỗi kết nối', 'error');
    });
}

function toggleSave(button) {
    const isSaved = button.classList.contains('saved');
    
    button.classList.toggle('saved');
    const span = button.querySelector('span');
    if (span) {
        span.textContent = isSaved ? 'Lưu' : 'Đã lưu';
    }

    showNotification(isSaved ? 'Đã bỏ lưu' : 'Đã lưu tác phẩm', 'success');
}

function toggleFollow(authorId, button) {
    const isFollowing = button.classList.contains('following');
    
    button.disabled = true;
    button.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Đang xử lý...';

    fetch('../api/follow.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            action: isFollowing ? 'unfollow' : 'follow',
            author_id: authorId
        })
    })
    .then(response => response.json())
    .then(result => {
        if (result.success) {
            button.classList.toggle('following');
            button.innerHTML = isFollowing ? 
                '<i class="fas fa-user-plus"></i> Theo dõi' : 
                '<i class="fas fa-user-check"></i> Đang theo dõi';
            
            showNotification(result.message || (isFollowing ? 'Đã bỏ theo dõi' : 'Đã theo dõi'), 'success');
        } else {
            showNotification(result.message || 'Có lỗi xảy ra', 'error');
        }
    })
    .catch(error => {
        console.error('Follow error:', error);
        showNotification('Lỗi kết nối', 'error');
    })
    .finally(() => {
        button.disabled = false;
        if (!button.classList.contains('following')) {
            button.innerHTML = '<i class="fas fa-user-plus"></i> Theo dõi';
        }
    });
}

function downloadImage() {
    const mainImage = document.getElementById('mainImage');
    if (!mainImage) {
        showNotification('Không tìm thấy ảnh để tải', 'error');
        return;
    }

    const imageUrl = mainImage.src;
    const link = document.createElement('a');
    link.href = imageUrl;
    link.download = 'artfolio-image-' + Date.now() + '.jpg';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    showNotification('Đang tải xuống...', 'success');
}

function updateLikeCount(count) {
    const likeCountEls = document.querySelectorAll('.meta-item .fa-heart + *');
    likeCountEls.forEach(el => {
        el.textContent = ' ' + count + ' lượt thích';
    });
}

// ==================== COMMENT FORM ====================
function initCommentForm() {
    const commentForm = document.getElementById('commentForm');
    if (!commentForm) return;

    const textarea = commentForm.querySelector('.comment-textarea');
    const cancelBtn = commentForm.querySelector('.btn-cancel');
    const submitBtn = commentForm.querySelector('.btn-submit-comment');

    // Show/hide actions on focus
    textarea.addEventListener('focus', function() {
        commentForm.classList.add('active');
    });

    // Cancel button
    if (cancelBtn) {
        cancelBtn.addEventListener('click', function() {
            textarea.value = '';
            textarea.blur();
            commentForm.classList.remove('active');
        });
    }

    // Submit form
    commentForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const commentText = textarea.value.trim();
        if (!commentText) {
            showNotification('Vui lòng nhập nội dung bình luận', 'error');
            return;
        }

        // Get image ID from URL
        const urlParams = new URLSearchParams(window.location.search);
        const imageId = urlParams.get('id');

        submitBtn.disabled = true;
        submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Đang gửi...';

        fetch('../api/comments.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                action: 'add_comment',
                image_id: imageId,
                comment: commentText
            })
        })
        .then(response => response.json())
        .then(result => {
            if (result.success) {
                showNotification('Đã thêm bình luận', 'success');
                textarea.value = '';
                commentForm.classList.remove('active');
                
                // Add new comment to list
                if (result.data && result.data.comment) {
                    addCommentToList(result.data.comment);
                    updateCommentCount(1);
                }
            } else {
                showNotification(result.message || 'Không thể thêm bình luận', 'error');
            }
        })
        .catch(error => {
            console.error('Comment error:', error);
            showNotification('Lỗi kết nối', 'error');
        })
        .finally(() => {
            submitBtn.disabled = false;
            submitBtn.innerHTML = '<i class="fas fa-paper-plane"></i> Gửi';
        });
    });
}

function addCommentToList(comment) {
    const commentsList = document.querySelector('.comments-list');
    if (!commentsList) return;

    const commentHTML = `
        <div class="comment-item" data-comment-id="${comment.id}">
            ${comment.user.avatar ? 
                `<img src="${comment.user.avatar}" alt="${comment.user.username}" class="comment-avatar">` :
                `<div class="comment-avatar-initial">${comment.user.username.charAt(0).toUpperCase()}</div>`
            }
            
            <div class="comment-content">
                <div class="comment-header">
                    <span class="comment-author">${comment.user.username}</span>
                    <span class="comment-time">Vừa xong</span>
                </div>
                
                <p class="comment-text">${comment.text}</p>
                
                <div class="comment-actions">
                    <span class="comment-action">
                        <i class="fas fa-heart"></i>
                        <span>0</span>
                    </span>
                    <span class="comment-action">
                        <i class="fas fa-reply"></i>
                        <span>Trả lời</span>
                    </span>
                </div>
            </div>
        </div>
    `;

    commentsList.insertAdjacentHTML('afterbegin', commentHTML);
}

function updateCommentCount(delta) {
    const countEl = document.querySelector('.comments-count');
    if (countEl) {
        const currentCount = parseInt(countEl.textContent) || 0;
        countEl.textContent = currentCount + delta;
    }

    // Update meta count
    const metaCountEls = document.querySelectorAll('.meta-item .fa-comment + *');
    metaCountEls.forEach(el => {
        const text = el.textContent;
        const match = text.match(/(\d+)/);
        if (match) {
            const count = parseInt(match[1]) + delta;
            el.textContent = ' ' + count + ' bình luận';
        }
    });
}

// ==================== COMMENT ACTIONS ====================
function initCommentActions() {
    // Like comment
    document.addEventListener('click', function(e) {
        if (e.target.closest('.comment-action .fa-heart')) {
            const action = e.target.closest('.comment-action');
            toggleCommentLike(action);
        }
    });

    // Reply to comment
    document.addEventListener('click', function(e) {
        if (e.target.closest('.comment-action .fa-reply')) {
            const commentItem = e.target.closest('.comment-item');
            const commentId = commentItem.getAttribute('data-comment-id');
            showReplyForm(commentItem, commentId);
        }
    });
}

function toggleCommentLike(actionElement) {
    const isLiked = actionElement.classList.contains('liked');
    actionElement.classList.toggle('liked');
    
    const countSpan = actionElement.querySelector('span');
    if (countSpan) {
        const currentCount = parseInt(countSpan.textContent) || 0;
        countSpan.textContent = isLiked ? currentCount - 1 : currentCount + 1;
    }

    showNotification(isLiked ? 'Đã bỏ thích' : 'Đã thích bình luận', 'success');
}

function showReplyForm(commentItem, commentId) {
    // Check if reply form already exists
    if (commentItem.querySelector('.reply-form')) return;

    const replyFormHTML = `
        <div class="reply-form" style="margin-top: 1rem;">
            <textarea class="comment-textarea" placeholder="Viết câu trả lời..." style="min-height: 80px;"></textarea>
            <div class="comment-form-actions" style="margin-top: 0.5rem;">
                <button type="button" class="btn-cancel">Hủy</button>
                <button type="button" class="btn-submit-reply">
                    <i class="fas fa-paper-plane"></i> Trả lời
                </button>
            </div>
        </div>
    `;

    const commentContent = commentItem.querySelector('.comment-content');
    commentContent.insertAdjacentHTML('beforeend', replyFormHTML);

    const replyForm = commentContent.querySelector('.reply-form');
    const textarea = replyForm.querySelector('textarea');
    const cancelBtn = replyForm.querySelector('.btn-cancel');
    const submitBtn = replyForm.querySelector('.btn-submit-reply');

    textarea.focus();

    cancelBtn.addEventListener('click', function() {
        replyForm.remove();
    });

    submitBtn.addEventListener('click', function() {
        const replyText = textarea.value.trim();
        if (!replyText) {
            showNotification('Vui lòng nhập nội dung trả lời', 'error');
            return;
        }

        submitBtn.disabled = true;
        submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Đang gửi...';

        // Submit reply
        fetch('../api/comments.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                action: 'add_reply',
                comment_id: commentId,
                reply: replyText
            })
        })
        .then(response => response.json())
        .then(result => {
            if (result.success) {
                showNotification('Đã thêm câu trả lời', 'success');
                replyForm.remove();
                
                if (result.data && result.data.reply) {
                    addReplyToComment(commentItem, result.data.reply);
                }
            } else {
                showNotification(result.message || 'Không thể thêm câu trả lời', 'error');
            }
        })
        .catch(error => {
            console.error('Reply error:', error);
            showNotification('Lỗi kết nối', 'error');
        })
        .finally(() => {
            submitBtn.disabled = false;
            submitBtn.innerHTML = '<i class="fas fa-paper-plane"></i> Trả lời';
        });
    });
}

function addReplyToComment(commentItem, reply) {
    let replySection = commentItem.querySelector('.comment-reply');
    
    if (!replySection) {
        replySection = document.createElement('div');
        replySection.className = 'comment-reply';
        commentItem.querySelector('.comment-content').appendChild(replySection);
    }

    const replyHTML = `
        <div class="reply-item">
            ${reply.user.avatar ? 
                `<img src="${reply.user.avatar}" alt="${reply.user.username}" class="reply-avatar">` :
                `<div class="reply-avatar-initial">${reply.user.username.charAt(0).toUpperCase()}</div>`
            }
            
            <div class="comment-content">
                <div class="comment-header">
                    <span class="comment-author">${reply.user.username}</span>
                    <span class="comment-time">Vừa xong</span>
                </div>
                <p class="comment-text">${reply.text}</p>
            </div>
        </div>
    `;

    replySection.insertAdjacentHTML('beforeend', replyHTML);
}

// ==================== SHARE BUTTON ====================
function initShareButton() {
    const shareBtn = document.getElementById('shareBtn');
    if (!shareBtn) return;

    shareBtn.addEventListener('click', function() {
        const url = window.location.href;
        const title = document.querySelector('.image-title').textContent;

        if (navigator.share) {
            navigator.share({
                title: title,
                url: url
            })
            .then(() => showNotification('Đã chia sẻ', 'success'))
            .catch(err => console.log('Error sharing:', err));
        } else {
            // Fallback: Copy to clipboard
            navigator.clipboard.writeText(url)
                .then(() => showNotification('Đã sao chép link', 'success'))
                .catch(() => showNotification('Không thể sao chép link', 'error'));
        }
    });
}

// ==================== HELPER FUNCTIONS ====================
function showNotification(message, type = 'info') {
    if (typeof window.showNotification === 'function') {
        window.showNotification(message, type);
    } else {
        alert(message);
    }
}