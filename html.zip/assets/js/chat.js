// assets/js/chat.js
class PublicChat {
    constructor() {
        this.lastId = 0;
        this.isLoading = false;
        this.pollingInterval = null;
        
        this.init();
    }

    init() {
        // Đợi DOM tải xong
        setTimeout(() => {
            this.loadHistory();
            this.startPolling();
            this.setupEventListeners();
        }, 100);
    }

    setupEventListeners() {
        // Form submit - CHỈNH QUAN TRỌNG
        const chatForm = document.getElementById('chatForm');
        if (chatForm) {
            // Xóa listener cũ nếu có
            chatForm.removeEventListener('submit', this.handleSubmit);
            
            // Thêm listener mới
            this.handleSubmit = this.handleSubmit.bind(this);
            chatForm.addEventListener('submit', this.handleSubmit);
        }

        // Textarea events
        const textarea = document.getElementById('messageInput');
        if (textarea) {
            // Auto resize
            textarea.addEventListener('input', function() {
                this.style.height = 'auto';
                const height = Math.min(this.scrollHeight, 120);
                this.style.height = height + 'px';
            });

            // Enter to send
            textarea.addEventListener('keydown', (e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    this.sendMessage();
                }
            });

            // Focus vào input khi click vào chat
            document.getElementById('chatMessages')?.addEventListener('click', () => {
                textarea.focus();
            });
        }

        // Thêm sự kiện scroll để load thêm tin nhắn cũ
        const messagesContainer = document.getElementById('chatMessages');
        if (messagesContainer) {
            messagesContainer.addEventListener('scroll', () => {
                this.handleScroll();
            });
        }
    }

    handleSubmit(e) {
        e.preventDefault();
        e.stopPropagation();
        this.sendMessage();
        return false;
    }

    async sendMessage() {
        const input = document.getElementById('messageInput');
        if (!input) return;
        
        const message = input.value.trim();
        if (!message) {
            input.focus();
            return;
        }

        try {
            // Disable input và button
            input.disabled = true;
            const sendBtn = document.querySelector('#chatForm button[type="submit"]');
            if (sendBtn) {
                sendBtn.disabled = true;
                sendBtn.innerHTML = '<span class="spinner-border spinner-border-sm"></span>';
            }

            // Gửi request
            const formData = new FormData();
            formData.append('message', message);
            
            const res = await fetch('api/chat.php?action=send', {
                method: 'POST',
                body: formData
            });
            
            const data = await res.json();

            if (data.success) {
                // Xóa nội dung input
                input.value = '';
                input.style.height = 'auto';
                
                // Hiển thị tin nhắn ngay lập tức
                if (data.message) {
                    this.addMessageImmediately(data.message);
                    this.scrollToBottom();
                }
                
                // Cập nhật online count nếu có
                if (data.online_count !== undefined) {
                    this.updateOnlineCount(data.online_count);
                }
                
                console.log('✓ Tin nhắn đã gửi');
            } else {
                alert(data.error || 'Gửi tin nhắn thất bại');
            }
        } catch (err) {
            console.error('Lỗi gửi tin nhắn:', err);
            alert('Lỗi kết nối. Vui lòng thử lại.');
        } finally {
            // Re-enable input và button
            input.disabled = false;
            input.focus();
            
            const sendBtn = document.querySelector('#chatForm button[type="submit"]');
            if (sendBtn) {
                sendBtn.disabled = false;
                sendBtn.innerHTML = 'Gửi';
            }
        }
    }

    async loadHistory() {
        try {
            const container = document.getElementById('chatMessages');
            if (!container) return;
            
            const res = await fetch('api/chat.php?action=history');
            const data = await res.json();
            
            if (data.success && data.messages && data.messages.length > 0) {
                container.innerHTML = ''; // Xóa loading
                this.renderMessages(data.messages);
                
                // Cập nhật lastId
                this.lastId = data.last_id || data.messages[data.messages.length - 1].id || 0;
                this.scrollToBottom();
            } else if (data.success) {
                container.innerHTML = `
                    <div class="text-center py-5">
                        <i class="far fa-comments fa-3x text-muted mb-3"></i>
                        <p class="text-muted">Chưa có tin nhắn nào. Hãy bắt đầu cuộc trò chuyện!</p>
                    </div>
                `;
            }
            
            // Cập nhật số người online
            if (data.online_count !== undefined) {
                this.updateOnlineCount(data.online_count);
            }
        } catch (err) {
            console.error('Lỗi tải lịch sử chat:', err);
            const container = document.getElementById('chatMessages');
            if (container) {
                container.innerHTML = `
                    <div class="text-center py-5">
                        <i class="fas fa-exclamation-triangle fa-3x text-danger mb-3"></i>
                        <p class="text-danger">Không thể tải tin nhắn. Vui lòng thử lại sau.</p>
                    </div>
                `;
            }
        }
    }

    async loadNewMessages() {
        if (this.isLoading || !document.getElementById('chatMessages')) return;
        this.isLoading = true;

        try {
            const res = await fetch(`api/chat.php?action=get&last_id=${this.lastId}`);
            const data = await res.json();

            if (data.success && data.messages && data.messages.length > 0) {
                // Chỉ render nếu có tin nhắn mới
                if (this.hasNewMessages(data.messages)) {
                    this.renderMessages(data.messages);
                    this.lastId = data.last_id;
                    
                    // Chỉ scroll nếu user đang ở gần bottom
                    if (this.isNearBottom()) {
                        this.scrollToBottom();
                    }
                }
            }
            
            // Cập nhật online count
            if (data.online_count !== undefined) {
                this.updateOnlineCount(data.online_count);
            }
        } catch (err) {
            console.error('Lỗi tải tin nhắn mới:', err);
        } finally {
            this.isLoading = false;
        }
    }

    hasNewMessages(messages) {
        return messages.some(msg => msg.id > this.lastId);
    }

    isNearBottom() {
        const container = document.getElementById('chatMessages');
        if (!container) return true;
        
        const threshold = 100; // pixels từ bottom
        return container.scrollHeight - container.scrollTop - container.clientHeight <= threshold;
    }

    handleScroll() {
        const container = document.getElementById('chatMessages');
        if (!container) return;
        
        // Load more messages khi scroll lên đầu
        if (container.scrollTop === 0 && !this.isLoading) {
            // Có thể implement load older messages ở đây
        }
    }

    addMessageImmediately(message) {
        const container = document.getElementById('chatMessages');
        if (!container || !message) return;

        // Kiểm tra xem có hiển thị "chưa có tin nhắn" không
        if (container.querySelector('.fa-comments')) {
            container.innerHTML = '';
        }

        const isOwn = message.user_id == <?php echo json_encode($_SESSION['user_id'] ?? 0); ?>;
        const div = document.createElement('div');
        div.className = 'message ' + (isOwn ? 'self' : 'other');
        div.setAttribute('data-message-id', message.id);
        div.innerHTML = `
            <div class="username">${this.escapeHtml(message.username)}</div>
            <div class="content">${this.escapeHtml(message.message)}</div>
            <div class="time">${this.formatTime(message.created_at)}</div>
        `;
        container.appendChild(div);
        
        // Cập nhật lastId
        if (message.id && message.id > this.lastId) {
            this.lastId = message.id;
        }
    }

    renderMessages(messages) {
        const container = document.getElementById('chatMessages');
        if (!container || !messages) return;

        // Lọc tin nhắn mới (chưa hiển thị)
        const newMessages = messages.filter(msg => 
            msg.id > this.lastId && 
            !container.querySelector(`[data-message-id="${msg.id}"]`)
        );

        if (newMessages.length === 0) return;

        // Sắp xếp theo thời gian
        newMessages.sort((a, b) => new Date(a.created_at) - new Date(b.created_at));

        newMessages.forEach(msg => {
            this.addMessageImmediately(msg);
        });
    }

    scrollToBottom() {
        const container = document.getElementById('chatMessages');
        if (container) {
            setTimeout(() => {
                container.scrollTop = container.scrollHeight;
            }, 50);
        }
    }

    updateOnlineCount(count) {
        const onlineCountEl = document.getElementById('online-count');
        if (onlineCountEl) {
            if (count === 1) {
                onlineCountEl.textContent = '1 người online';
            } else {
                onlineCountEl.textContent = `${count} người online`;
            }
        }
    }

    formatTime(datetime) {
        try {
            if (!datetime) return 'Vừa xong';
            
            const date = new Date(datetime.replace(' ', 'T'));
            if (isNaN(date.getTime())) {
                return 'Vừa xong';
            }
            
            const now = new Date();
            const diffMs = now - date;
            const diffSec = Math.floor(diffMs / 1000);
            const diffMin = Math.floor(diffSec / 60);
            const diffHour = Math.floor(diffMin / 60);
            const diffDay = Math.floor(diffHour / 24);

            if (diffSec < 60) return 'Vừa xong';
            if (diffMin < 60) return `${diffMin} phút trước`;
            if (diffHour < 24) return `${diffHour} giờ trước`;
            if (diffDay === 1) return 'Hôm qua';
            if (diffDay < 7) return `${diffDay} ngày trước`;
            
            return date.toLocaleDateString('vi-VN', {
                day: '2-digit',
                month: '2-digit',
                year: 'numeric'
            });
        } catch (err) {
            return 'Vừa xong';
        }
    }

    startPolling() {
        // Dừng polling cũ
        this.stopPolling();
        
        // Bắt đầu polling mới
        this.pollingInterval = setInterval(() => {
            this.loadNewMessages();
        }, 2000); // 2 giây
    }

    stopPolling() {
        if (this.pollingInterval) {
            clearInterval(this.pollingInterval);
            this.pollingInterval = null;
        }
    }

    escapeHtml(text) {
        if (!text) return '';
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    // Cleanup khi thoát trang
    cleanup() {
        this.stopPolling();
        const chatForm = document.getElementById('chatForm');
        if (chatForm && this.handleSubmit) {
            chatForm.removeEventListener('submit', this.handleSubmit);
        }
    }
}

// Khởi động chat
let chatInstance = null;

document.addEventListener('DOMContentLoaded', () => {
    // Kiểm tra xem có container chat không
    if (document.getElementById('chatMessages')) {
        chatInstance = new PublicChat();
        
        // Cleanup khi rời trang
        window.addEventListener('beforeunload', () => {
            if (chatInstance) {
                chatInstance.cleanup();
            }
        });
    }
});

// Export để debug
window.ChatSystem = PublicChat;