<?php
// includes/modals.php
?>

<!-- Login Modal -->
<div id="loginModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h2>Đăng Nhập</h2>
            <button class="modal-close" aria-label="Close">&times;</button>
        </div>
        
        <form id="loginForm" class="auth-form">
            <div class="form-group">
                <label for="loginEmail">Email</label>
                <input type="email" id="loginEmail" name="email" required placeholder="Nhập email của bạn">
                <small class="form-error"></small>
            </div>

            <div class="form-group">
                <label for="loginPassword">Mật Khẩu</label>
                <input type="password" id="loginPassword" name="password" required placeholder="Nhập mật khẩu">
                <small class="form-error"></small>
            </div>

            <div class="form-group checkbox">
                <input type="checkbox" id="rememberMe" name="remember">
                <label for="rememberMe">Nhớ tôi</label>
            </div>

            <button type="submit" class="btn btn-primary btn-block">
                <i class="fas fa-sign-in-alt"></i>
                Đăng Nhập
            </button>

            <div class="form-divider">hoặc</div>

            <button type="button" class="btn-text" id="switchToRegister">
                Chưa có tài khoản? Đăng ký ngay
            </button>
        </form>

        <div class="form-message" id="loginMessage"></div>
    </div>
</div>

<!-- Register Modal -->
<div id="registerModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h2>Đăng Ký</h2>
            <button class="modal-close" aria-label="Close">&times;</button>
        </div>
        
        <form id="registerForm" class="auth-form">
            <div class="form-group">
                <label for="registerUsername">Tên Người Dùng</label>
                <input type="text" id="registerUsername" name="username" required 
                       placeholder="3-50 ký tự, chỉ a-z, 0-9, -, _">
                <small class="form-error"></small>
            </div>

            <div class="form-group">
                <label for="registerEmail">Email</label>
                <input type="email" id="registerEmail" name="email" required 
                       placeholder="Nhập email của bạn">
                <small class="form-error"></small>
            </div>

            <div class="form-group">
                <label for="registerPassword">Mật Khẩu</label>
                <input type="password" id="registerPassword" name="password" required 
                       placeholder="Tối thiểu 6 ký tự">
                <small class="form-error"></small>
            </div>

            <div class="form-group">
                <label for="registerPasswordConfirm">Xác Nhận Mật Khẩu</label>
                <input type="password" id="registerPasswordConfirm" name="password_confirm" required 
                       placeholder="Nhập lại mật khẩu">
                <small class="form-error"></small>
            </div>

            <button type="submit" class="btn btn-primary btn-block">
                <i class="fas fa-user-plus"></i>
                Đăng Ký
            </button>

            <div class="form-divider">hoặc</div>

            <button type="button" class="btn-text" id="switchToLogin">
                Đã có tài khoản? Đăng nhập
            </button>
        </form>

        <div class="form-message" id="registerMessage"></div>
    </div>
</div>

<!-- Upload Modal -->
<div id="uploadModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h2>Tải Lên Tác Phẩm</h2>
            <button class="modal-close" aria-label="Close">&times;</button>
        </div>

        <form id="uploadForm" class="upload-form" enctype="multipart/form-data">
            <div class="form-group">
                <label for="uploadTitle">Tiêu Đề</label>
                <input type="text" id="uploadTitle" name="title" required placeholder="Tiêu đề tác phẩm">
            </div>

            <div class="form-group">
                <label for="uploadCategory">Danh Mục</label>
                <select id="uploadCategory" name="category" required>
                    <option value="">-- Chọn danh mục --</option>
                    <option value="painting">Tranh Sơn Dầu</option>
                    <option value="digital">Nghệ Thuật Số</option>
                    <option value="photography">Nhiếp Ảnh</option>
                    <option value="sculpture">Điêu Khắc</option>
                    <option value="illustration">Minh Họa</option>
                    <option value="other">Khác</option>
                </select>
            </div>

            <div class="form-group">
                <label for="uploadDescription">Mô Tả</label>
                <textarea id="uploadDescription" name="description" rows="4" placeholder="Mô tả tác phẩm của bạn"></textarea>
            </div>

            <div class="form-group">
                <label for="uploadImage">Chọn Ảnh</label>
                <div class="upload-area" id="uploadArea">
                    <i class="fas fa-cloud-upload-alt"></i>
                    <p>Kéo thả ảnh vào đây hoặc click để chọn</p>
                    <small>Hỗ trợ: JPG, PNG, GIF, WebP (tối đa 5MB)</small>
                    <input type="file" id="uploadImage" name="image" accept="image/*" required style="display: none;">
                </div>
                <div class="upload-preview" id="uploadPreview" style="display: none;">
                    <img id="previewImage" alt="Preview">
                    <button type="button" class="btn-remove" id="removePreview">×</button>
                </div>
            </div>

            <div class="form-group checkbox">
                <input type="checkbox" id="uploadPublic" name="is_public" checked>
                <label for="uploadPublic">Công Khai</label>
            </div>

            <button type="submit" class="btn btn-primary btn-block">
                <i class="fas fa-upload"></i>
                Tải Lên
            </button>

            <div class="upload-progress" id="uploadProgress" style="display: none;">
                <div class="progress-bar"></div>
                <span class="progress-text">0%</span>
            </div>
        </form>

        <div class="form-message" id="uploadMessage"></div>
    </div>
</div>

<style>
.modal {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.5);
    z-index: 2000;
    align-items: center;
    justify-content: center;
    opacity: 0;
    transition: opacity 0.3s ease;
}

.modal.active {
    display: flex;
    opacity: 1;
}

.modal-content {
    background: white;
    border-radius: 8px;
    box-shadow: 0 10px 40px rgba(0, 0, 0, 0.2);
    max-width: 400px;
    width: 90%;
    max-height: 90vh;
    overflow-y: auto;
    animation: slideUp 0.3s ease;
}

@keyframes slideUp {
    from {
        transform: translateY(50px);
        opacity: 0;
    }
    to {
        transform: translateY(0);
        opacity: 1;
    }
}

.modal-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 1.5rem;
    border-bottom: 1px solid #e0e0e0;
}

.modal-header h2 {
    margin: 0;
    font-size: 1.5rem;
    color: #333;
}

.modal-close {
    background: none;
    border: none;
    font-size: 1.5rem;
    cursor: pointer;
    color: #999;
    transition: color 0.3s ease;
}

.modal-close:hover {
    color: #333;
}

.auth-form,
.upload-form {
    padding: 1.5rem;
}

.form-group {
    margin-bottom: 1.25rem;
}

.form-group label {
    display: block;
    margin-bottom: 0.5rem;
    font-weight: 600;
    color: #333;
    font-size: 0.95rem;
}

.form-group input[type="text"],
.form-group input[type="email"],
.form-group input[type="password"],
.form-group textarea,
.form-group select {
    width: 100%;
    padding: 0.75rem;
    border: 1px solid #ddd;
    border-radius: 4px;
    font-size: 0.95rem;
    transition: border-color 0.3s ease;
    font-family: inherit;
}

.form-group input:focus,
.form-group textarea:focus,
.form-group select:focus {
    outline: none;
    border-color: #667eea;
    box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
}

.form-group.checkbox {
    display: flex;
    align-items: center;
    margin-bottom: 1rem;
}

.form-group.checkbox input[type="checkbox"] {
    width: auto;
    margin-right: 0.5rem;
    cursor: pointer;
}

.form-group.checkbox label {
    margin: 0;
    cursor: pointer;
    font-weight: 500;
}

.form-error {
    display: block;
    margin-top: 0.25rem;
    color: #d32f2f;
    font-size: 0.85rem;
    min-height: 1.2em;
}

.form-divider {
    text-align: center;
    margin: 1.5rem 0;
    color: #999;
    font-size: 0.9rem;
    position: relative;
}

.form-divider::before {
    content: '';
    position: absolute;
    top: 50%;
    left: 0;
    right: 0;
    height: 1px;
    background: #ddd;
    z-index: -1;
}

.form-divider {
    background: white;
    padding: 0 1rem;
    display: inline-block;
    width: 100%;
}

.btn-text {
    background: none;
    border: none;
    color: #667eea;
    cursor: pointer;
    font-weight: 600;
    font-size: 0.95rem;
    width: 100%;
    padding: 0.75rem;
    transition: color 0.3s ease;
}

.btn-text:hover {
    color: #764ba2;
    text-decoration: underline;
}

.btn-block {
    width: 100%;
}

.form-message {
    padding: 1rem;
    margin-top: 1rem;
    border-radius: 4px;
    display: none;
    font-size: 0.95rem;
}

.form-message.success {
    background: #c8e6c9;
    color: #2e7d32;
    display: block;
}

.form-message.error {
    background: #ffcdd2;
    color: #d32f2f;
    display: block;
}

.upload-area {
    border: 2px dashed #ddd;
    border-radius: 8px;
    padding: 2rem;
    text-align: center;
    cursor: pointer;
    transition: all 0.3s ease;
}

.upload-area:hover {
    border-color: #667eea;
    background: #f5f7ff;
}

.upload-area i {
    font-size: 2.5rem;
    color: #999;
    margin-bottom: 0.5rem;
}

.upload-area p {
    margin: 0.5rem 0 0;
    font-weight: 600;
    color: #333;
}

.upload-area small {
    display: block;
    color: #999;
    margin-top: 0.5rem;
}

.upload-preview {
    position: relative;
    margin-top: 1rem;
}

.upload-preview img {
    max-width: 100%;
    border-radius: 4px;
}

.btn-remove {
    position: absolute;
    top: -10px;
    right: -10px;
    width: 30px;
    height: 30px;
    background: #d32f2f;
    color: white;
    border: none;
    border-radius: 50%;
    cursor: pointer;
    font-size: 1.5rem;
    display: flex;
    align-items: center;
    justify-content: center;
}

.upload-progress {
    margin-top: 1rem;
}

.progress-bar {
    width: 100%;
    height: 4px;
    background: #e0e0e0;
    border-radius: 2px;
    overflow: hidden;
}

.progress-bar::after {
    content: '';
    display: block;
    height: 100%;
    background: #667eea;
    animation: progress 1s ease;
}

@keyframes progress {
    from {
        width: 0;
    }
}

.progress-text {
    font-size: 0.85rem;
    color: #666;
}

@media (max-width: 600px) {
    .modal-content {
        max-width: 95%;
    }

    .modal-header {
        padding: 1rem;
    }

    .modal-header h2 {
        font-size: 1.25rem;
    }

    .auth-form,
    .upload-form {
        padding: 1rem;
    }
}
</style>