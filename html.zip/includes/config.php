<?php
// includes/config.php - SECURE & OPTIMIZED
// ============================================================================

// Prevent direct access
if (basename($_SERVER['PHP_SELF']) === 'config.php') {
    http_response_code(403);
    exit('Access denied');
}

// ========== OUTPUT BUFFERING ==========
if (!ob_get_level()) {
    ob_start();
}

// ========== ENVIRONMENT CONFIGURATION ==========
// Load from .env file if exists, otherwise use hardcoded (fallback)
$env_file = dirname(__DIR__) . '/.env';
if (file_exists($env_file)) {
    $env = parse_ini_file($env_file);
    define('APP_ENV', $env['APP_ENV'] ?? 'production');
    define('DEBUG_MODE', strtolower($env['APP_ENV'] ?? 'production') === 'development');
} else {
    define('APP_ENV', 'production');
    define('DEBUG_MODE', false); // Always false in production
}

// ========== SESSION CONFIGURATION ==========
if (session_status() === PHP_SESSION_NONE) {
    // Secure session configuration for shared hosting
    session_set_cookie_params([
        'lifetime' => 86400 * 7,      // 7 days
        'path' => '/',
        'domain' => '',               // Empty for shared hosting
        'secure' => isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on',
        'httponly' => true,           // Not accessible via JavaScript
        'samesite' => 'Lax'           // CSRF protection
    ]);
    
    session_start();
}

// ========== DATABASE CONFIGURATION ==========
// SECURE: Read from .env file first, then fallback to constants
if (!empty($env) && function_exists('parse_ini_file')) {
    define('DB_HOST', $env['DB_HOST'] ?? 'fdb1018.atspace.me');
    define('DB_USER', $env['DB_USER'] ?? '3843044_chienhg');
    define('DB_PASS', $env['DB_PASS'] ?? 'Anhchien0310@');
    define('DB_NAME', $env['DB_NAME'] ?? '3843044_chienhg');
} else {
    // Fallback - should be in .env file in production
    define('DB_HOST', 'fdb1018.atspace.me');
    define('DB_USER', '3843044_chienhg');
    define('DB_PASS', 'Anhchien0310@');
    define('DB_NAME', '3843044_chienhg');
}

// ========== SITE CONFIGURATION ==========
$protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https://' : 'http://';
$host = $_SERVER['HTTP_HOST'];

// Remove trailing slash from domain, add to URL
$site_url = $protocol . rtrim($host, '/') . '/';

define('SITE_URL', $site_url);
define('BASE_URL', $site_url);
define('SITE_NAME', $env['SITE_NAME'] ?? 'ArtFolio');
define('SITE_EMAIL', $env['SITE_EMAIL'] ?? 'noreply@artfolio.local');
define('IS_SSL', $protocol === 'https://');

// ========== PATH CONFIGURATION ==========
$doc_root = rtrim($_SERVER['DOCUMENT_ROOT'], '/\\');

define('ROOT_DIR', $doc_root);
define('APP_DIR', $doc_root . '/includes/');
define('UPLOAD_BASE', $doc_root . '/uploads/');
define('UPLOAD_URL', SITE_URL . 'uploads/');
define('GALLERY_UPLOAD_DIR', UPLOAD_BASE . 'gallery/');
define('GALLERY_UPLOAD_URL', UPLOAD_URL . 'gallery/');
define('PROFILE_UPLOAD_DIR', UPLOAD_BASE . 'profile/');
define('PROFILE_UPLOAD_URL', UPLOAD_URL . 'profile/');
define('LOG_DIR', $doc_root . '/logs/');

// ========== FILE UPLOAD LIMITS ==========
define('MAX_FILE_SIZE', isset($env['MAX_FILE_SIZE']) ? (int)$env['MAX_FILE_SIZE'] : 5242880); // 5MB
$extensions = isset($env['ALLOWED_EXTENSIONS']) ? explode(',', $env['ALLOWED_EXTENSIONS']) : ['jpg', 'jpeg', 'png', 'gif', 'webp'];
define('ALLOWED_EXTENSIONS', array_map('trim', $extensions));

// ========== SECURITY CONFIGURATION ==========
define('SESSION_LIFETIME', 86400 * 7);
define('PASSWORD_MIN_LENGTH', 6);
define('USERNAME_MIN_LENGTH', 3);
define('CSRF_TOKEN_LIFETIME', 3600);
define('MAX_LOGIN_ATTEMPTS', 5);
define('LOGIN_ATTEMPT_TIMEOUT', 900); // 15 minutes

// ========== TIMEZONE ==========
date_default_timezone_set($env['TIMEZONE'] ?? 'Asia/Ho_Chi_Minh');

// ========== ERROR REPORTING ==========
$is_local = in_array($_SERVER['HTTP_HOST'], ['localhost', '127.0.0.1', '::1']) ||
            strpos($_SERVER['HTTP_HOST'], '.local') !== false;

if ($is_local) {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
} else {
    // Production - Log errors, don't display
    error_reporting(E_ALL);
    ini_set('display_errors', 0);
    ini_set('display_startup_errors', 0);
    ini_set('log_errors', 1);
    
    // Set log file path
    if (!file_exists(LOG_DIR)) {
        @mkdir(LOG_DIR, 0755, true);
    }
    ini_set('error_log', LOG_DIR . 'error.log');
}

// ========== CREATE REQUIRED DIRECTORIES ==========
$required_dirs = [
    UPLOAD_BASE,
    GALLERY_UPLOAD_DIR,
    PROFILE_UPLOAD_DIR,
    LOG_DIR
];

foreach ($required_dirs as $dir) {
    if (!file_exists($dir)) {
        @mkdir($dir, 0755, true);
    }
    
    // Create .htaccess in upload directories
    if (strpos($dir, 'uploads/') !== false) {
        $htaccess_path = $dir . '.htaccess';
        if (!file_exists($htaccess_path)) {
            $htaccess_content = <<<'HTACCESS'
<FilesMatch "\.(jpg|jpeg|png|gif|webp|ico|svg)$">
    Order Allow,Deny
    Allow from all
</FilesMatch>
<FilesMatch "\.(php|php3|php4|php5|phtml|pl|py|jsp|asp|htm|shtml|sh|cgi|exe|bat|cmd)$">
    Order Deny,Allow
    Deny from all
</FilesMatch>
HTACCESS;
            @file_put_contents($htaccess_path, $htaccess_content);
        }
    }
}

// ========== INCLUDE REQUIRED FILES ==========
$required_files = [
    APP_DIR . 'database.php',
    APP_DIR . 'functions.php'
];

foreach ($required_files as $file) {
    if (file_exists($file)) {
        require_once $file;
    } else {
        error_log("Required file not found: $file");
        if (DEBUG_MODE) {
            die("System error: Required file missing - " . basename($file));
        }
    }
}

// ========== SECURITY HEADERS ==========
if (!headers_sent()) {
    // Frame protection
    header('X-Frame-Options: SAMEORIGIN');
    
    // MIME type protection
    header('X-Content-Type-Options: nosniff');
    
    // XSS protection
    header('X-XSS-Protection: 1; mode=block');
    
    // Referrer policy
    header('Referrer-Policy: strict-origin-when-cross-origin');
    
    // HSTS for HTTPS
    if (IS_SSL) {
        header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
    }
    
    // Relaxed CSP for compatibility (tighten in production)
    $csp = "default-src 'self'; script-src 'self' 'unsafe-inline' 'unsafe-eval' https: data:; style-src 'self' 'unsafe-inline' https:; img-src 'self' https: data:; font-src 'self' https: data:";
    header("Content-Security-Policy: $csp");
}

// ========== INITIALIZE SESSION VARIABLES ==========
if (!isset($_SESSION['errors'])) {
    $_SESSION['errors'] = [];
}

if (!isset($_SESSION['messages'])) {
    $_SESSION['messages'] = [];
}

if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// ========== REGISTER SHUTDOWN FUNCTION ==========
register_shutdown_function(function() {
    if (ob_get_level() > 0) {
        ob_end_flush();
    }
});

// ========== LOAD ENV VARIABLES IF AVAILABLE ==========
if (!empty($env)) {
    foreach ($env as $key => $value) {
        if (!defined($key)) {
            define($key, $value);
        }
    }
}
?>