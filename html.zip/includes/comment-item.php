<?php
// includes/comment-item.php
?>
<div class="comment-item" data-comment-id="<?php echo $comment['id']; ?>">
    <?php if (!empty($comment['avatar'])): ?>
        <img src="<?php echo UPLOAD_URL . 'profile/' . basename($comment['avatar']); ?>" 
             alt="<?php echo htmlspecialchars($comment['username']); ?>"
             class="comment-avatar">
    <?php else: ?>
        <div class="comment-avatar-initial">
            <?php echo strtoupper(substr($comment['username'], 0, 1)); ?>
        </div>
    <?php endif; ?>
    
    <div class="comment-content">
        <div class="comment-header">
            <span class="comment-author">
                <?php echo htmlspecialchars($comment['username']); ?>
            </span>
            <span class="comment-time">
                <?php echo get_time_ago($comment['created_at']); ?>
            </span>
        </div>
        
        <p class="comment-text"><?php echo nl2br(htmlspecialchars($comment['text'])); ?></p>
        
        <div class="comment-actions">
            <?php if ($isLoggedIn): ?>
                <?php
                // Check if liked comment
                $commentLiked = false;
                $commentLikeCheck = getRow(
                    "SELECT id FROM comment_likes WHERE user_id = ? AND comment_id = ? LIMIT 1",
                    [$currentUser['id'], $comment['id']]
                );
                $commentLiked = !empty($commentLikeCheck);
                ?>
                <span class="comment-action like-comment-btn <?php echo $commentLiked ? 'liked' : ''; ?>"
                      data-comment-id="<?php echo $comment['id']; ?>"
                      data-is-liked="<?php echo $commentLiked ? '1' : '0'; ?>">
                    <i class="fas fa-heart"></i>
                    <span><?php echo $comment['likes_count'] ?? 0; ?></span>
                </span>
                <span class="comment-action reply-comment-btn">
                    <i class="fas fa-reply"></i>
                    <span>Trả lời</span>
                </span>
            <?php else: ?>
                <span class="comment-action">
                    <i class="fas fa-heart"></i>
                    <span><?php echo $comment['likes_count'] ?? 0; ?></span>
                </span>
            <?php endif; ?>
        </div>

        <!-- Replies -->
        <?php if (!empty($comment['replies'])): ?>
            <div class="comment-reply">
                <?php foreach ($comment['replies'] as $reply): ?>
                    <div class="reply-item">
                        <?php if (!empty($reply['avatar'])): ?>
                            <img src="<?php echo UPLOAD_URL . 'profile/' . basename($reply['avatar']); ?>" 
                                 alt="<?php echo htmlspecialchars($reply['username']); ?>"
                                 class="reply-avatar">
                        <?php else: ?>
                            <div class="reply-avatar-initial">
                                <?php echo strtoupper(substr($reply['username'], 0, 1)); ?>
                            </div>
                        <?php endif; ?>
                        
                        <div class="comment-content">
                            <div class="comment-header">
                                <span class="comment-author">
                                    <?php echo htmlspecialchars($reply['username']); ?>
                                </span>
                                <span class="comment-time">
                                    <?php echo get_time_ago($reply['created_at']); ?>
                                </span>
                            </div>
                            <p class="comment-text"><?php echo nl2br(htmlspecialchars($reply['text'])); ?></p>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</div>