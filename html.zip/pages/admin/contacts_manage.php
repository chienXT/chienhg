<?php
require_once '../config.php';

if (!isAdmin()) {
    header('Location: login.php');
    exit;
}

// Xử lý actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $id = $_POST['id'] ?? 0;
    
    if ($action === 'delete' && $id) {
        try {
            $query = "DELETE FROM contacts WHERE id = :id";
            $stmt = $pdo->prepare($query);
            $stmt->execute([':id' => $id]);
            $_SESSION['success_message'] = 'Xóa contact thành công!';
        } catch (PDOException $e) {
            $_SESSION['error_message'] = 'Lỗi: ' . $e->getMessage();
        }
        header('Location: contacts_manage.php');
        exit;
    }
    
    if ($action === 'update_status' && $id) {
        $status = $_POST['status'] ?? 'pending';
        try {
            $query = "UPDATE contacts SET status = :status WHERE id = :id";
            $stmt = $pdo->prepare($query);
            $stmt->execute([':status' => $status, ':id' => $id]);
            $_SESSION['success_message'] = 'Cập nhật trạng thái thành công!';
        } catch (PDOException $e) {
            $_SESSION['error_message'] = 'Lỗi: ' . $e->getMessage();
        }
        header('Location: contacts_manage.php');
        exit;
    }
}

// Lấy danh sách contacts
try {
    $query = "SELECT * FROM contacts ORDER BY created_at DESC";
    $stmt = $pdo->prepare($query);
    $stmt->execute();
    $contacts = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $contacts = [];
    $error = $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quản Lý Contacts - ArtFolio Admin</title>
    <link rel="stylesheet" href="../../css/style.css">
    <style>
        .admin-container {
            max-width: 1400px;
            margin: 80px auto 40px;
            padding: 0 20px;
        }
        .admin-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            flex-wrap: wrap;
            gap: 15px;
        }
        .admin-nav {
            display: flex;
            gap: 15px;
            margin-bottom: 30px;
            flex-wrap: wrap;
        }
        .admin-nav a {
            padding: 10px 20px;
            background: #f0f0f0;
            border-radius: 8px;
            text-decoration: none;
            color: #333;
            transition: all 0.3s;
        }
        .admin-nav a.active, .admin-nav a:hover {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        .alert {
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .alert-error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        .stat-card {
            background: white;
            padding: 20px;
            border-radius: 15px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
            text-align: center;
        }
        .stat-number {
            font-size: 32px;
            font-weight: bold;
            color: #667eea;
        }
        .stat-label {
            color: #666;
            margin-top: 5px;
        }
        .contacts-list {
            background: white;
            border-radius: 15px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        .contact-item {
            padding: 25px;
            border-bottom: 1px solid #eee;
            transition: background 0.3s;
        }
        .contact-item:hover {
            background: #f9f9f9;
        }
        .contact-item:last-child {
            border-bottom: none;
        }
        .contact-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 15px;
            flex-wrap: wrap;
            gap: 15px;
        }
        .contact-info {
            flex: 1;
        }
        .contact-name {
            font-weight: bold;
            font-size: 18px;
            color: #333;
            margin-bottom: 5px;
        }
        .contact-email {
            color: #667eea;
            font-size: 14px;
            margin-bottom: 5px;
        }
        .contact-date {
            color: #999;
            font-size: 13px;
        }
        .contact-message {
            background: #f5f5f5;
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 15px;
            line-height: 1.6;
            color: #555;
        }
        .contact-actions {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }
        .status-badge {
            padding: 6px 15px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }
        .status-pending {
            background: #ffc107;
            color: #000;
        }
        .status-read {
            background: #17a2b8;
            color: white;
        }
        .status-replied {
            background: #28a745;
            color: white;
        }
        .action-btn {
            padding: 8px 16px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 13px;
            transition: all 0.3s;
        }
        .btn-read {
            background: #17a2b8;
            color: white;
        }
        .btn-replied {
            background: #28a745;
            color: white;
        }
        .btn-delete {
            background: #dc3545;
            color: white;
        }
        .action-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 10px rgba(0,0,0,0.2);
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <div class="admin-header">
            <h1>✉️ Quản Lý Contacts</h1>
            <div>
                <span>Xin chào, <?php echo htmlspecialchars($_SESSION['username']); ?></span>
                <a href="../../index.php" class="admin-btn" style="margin-left: 10px;">Về Trang Chủ</a>
                <a href="?logout" class="logout-btn" style="margin-left: 10px;">Đăng Xuất</a>
            </div>
        </div>

        <div class="admin-nav">
            <a href="dashboard.php">Dashboard</a>
            <a href="users.php">Users</a>
            <a href="gallery_manage.php">Gallery</a>
            <a href="contacts_manage.php" class="active">Contacts</a>
        </div>

        <?php if (isset($_SESSION['success_message'])): ?>
            <div class="alert alert-success">
                <?php 
                    echo htmlspecialchars($_SESSION['success_message']); 
                    unset($_SESSION['success_message']);
                ?>
            </div>
        <?php endif; ?>

        <?php if (isset($_SESSION['error_message'])): ?>
            <div class="alert alert-error">
                <?php 
                    echo htmlspecialchars($_SESSION['error_message']); 
                    unset($_SESSION['error_message']);
                ?>
            </div>
        <?php endif; ?>

        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-number"><?php echo count($contacts); ?></div>
                <div class="stat-label">Tổng Contacts</div>
            </div>
            <div class="stat-card">
                <div class="stat-number">
                    <?php echo count(array_filter($contacts, fn($c) => $c['status'] === 'pending')); ?>
                </div>
                <div class="stat-label">Chờ Xử Lý</div>
            </div>
            <div class="stat-card">
                <div class="stat-number">
                    <?php echo count(array_filter($contacts, fn($c) => $c['status'] === 'read')); ?>
                </div>
                <div class="stat-label">Đã Đọc</div>
            </div>
            <div class="stat-card">
                <div class="stat-number">
                    <?php echo count(array_filter($contacts, fn($c) => $c['status'] === 'replied')); ?>
                </div>
                <div class="stat-label">Đã Trả Lời</div>
            </div>
        </div>

        <?php if (empty($contacts)): ?>
            <div style="text-align: center; padding: 60px; background: white; border-radius: 15px;">
                <p style="color: #666; font-size: 18px;">Chưa có contact nào</p>
            </div>
        <?php else: ?>
            <div class="contacts-list">
                <?php foreach ($contacts as $contact): ?>
                    <div class="contact-item">
                        <div class="contact-header">
                            <div class="contact-info">
                                <div class="contact-name">
                                    <?php echo htmlspecialchars($contact['name']); ?>
                                    <span class="status-badge status-<?php echo $contact['status']; ?>">
                                        <?php 
                                            $status_labels = [
                                                'pending' => 'Chờ Xử Lý',
                                                'read' => 'Đã Đọc',
                                                'replied' => 'Đã Trả Lời'
                                            ];
                                            echo $status_labels[$contact['status']] ?? 'Unknown';
                                        ?>
                                    </span>
                                </div>
                                <div class="contact-email">📧 <?php echo htmlspecialchars($contact['email']); ?></div>
                                <div class="contact-date">📅 <?php echo date('d/m/Y H:i', strtotime($contact['created_at'])); ?></div>
                            </div>
                        </div>
                        
                        <div class="contact-message">
                            <strong>Tin nhắn:</strong><br>
                            <?php echo nl2br(htmlspecialchars($contact['message'])); ?>
                        </div>
                        
                        <div class="contact-actions">
                            <?php if ($contact['status'] !== 'read'): ?>
                                <form method="POST" style="display: inline;">
                                    <input type="hidden" name="action" value="update_status">
                                    <input type="hidden" name="id" value="<?php echo $contact['id']; ?>">
                                    <input type="hidden" name="status" value="read">
                                    <button type="submit" class="action-btn btn-read">✓ Đánh Dấu Đã Đọc</button>
                                </form>
                            <?php endif; ?>
                            
                            <?php if ($contact['status'] !== 'replied'): ?>
                                <form method="POST" style="display: inline;">
                                    <input type="hidden" name="action" value="update_status">
                                    <input type="hidden" name="id" value="<?php echo $contact['id']; ?>">
                                    <input type="hidden" name="status" value="replied">
                                    <button type="submit" class="action-btn btn-replied">✉️ Đã Trả Lời</button>
                                </form>
                            <?php endif; ?>
                            
                            <form method="POST" style="display: inline;" onsubmit="return confirm('Chắc chắn xóa contact này?');">
                                <input type="hidden" name="action" value="delete">
                                <input type="hidden" name="id" value="<?php echo $contact['id']; ?>">
                                <button type="submit" class="action-btn btn-delete">🗑️ Xóa</button>
                            </form>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>

    <?php
    if (isset($_GET['logout'])) {
        session_destroy();
        header('Location: login.php');
        exit;
    }
    ?>
</body>
</html>