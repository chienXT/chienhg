<?php
// Clear output buffer
if (ob_get_level()) {
    ob_end_clean();
}

require_once 'config.php';

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    try {
        $category = $_GET['category'] ?? '';
        
        if ($category && $category !== 'all') {
            $query = "SELECT * FROM gallery WHERE category = :category ORDER BY created_at DESC";
            $stmt = $pdo->prepare($query);
            $stmt->execute([':category' => $category]);
        } else {
            $query = "SELECT * FROM gallery ORDER BY created_at DESC";
            $stmt = $pdo->prepare($query);
            $stmt->execute();
        }
        
        $galleryItems = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo json_encode($galleryItems);
        exit;
        
    } catch (PDOException $e) {
        error_log("Gallery fetch error: " . $e->getMessage());
        echo json_encode([]);
        exit;
    }
}

// Thêm item mới (chỉ admin)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isAdmin()) {
    try {
        $data = json_decode(file_get_contents("php://input"), true);
        
        $title = $data['title'] ?? '';
        $description = $data['description'] ?? '';
        $image_url = $data['image_url'] ?? '';
        $category = $data['category'] ?? '';
        $tags = $data['tags'] ?? '';
        
        if (empty($title) || empty($category)) {
            echo json_encode([
                'success' => false,
                'message' => 'Vui lòng điền đầy đủ thông tin'
            ]);
            exit;
        }
        
        $query = "INSERT INTO gallery (title, description, image_url, category, tags, created_at) 
                  VALUES (:title, :description, :image_url, :category, :tags, NOW())";
        $stmt = $pdo->prepare($query);
        
        if ($stmt->execute([
            ':title' => $title,
            ':description' => $description,
            ':image_url' => $image_url,
            ':category' => $category,
            ':tags' => $tags
        ])) {
            echo json_encode([
                'success' => true,
                'message' => 'Thêm tác phẩm thành công'
            ]);
            exit;
        } else {
            echo json_encode([
                'success' => false,
                'message' => 'Có lỗi xảy ra khi thêm tác phẩm'
            ]);
            exit;
        }
        
    } catch (PDOException $e) {
        error_log("Gallery insert error: " . $e->getMessage());
        echo json_encode([
            'success' => false,
            'message' => 'Lỗi hệ thống'
        ]);
        exit;
    }
}
?>