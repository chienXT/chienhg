<?php
// pages/image-detail.php - COMPLETE FIX
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Include config với path tuyệt đối
require_once dirname(__DIR__) . '/includes/config.php';

// Get image ID
$image_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($image_id <= 0) {
    header('Location: ' . BASE_URL);
    exit;
}

// User info
$isLoggedIn = isset($_SESSION['user_id']);
$currentUserId = $_SESSION['user_id'] ?? 0;

// Initialize
$imageData = null;
$isLiked = false;
$comments = [];
$relatedImages = [];

try {
    // Get image data with author info
    $sql = "SELECT 
        a.*,
        u.id as author_id,
        u.username as author_username,
        u.avatar as author_avatar,
        u.role as author_role,
        (SELECT COUNT(*) FROM artworks WHERE user_id = u.id AND is_public = 1) as author_artworks_count
    FROM artworks a
    LEFT JOIN users u ON a.user_id = u.id
    WHERE a.id = ? AND a.is_public = 1
    LIMIT 1";
    
    $imageData = getRow($sql, [$image_id]);
    
    if (!$imageData) {
        header('Location: ' . BASE_URL);
        exit;
    }
    
    // Update views
    executeQuery("UPDATE artworks SET views = views + 1 WHERE id = ?", [$image_id]);
    
    // Check if user liked
    if ($isLoggedIn) {
        $like = getRow("SELECT id FROM likes WHERE user_id = ? AND image_id = ?", [$currentUserId, $image_id]);
        $isLiked = !empty($like);
    }
    
    // Get comments
    $comments = getAll("SELECT c.*, u.username, u.avatar 
        FROM comments c
        LEFT JOIN users u ON c.user_id = u.id
        WHERE c.image_id = ? AND c.status = 'approved'
        ORDER BY c.created_at DESC
        LIMIT 50", [$image_id]);
    
    // Get related images (same category or author)
    $relatedImages = getAll("SELECT a.*, u.username 
        FROM artworks a
        LEFT JOIN users u ON a.user_id = u.id
        WHERE a.id != ? 
        AND a.is_public = 1 
        AND (a.category = ? OR a.user_id = ?)
        ORDER BY RAND()
        LIMIT 6", [$image_id, $imageData['category'], $imageData['author_id']]);
    
} catch (Exception $e) {
    error_log('Image detail error: ' . $e->getMessage());
    header('Location: ' . BASE_URL);
    exit;
}

$pageTitle = htmlspecialchars($imageData['title']) . ' - ' . SITE_NAME;
$tags = !empty($imageData['tags']) ? explode(',', $imageData['tags']) : [];

// Get image URL
$imageUrl = '';
if (!empty($imageData['image_path'])) {
    if (strpos($imageData['image_path'], 'http') === 0) {
        $imageUrl = $imageData['image_path'];
    } else {
        $imageUrl = GALLERY_UPLOAD_URL . basename($imageData['image_path']);
    }
}

// Time ago
function timeAgo($datetime) {
    $time = strtotime($datetime);
    $diff = time() - $time;
    if ($diff < 60) return 'Vừa xong';
    if ($diff < 3600) return floor($diff/60) . ' phút trước';
    if ($diff < 86400) return floor($diff/3600) . ' giờ trước';
    if ($diff < 604800) return floor($diff/86400) . ' ngày trước';
    return date('d/m/Y', $time);
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle; ?></title>
    <meta name="description" content="<?php echo htmlspecialchars(substr($imageData['description'], 0, 160)); ?>">
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .detail-container {
            max-width: 1400px;
            margin: 100px auto 40px;
            padding: 0 20px;
        }
        .detail-grid {
            display: grid;
            grid-template-columns: 1fr 350px;
            gap: 30px;
        }
        @media (max-width: 768px) {
            .detail-grid {
                grid-template-columns: 1fr;
            }
        }
        .image-box {
            background: white;
            border-radius: 12px;
            padding: 20px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        .main-image {
            width: 100%;
            height: auto;
            border-radius: 8px;
            display: block;
        }
        .placeholder-img {
            width: 100%;
            height: 500px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 64px;
            font-weight: bold;
            border-radius: 8px;
        }
        .info-box {
            background: white;
            border-radius: 12px;
            padding: 30px;
            margin-top: 20px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        .info-box h1 {
            font-size: 32px;
            margin-bottom: 15px;
            color: #333;
        }
        .meta-info {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            margin-bottom: 20px;
            color: #666;
            font-size: 14px;
        }
        .meta-info span {
            display: flex;
            align-items: center;
            gap: 5px;
        }
        .description {
            line-height: 1.8;
            color: #555;
            margin-bottom: 20px;
        }
        .tags {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
        }
        .tag {
            background: #f0f0f0;
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 14px;
            color: #666;
        }
        .sidebar {
            display: flex;
            flex-direction: column;
            gap: 20px;
        }
        .author-card {
            background: white;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        .author-info {
            display: flex;
            align-items: center;
            gap: 15px;
            margin-bottom: 20px;
            text-decoration: none;
            color: inherit;
        }
        .author-avatar {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            object-fit: cover;
        }
        .avatar-placeholder {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 24px;
            font-weight: bold;
        }
        .author-stats {
            text-align: center;
            padding: 15px 0;
            border-top: 1px solid #eee;
            margin-bottom: 15px;
        }
        .stat-number {
            display: block;
            font-size: 20px;
            font-weight: bold;
            color: #333;
        }
        .stat-label {
            font-size: 13px;
            color: #666;
        }
        .action-btn {
            width: 100%;
            padding: 12px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            transition: all 0.3s;
        }
        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
        }
        .btn-secondary {
            background: white;
            border: 1px solid #ddd;
            color: #333;
        }
        .btn-secondary:hover {
            background: #f8f9fa;
        }
        .btn-liked {
            background: #ff4757;
            color: white;
        }
        .actions-card {
            background: white;
            padding: 20px;
            border-radius: 12px;
            display: flex;
            flex-direction: column;
            gap: 10px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        .comments-section {
            background: white;
            border-radius: 12px;
            padding: 30px;
            margin-top: 20px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        .comment-form {
            margin-bottom: 30px;
        }
        .comment-textarea {
            width: 100%;
            min-height: 100px;
            padding: 15px;
            border: 1px solid #ddd;
            border-radius: 8px;
            resize: vertical;
            font-family: inherit;
            margin-bottom: 10px;
        }
        .comment-item {
            display: flex;
            gap: 15px;
            padding: 15px;
            background: #f8f9fa;
            border-radius: 8px;
            margin-bottom: 15px;
        }
        .comment-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            flex-shrink: 0;
        }
        .comment-content {
            flex: 1;
        }
        .comment-header {
            display: flex;
            justify-content: space-between;
            margin-bottom: 8px;
        }
        .related-section {
            margin-top: 40px;
        }
        .related-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }
        .related-item {
            position: relative;
            border-radius: 8px;
            overflow: hidden;
            cursor: pointer;
            transition: transform 0.3s;
        }
        .related-item:hover {
            transform: translateY(-5px);
        }
        .related-item img {
            width: 100%;
            height: 200px;
            object-fit: cover;
        }
    </style>
</head>
<body>
    <?php include dirname(__DIR__) . '/includes/header.php'; ?>

    <div class="detail-container">
        <div class="detail-grid">
            <!-- Main Content -->
            <div class="main-content">
                <!-- Image -->
                <div class="image-box">
                    <?php if (!empty($imageUrl)): ?>
                        <img src="<?php echo htmlspecialchars($imageUrl); ?>" 
                             alt="<?php echo htmlspecialchars($imageData['title']); ?>"
                             class="main-image"
                             onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
                        <div class="placeholder-img" style="display:none;">
                            <?php echo strtoupper(substr($imageData['title'], 0, 2)); ?>
                        </div>
                    <?php else: ?>
                        <div class="placeholder-img">
                            <?php echo strtoupper(substr($imageData['title'], 0, 2)); ?>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Info -->
                <div class="info-box">
                    <h1><?php echo htmlspecialchars($imageData['title']); ?></h1>
                    
                    <div class="meta-info">
                        <span><i class="fas fa-eye"></i> <?php echo number_format($imageData['views']); ?></span>
                        <span><i class="fas fa-heart"></i> <?php echo number_format($imageData['likes']); ?></span>
                        <span><i class="fas fa-comment"></i> <?php echo count($comments); ?></span>
                        <span><i class="fas fa-calendar"></i> <?php echo date('d/m/Y', strtotime($imageData['created_at'])); ?></span>
                        <span><i class="fas fa-folder"></i> <?php echo ucfirst($imageData['category']); ?></span>
                    </div>

                    <?php if (!empty($imageData['description'])): ?>
                        <p class="description"><?php echo nl2br(htmlspecialchars($imageData['description'])); ?></p>
                    <?php endif; ?>

                    <?php if (!empty($tags)): ?>
                        <div class="tags">
                            <?php foreach ($tags as $tag): ?>
                                <span class="tag">#<?php echo htmlspecialchars(trim($tag)); ?></span>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Comments -->
                <div class="comments-section">
                    <h2>Bình luận (<?php echo count($comments); ?>)</h2>
                    
                    <?php if ($isLoggedIn): ?>
                        <form class="comment-form" id="commentForm">
                            <textarea name="comment" class="comment-textarea" 
                                placeholder="Viết bình luận của bạn..." 
                                required minlength="5"></textarea>
                            <button type="submit" class="action-btn btn-primary">
                                <i class="fas fa-paper-plane"></i> Gửi bình luận
                            </button>
                        </form>
                    <?php else: ?>
                        <div style="text-align: center; padding: 30px; background: #f8f9fa; border-radius: 8px; margin-bottom: 30px;">
                            <p style="margin-bottom: 15px;">Đăng nhập để bình luận</p>
                            <button onclick="openLoginModal()" class="action-btn btn-primary" style="max-width: 200px; margin: 0 auto;">
                                Đăng nhập
                            </button>
                        </div>
                    <?php endif; ?>

                    <?php if (empty($comments)): ?>
                        <p style="text-align: center; padding: 40px; color: #999;">
                            <i class="fas fa-comment-slash" style="font-size: 48px; margin-bottom: 10px; display: block;"></i>
                            Chưa có bình luận nào
                        </p>
                    <?php else: ?>
                        <?php foreach ($comments as $comment): ?>
                            <div class="comment-item">
                                <?php if (!empty($comment['avatar'])): ?>
                                    <img src="<?php echo PROFILE_UPLOAD_URL . basename($comment['avatar']); ?>" 
                                         class="comment-avatar"
                                         alt="<?php echo htmlspecialchars($comment['username']); ?>">
                                <?php else: ?>
                                    <div class="avatar-placeholder" style="width: 40px; height: 40px; font-size: 16px;">
                                        <?php echo strtoupper(substr($comment['username'], 0, 1)); ?>
                                    </div>
                                <?php endif; ?>
                                <div class="comment-content">
                                    <div class="comment-header">
                                        <strong><?php echo htmlspecialchars($comment['username']); ?></strong>
                                        <span style="font-size: 12px; color: #999;">
                                            <?php echo timeAgo($comment['created_at']); ?>
                                        </span>
                                    </div>
                                    <p><?php echo nl2br(htmlspecialchars($comment['text'])); ?></p>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>

                <!-- Related Images -->
                <?php if (!empty($relatedImages)): ?>
                <div class="related-section">
                    <h2>Tác phẩm liên quan</h2>
                    <div class="related-grid">
                        <?php foreach ($relatedImages as $related): ?>
                            <a href="<?php echo BASE_URL; ?>pages/image-detail.php?id=<?php echo $related['id']; ?>" class="related-item">
                                <?php 
                                $relatedUrl = '';
                                if (!empty($related['image_path'])) {
                                    if (strpos($related['image_path'], 'http') === 0) {
                                        $relatedUrl = $related['image_path'];
                                    } else {
                                        $relatedUrl = GALLERY_UPLOAD_URL . basename($related['image_path']);
                                    }
                                }
                                ?>
                                <?php if ($relatedUrl): ?>
                                    <img src="<?php echo htmlspecialchars($relatedUrl); ?>" alt="<?php echo htmlspecialchars($related['title']); ?>">
                                <?php else: ?>
                                    <div style="width: 100%; height: 200px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); display: flex; align-items: center; justify-content: center; color: white; font-size: 32px; font-weight: bold;">
                                        <?php echo strtoupper(substr($related['title'], 0, 2)); ?>
                                    </div>
                                <?php endif; ?>
                                <div style="position: absolute; bottom: 0; left: 0; right: 0; padding: 10px; background: linear-gradient(transparent, rgba(0,0,0,0.7)); color: white;">
                                    <div style="font-size: 14px; font-weight: bold;"><?php echo htmlspecialchars($related['title']); ?></div>
                                    <div style="font-size: 12px; opacity: 0.9;"><?php echo htmlspecialchars($related['username']); ?></div>
                                </div>
                            </a>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endif; ?>
            </div>

            <!-- Sidebar -->
            <aside class="sidebar">
                <!-- Author Card -->
                <div class="author-card">
                    <a href="<?php echo BASE_URL; ?>pages/profile.php?id=<?php echo $imageData['author_id']; ?>" class="author-info">
                        <?php if (!empty($imageData['author_avatar'])): ?>
                            <img src="<?php echo PROFILE_UPLOAD_URL . basename($imageData['author_avatar']); ?>" 
                                 class="author-avatar"
                                 alt="<?php echo htmlspecialchars($imageData['author_username']); ?>">
                        <?php else: ?>
                            <div class="avatar-placeholder">
                                <?php echo strtoupper(substr($imageData['author_username'], 0, 1)); ?>
                            </div>
                        <?php endif; ?>
                        <div>
                            <h3 style="margin: 0 0 5px 0; font-size: 18px;">
                                <?php echo htmlspecialchars($imageData['author_username']); ?>
                            </h3>
                            <span style="font-size: 14px; color: #666;">
                                <?php echo $imageData['author_role'] === 'artist' ? '🎨 Nghệ sĩ' : '👤 Thành viên'; ?>
                            </span>
                        </div>
                    </a>
                    
                    <div class="author-stats">
                        <span class="stat-number"><?php echo number_format($imageData['author_artworks_count']); ?></span>
                        <span class="stat-label">Tác phẩm</span>
                    </div>

                    <?php if ($isLoggedIn && $currentUserId != $imageData['author_id']): ?>
                        <button onclick="followUser(<?php echo $imageData['author_id']; ?>)" class="action-btn btn-primary">
                            <i class="fas fa-user-plus"></i> Theo dõi
                        </button>
                    <?php endif; ?>
                </div>

                <!-- Actions Card -->
                <div class="actions-card">
                    <?php if ($isLoggedIn): ?>
                        <button id="likeBtn" class="action-btn <?php echo $isLiked ? 'btn-liked' : 'btn-secondary'; ?>">
                            <i class="fas fa-heart"></i> <?php echo $isLiked ? 'Đã thích' : 'Thích'; ?>
                        </button>
                    <?php endif; ?>
                    
                    <button onclick="shareImage()" class="action-btn btn-secondary">
                        <i class="fas fa-share-alt"></i> Chia sẻ
                    </button>
                    
                    <?php if (!empty($imageUrl)): ?>
                    <button onclick="downloadImage()" class="action-btn btn-secondary">
                        <i class="fas fa-download"></i> Tải xuống
                    </button>
                    <?php endif; ?>
                    
                    <?php if ($isLoggedIn && $currentUserId == $imageData['user_id']): ?>
                    <button onclick="deleteImage()" class="action-btn" style="background: #ff4757; color: white;">
                        <i class="fas fa-trash"></i> Xóa
                    </button>
                    <?php endif; ?>
                </div>
            </aside>
        </div>
    </div>

    <?php include dirname(__DIR__) . '/includes/footer.php'; ?>

    <script>
    const imageId = <?php echo $image_id; ?>;
    const isLoggedIn = <?php echo $isLoggedIn ? 'true' : 'false'; ?>;
    const BASE_URL = '<?php echo BASE_URL; ?>';
    const imageUrl = '<?php echo addslashes($imageUrl); ?>';

    // Like/Unlike
    document.getElementById('likeBtn')?.addEventListener('click', async function() {
        try {
            const response = await fetch(BASE_URL + 'api/like.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({image_id: imageId})
            });
            
            const data = await response.json();
            if (data.success) {
                const isLiked = data.action === 'liked';
                this.className = 'action-btn ' + (isLiked ? 'btn-liked' : 'btn-secondary');
                this.innerHTML = '<i class="fas fa-heart"></i> ' + (isLiked ? 'Đã thích' : 'Thích');
            } else {
                alert(data.message || 'Có lỗi xảy ra');
            }
        } catch (error) {
            console.error('Like error:', error);
            alert('Không thể kết nối đến server');
        }
    });

    // Share
    function shareImage() {
        if (navigator.share) {
            navigator.share({
                title: document.title,
                url: window.location.href
            }).catch(err => console.log('Share error:', err));
        } else {
            navigator.clipboard.writeText(window.location.href);
            alert('Đã copy link vào clipboard!');
        }
    }

    // Download
    function downloadImage() {
        if (!imageUrl) {
            alert('Không có ảnh để tải');
            return;
        }
        const link = document.createElement('a');
        link.href = imageUrl;
        link.download = 'artwork-<?php echo $image_id; ?>.jpg';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }

    // Follow
    function followUser(userId) {
        alert('Chức năng theo dõi đang được phát triển');
    }

    // Delete
    function deleteImage() {
        if (!confirm('Bạn có chắc muốn xóa tác phẩm này?')) return;
        
        fetch(BASE_URL + 'api/delete-image.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({image_id: imageId})
        })
        .then(r => r.json())
        .then(data => {
            if (data.success) {
                alert('Đã xóa thành công!');
                window.location.href = BASE_URL;
            } else {
                alert(data.message || 'Lỗi xóa ảnh');
            }
        })
        .catch(err => {
            console.error(err);
            alert('Không thể xóa');
        });
    }

    // Comment
    document.getElementById('commentForm')?.addEventListener('submit', async function(e) {
        e.preventDefault();
        
        const formData = new FormData(this);
        formData.append('image_id', imageId);
        
        try {
            const response = await fetch(BASE_URL + 'api/comment.php', {
                method: 'POST',
                body: formData
            });
            
            const data = await response.json();
            if (data.success) {
                alert('Bình luận đã được gửi!');
                location.reload();
            } else {
                alert(data.message || 'Không thể gửi bình luận');
            }
        } catch (error) {
            console.error('Comment error:', error);
            alert('Không thể gửi bình luận');
        }
    });

    // Login modal function
    function openLoginModal() {
        // If you have a login modal, open it
        // Otherwise redirect to login page
        window.location.href = BASE_URL + 'pages/auth/login.php';
    }
    </script>
</body>
</html>