<?php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/session.php';
require_once __DIR__ . '/../../includes/functions.php';

// Kiểm tra đăng nhập
if (!isset($_SESSION['user_id'])) {
    header('Location: /pages/auth/login.php');
    exit();
}

$pageTitle = 'Upload Tác Phẩm - ArtFolio';
$cssFiles = ['/assets/css/modals.css', '/assets/css/gallery.css'];
$jsFiles = ['/assets/js/upload.js'];

include __DIR__ . '/../../includes/header.php';
?>

<div class="page-header">
    <div class="container">
        <h1>📤 Upload Tác Phẩm Mới</h1>
        <p>Chia sẻ tác phẩm nghệ thuật của bạn với cộng đồng</p>
    </div>
</div>

<div class="container" style="padding: 50px 0;">
    <div class="upload-form-container">
        <div class="form-card">
            <form id="uploadForm" enctype="multipart/form-data">
                <div class="form-section">
                    <h3><span>🖼️</span> Hình Ảnh Tác Phẩm</h3>
                    
                    <div class="upload-tabs">
                        <button type="button" class="tab-btn active" data-tab="url">URL Hình Ảnh</button>
                        <button type="button" class="tab-btn" data-tab="file">Upload File</button>
                    </div>
                    
                    <div class="tab-content active" data-tab-content="url">
                        <div class="form-group">
                            <label for="upload_image_url">URL Hình Ảnh *</label>
                            <input type="url" id="upload_image_url" name="image_url" 
                                   placeholder="https://example.com/your-artwork.jpg"
                                   class="form-control">
                            <small class="form-text">Nhập URL của hình ảnh từ internet</small>
                        </div>
                    </div>
                    
                    <div class="tab-content" data-tab-content="file">
                        <div class="form-group">
                            <label for="upload_image_file">Chọn Ảnh Từ Thiết Bị *</label>
                            <div class="file-upload-area" id="fileUploadArea">
                                <input type="file" id="upload_image_file" name="image_file" 
                                       accept="image/*" style="display: none;">
                                <div class="file-upload-placeholder">
                                    <span style="font-size: 48px;">📷</span>
                                    <p>Click để chọn ảnh hoặc kéo thả vào đây</p>
                                    <small>Hỗ trợ: JPG, PNG, GIF (Tối đa 5MB)</small>
                                </div>
                                <div class="file-preview" id="filePreview" style="display: none;">
                                    <img id="previewImage" alt="Preview">
                                    <button type="button" class="remove-preview" id="removePreview">✕</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="form-section">
                    <h3><span>📝</span> Thông Tin Tác Phẩm</h3>
                    
                    <div class="form-group">
                        <label for="upload_title">Tiêu Đề *</label>
                        <input type="text" id="upload_title" name="title" 
                               placeholder="Ví dụ: Hoàng hôn trên biển" required
                               class="form-control">
                    </div>
                    
                    <div class="form-group">
                        <label for="upload_description">Mô Tả Chi Tiết</label>
                        <textarea id="upload_description" name="description" 
                                  rows="4" placeholder="Mô tả về tác phẩm, ý tưởng, cảm hứng..."
                                  class="form-control"></textarea>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="upload_category">Danh Mục *</label>
                            <select id="upload_category" name="category" required class="form-control">
                                <option value="">-- Chọn danh mục --</option>
                                <option value="painting">Tranh Sơn Dầu</option>
                                <option value="digital">Nghệ Thuật Số</option>
                                <option value="photography">Nhiếp Ảnh</option>
                                <option value="sculpture">Điêu Khắc</option>
                                <option value="illustration">Minh Họa</option>
                                <option value="other">Khác</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="upload_tags">Tags (Từ khóa)</label>
                            <input type="text" id="upload_tags" name="tags"
                                   placeholder="art, painting, landscape"
                                   class="form-control">
                            <small class="form-text">Phân cách bằng dấu phẩy</small>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="upload_price">Giá (nếu có)</label>
                        <div class="input-with-symbol">
                            <span class="input-symbol">₫</span>
                            <input type="number" id="upload_price" name="price"
                                   placeholder="0" min="0" step="1000"
                                   class="form-control">
                        </div>
                    </div>
                </div>
                
                <div class="form-section">
                    <h3><span>🔒</span> Quyền Riêng Tư</h3>
                    
                    <div class="form-group">
                        <label class="checkbox-label">
                            <input type="checkbox" id="upload_public" name="is_public" checked>
                            <span class="checkmark"></span>
                            Công khai tác phẩm
                        </label>
                        <small class="form-text">Tác phẩm sẽ hiển thị với mọi người</small>
                    </div>
                    
                    <div class="form-group">
                        <label class="checkbox-label">
                            <input type="checkbox" id="upload_for_sale" name="for_sale">
                            <span class="checkmark"></span>
                            Cho phép mua bán
                        </label>
                        <small class="form-text">Người khác có thể liên hệ để mua tác phẩm</small>
                    </div>
                </div>
                
                <div class="form-actions">
                    <button type="button" class="btn btn-secondary" onclick="window.history.back()">
                        ← Quay lại
                    </button>
                    <button type="submit" class="btn btn-primary" id="uploadSubmitBtn">
                        <span class="btn-loading" style="display: none;"></span>
                        <span class="btn-text">Upload Tác Phẩm</span>
                    </button>
                </div>
            </form>
        </div>
        
        <div class="upload-guide">
            <h4>📋 Hướng dẫn Upload</h4>
            <ul>
                <li>Ảnh nên có độ phân giải cao, chất lượng tốt</li>
                <li>Tiêu đề rõ ràng, mô tả chi tiết về tác phẩm</li>
                <li>Chọn đúng danh mục để dễ tìm kiếm</li>
                <li>Thêm tags liên quan để tăng khả năng hiển thị</li>
                <li>Kiểm tra kỹ thông tin trước khi upload</li>
            </ul>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Tab switching
    const tabBtns = document.querySelectorAll('.tab-btn');
    const tabContents = document.querySelectorAll('.tab-content');
    
    tabBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            const tabId = this.dataset.tab;
            
            // Update active tab button
            tabBtns.forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            
            // Show corresponding content
            tabContents.forEach(content => {
                content.classList.remove('active');
                if (content.dataset.tabContent === tabId) {
                    content.classList.add('active');
                }
            });
        });
    });
    
    // File upload preview
    const fileInput = document.getElementById('upload_image_file');
    const fileUploadArea = document.getElementById('fileUploadArea');
    const filePreview = document.getElementById('filePreview');
    const previewImage = document.getElementById('previewImage');
    const removePreviewBtn = document.getElementById('removePreview');
    
    fileUploadArea.addEventListener('click', function() {
        fileInput.click();
    });
    
    fileUploadArea.addEventListener('dragover', function(e) {
        e.preventDefault();
        this.style.borderColor = 'var(--primary-color)';
        this.style.background = 'rgba(102, 126, 234, 0.05)';
    });
    
    fileUploadArea.addEventListener('dragleave', function() {
        this.style.borderColor = '#ddd';
        this.style.background = '';
    });
    
    fileUploadArea.addEventListener('drop', function(e) {
        e.preventDefault();
        this.style.borderColor = '#ddd';
        this.style.background = '';
        
        if (e.dataTransfer.files.length) {
            handleFileSelect(e.dataTransfer.files[0]);
        }
    });
    
    fileInput.addEventListener('change', function(e) {
        if (this.files.length) {
            handleFileSelect(this.files[0]);
        }
    });
    
    function handleFileSelect(file) {
        if (!file.type.match('image.*')) {
            alert('Vui lòng chọn file hình ảnh!');
            return;
        }
        
        if (file.size > 5 * 1024 * 1024) {
            alert('File quá lớn! Vui lòng chọn file nhỏ hơn 5MB.');
            return;
        }
        
        const reader = new FileReader();
        reader.onload = function(e) {
            previewImage.src = e.target.result;
            filePreview.style.display = 'block';
            fileUploadArea.querySelector('.file-upload-placeholder').style.display = 'none';
        };
        reader.readAsDataURL(file);
    }
    
    removePreviewBtn.addEventListener('click', function(e) {
        e.stopPropagation();
        filePreview.style.display = 'none';
        fileUploadArea.querySelector('.file-upload-placeholder').style.display = 'block';
        fileInput.value = '';
    });
    
    // Form submission
    const uploadForm = document.getElementById('uploadForm');
    const submitBtn = document.getElementById('uploadSubmitBtn');
    const btnText = submitBtn.querySelector('.btn-text');
    const btnLoading = submitBtn.querySelector('.btn-loading');
    
    uploadForm.addEventListener('submit', async function(e) {
        e.preventDefault();
        
        // Validation
        const title = document.getElementById('upload_title').value.trim();
        const category = document.getElementById('upload_category').value;
        const imageUrl = document.getElementById('upload_image_url').value.trim();
        const imageFile = document.getElementById('upload_image_file').files[0];
        
        if (!title) {
            alert('Vui lòng nhập tiêu đề tác phẩm');
            return;
        }
        
        if (!category) {
            alert('Vui lòng chọn danh mục');
            return;
        }
        
        // Check if either URL or file is provided
        const currentTab = document.querySelector('.tab-btn.active').dataset.tab;
        if (currentTab === 'url' && !imageUrl) {
            alert('Vui lòng nhập URL hình ảnh');
            return;
        }
        
        if (currentTab === 'file' && !imageFile) {
            alert('Vui lòng chọn file hình ảnh');
            return;
        }
        
        // Show loading
        submitBtn.disabled = true;
        btnText.style.display = 'none';
        btnLoading.style.display = 'inline-block';
        
        try {
            const formData = new FormData();
            formData.append('title', title);
            formData.append('description', document.getElementById('upload_description').value.trim());
            formData.append('category', category);
            formData.append('tags', document.getElementById('upload_tags').value.trim());
            formData.append('price', document.getElementById('upload_price').value);
            formData.append('is_public', document.getElementById('upload_public').checked ? '1' : '0');
            formData.append('for_sale', document.getElementById('upload_for_sale').checked ? '1' : '0');
            
            if (currentTab === 'url') {
                formData.append('image_url', imageUrl);
            } else {
                formData.append('image_file', imageFile);
            }
            
            const response = await fetch('/api/upload.php', {
                method: 'POST',
                body: formData,
                credentials: 'same-origin'
            });
            
            const result = await response.json();
            
            if (result.success) {
                alert('Upload thành công!');
                window.location.href = '/pages/gallery/';
            } else {
                alert('Upload thất bại: ' + (result.message || 'Lỗi không xác định'));
            }
        } catch (error) {
            console.error('Upload error:', error);
            alert('Đã xảy ra lỗi khi upload. Vui lòng thử lại.');
        } finally {
            // Hide loading
            submitBtn.disabled = false;
            btnText.style.display = 'inline-block';
            btnLoading.style.display = 'none';
        }
    });
});
</script>

<style>
.page-header {
    background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
    color: white;
    padding: 80px 0 60px;
    text-align: center;
    margin-top: 70px;
}

.page-header h1 {
    font-size: 42px;
    margin-bottom: 15px;
}

.page-header p {
    font-size: 18px;
    opacity: 0.9;
    max-width: 600px;
    margin: 0 auto;
}

.upload-form-container {
    display: grid;
    grid-template-columns: 2fr 1fr;
    gap: 40px;
    margin-top: -40px;
}

@media (max-width: 992px) {
    .upload-form-container {
        grid-template-columns: 1fr;
    }
}

.form-card {
    background: white;
    border-radius: var(--border-radius);
    box-shadow: var(--shadow-hover);
    padding: 40px;
}

.form-section {
    margin-bottom: 40px;
    padding-bottom: 40px;
    border-bottom: 1px solid #eee;
}

.form-section:last-child {
    border-bottom: none;
    margin-bottom: 0;
}

.form-section h3 {
    font-size: 20px;
    color: var(--text-color);
    margin-bottom: 25px;
    display: flex;
    align-items: center;
    gap: 10px;
}

.form-row {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 20px;
}

@media (max-width: 768px) {
    .form-row {
        grid-template-columns: 1fr;
    }
}

.form-control {
    width: 100%;
    padding: 12px 16px;
    border: 1px solid #ddd;
    border-radius: var(--border-radius);
    font-size: 15px;
    transition: var(--transition);
}

.form-control:focus {
    outline: none;
    border-color: var(--primary-color);
    box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
}

.form-text {
    display: block;
    margin-top: 6px;
    color: #666;
    font-size: 13px;
}

.input-with-symbol {
    position: relative;
}

.input-symbol {
    position: absolute;
    left: 12px;
    top: 50%;
    transform: translateY(-50%);
    color: #666;
}

.input-with-symbol .form-control {
    padding-left: 30px;
}

.checkbox-label {
    display: flex;
    align-items: center;
    cursor: pointer;
    font-weight: 500;
    margin-bottom: 5px;
}

.checkbox-label input {
    margin-right: 10px;
    width: 18px;
    height: 18px;
}

.form-actions {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-top: 40px;
    padding-top: 30px;
    border-top: 1px solid #eee;
}

.btn {
    padding: 14px 32px;
    border-radius: var(--border-radius);
    font-size: 16px;
    font-weight: 600;
    cursor: pointer;
    transition: var(--transition);
    border: none;
}

.btn-primary {
    background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
    color: white;
    min-width: 180px;
}

.btn-primary:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 25px rgba(102, 126, 234, 0.3);
}

.btn-secondary {
    background: #f8f9fa;
    color: var(--text-color);
    border: 1px solid #ddd;
}

.btn-secondary:hover {
    background: #e9ecef;
}

.btn-loading {
    display: inline-block;
    width: 20px;
    height: 20px;
    border: 2px solid rgba(255, 255, 255, 0.3);
    border-top-color: white;
    border-radius: 50%;
    animation: spin 1s linear infinite;
}

.upload-guide {
    background: white;
    border-radius: var(--border-radius);
    box-shadow: var(--shadow-hover);
    padding: 30px;
    height: fit-content;
    position: sticky;
    top: 100px;
}

.upload-guide h4 {
    color: var(--primary-color);
    margin-bottom: 20px;
    font-size: 18px;
    display: flex;
    align-items: center;
    gap: 10px;
}

.upload-guide ul {
    list-style: none;
    padding: 0;
}

.upload-guide li {
    padding: 10px 0;
    border-bottom: 1px solid #f5f5f5;
    color: var(--text-light);
    display: flex;
    align-items: flex-start;
    gap: 10px;
}

.upload-guide li:last-child {
    border-bottom: none;
}
</style>

<?php
include __DIR__ . '/../../includes/footer.php';
?>