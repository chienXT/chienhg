<?php
// sections/contact.php
?>

<section id="contact" class="section">
    <div class="container">
        <div style="text-align: center; margin-bottom: 50px;">
            <h2 class="section-title">Liên Hệ Với Chúng Tôi</h2>
            <p class="section-subtitle">Có câu hỏi? Chúng tôi sẵn sàng lắng nghe. Gửi tin nhắn cho chúng tôi ngay hôm nay!</p>
        </div>

        <div class="contact-wrapper">
            <!-- Contact Info -->
            <div class="contact-info">
                <div class="info-card">
                    <div class="info-icon">
                        <i class="fas fa-map-marker-alt"></i>
                    </div>
                    <h4>Địa Chỉ</h4>
                    <p>Takeo, Cambodia<br>Khu Vực Châu Á Đông Nam</p>
                </div>

                <div class="info-card">
                    <div class="info-icon">
                        <i class="fas fa-phone"></i>
                    </div>
                    <h4>Điện Thoại</h4>
                    <p>+855 98 XXX XXXX<br><a href="tel:+85598xxxxxx">Gọi ngay</a></p>
                </div>

                <div class="info-card">
                    <div class="info-icon">
                        <i class="fas fa-envelope"></i>
                    </div>
                    <h4>Email</h4>
                    <p><?php echo esc(SITE_EMAIL); ?><br><a href="mailto:<?php echo esc(SITE_EMAIL); ?>">Gửi email</a></p>
                </div>

                <div class="info-card">
                    <div class="info-icon">
                        <i class="fas fa-clock"></i>
                    </div>
                    <h4>Giờ Hoạt Động</h4>
                    <p>Thứ 2 - Thứ 6: 09:00 - 18:00<br>Thứ 7, Chủ Nhật: Nghỉ</p>
                </div>
            </div>

            <!-- Contact Form -->
            <div class="contact-form-wrapper">
                <form id="contactForm" class="contact-form">
                    <div class="form-row">
                        <div class="form-group">
                            <label for="contactName">Họ Và Tên *</label>
                            <input 
                                type="text" 
                                id="contactName" 
                                name="name" 
                                required 
                                placeholder="Nhập tên của bạn"
                            >
                            <span class="form-error"></span>
                        </div>

                        <div class="form-group">
                            <label for="contactEmail">Email *</label>
                            <input 
                                type="email" 
                                id="contactEmail" 
                                name="email" 
                                required 
                                placeholder="Nhập email của bạn"
                            >
                            <span class="form-error"></span>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="contactSubject">Tiêu Đề *</label>
                        <input 
                            type="text" 
                            id="contactSubject" 
                            name="subject" 
                            required 
                            placeholder="Tiêu đề tin nhắn"
                        >
                        <span class="form-error"></span>
                    </div>

                    <div class="form-group">
                        <label for="contactCategory">Danh Mục</label>
                        <select id="contactCategory" name="category">
                            <option value="">-- Chọn danh mục --</option>
                            <option value="general">Hỏi Đáp Chung</option>
                            <option value="support">Hỗ Trợ Kỹ Thuật</option>
                            <option value="partnership">Hợp Tác & Đối Tác</option>
                            <option value="feedback">Phản Hồi & Góp Ý</option>
                            <option value="other">Khác</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="contactMessage">Tin Nhắn *</label>
                        <textarea 
                            id="contactMessage" 
                            name="message" 
                            required 
                            placeholder="Nhập tin nhắn của bạn (tối thiểu 20 ký tự)"
                            rows="6"
                        ></textarea>
                        <span class="form-error"></span>
                    </div>

                    <div class="form-group checkbox">
                        <input type="checkbox" id="contactAgree" name="agree" required>
                        <label for="contactAgree">
                            Tôi đồng ý với <a href="#" style="color: #5AB5D4;">Điều Khoản Dịch Vụ</a> và 
                            <a href="#" style="color: #5AB5D4;">Chính Sách Bảo Mật</a>
                        </label>
                    </div>

                    <button type="submit" class="submit-btn">
                        <i class="fas fa-paper-plane"></i>
                        Gửi Tin Nhắn
                    </button>

                    <p style="font-size: 12px; color: #999; text-align: center; margin-top: 12px;">
                        Chúng tôi sẽ phản hồi trong vòng 24 giờ
                    </p>
                </form>
            </div>
        </div>
    </div>
</section>

<style>
.contact-wrapper {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 60px;
    align-items: start;
}

.contact-info {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 24px;
}

.info-card {
    background: linear-gradient(135deg, #E8F4F8 0%, #F0F5FF 100%);
    padding: 24px;
    border-radius: 12px;
    border-left: 4px solid #5AB5D4;
    text-align: center;
    transition: all 0.3s ease;
}

.info-card:hover {
    transform: translateY(-4px);
    box-shadow: 0 8px 20px rgba(90, 181, 212, 0.15);
}

.info-icon {
    font-size: 36px;
    color: #5AB5D4;
    margin-bottom: 12px;
}

.info-card h4 {
    color: #212121;
    font-size: 18px;
    font-weight: 600;
    margin-bottom: 8px;
}

.info-card p {
    color: #616161;
    font-size: 14px;
    line-height: 1.6;
    margin: 0;
}

.info-card a {
    color: #5AB5D4;
    text-decoration: none;
    font-weight: 600;
    transition: color 0.3s ease;
}

.info-card a:hover {
    color: #3A7E9F;
}

.contact-form-wrapper {
    background: white;
    padding: 32px;
    border-radius: 12px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
}

.contact-form {
    display: flex;
    flex-direction: column;
    gap: 20px;
}

.form-row {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 16px;
}

.form-group {
    display: flex;
    flex-direction: column;
}

.form-group label {
    color: #212121;
    font-weight: 600;
    font-size: 14px;
    margin-bottom: 8px;
}

.form-group input,
.form-group textarea,
.form-group select {
    padding: 12px 14px;
    border: 1px solid #ddd;
    border-radius: 8px;
    font-size: 14px;
    font-family: inherit;
    transition: all 0.3s ease;
    background: white;
    color: #212121;
}

.form-group input:focus,
.form-group textarea:focus,
.form-group select:focus {
    outline: none;
    border-color: #5AB5D4;
    box-shadow: 0 0 0 3px rgba(90, 181, 212, 0.1);
}

.form-group textarea {
    resize: vertical;
}

.form-group.checkbox {
    flex-direction: row;
    align-items: flex-start;
    gap: 10px;
    margin: 10px 0;
}

.form-group.checkbox input {
    width: 18px;
    height: 18px;
    margin-top: 2px;
    cursor: pointer;
}

.form-group.checkbox label {
    margin: 0;
    font-size: 13px;
    font-weight: normal;
    cursor: pointer;
}

.form-error {
    color: #F44336;
    font-size: 12px;
    margin-top: 4px;
    display: none;
}

.form-group.error input,
.form-group.error textarea {
    border-color: #F44336;
}

.form-group.error .form-error {
    display: block;
}

.submit-btn {
    padding: 14px;
    background: linear-gradient(135deg, #5AB5D4 0%, #3A7E9F 100%);
    color: white;
    border: none;
    border-radius: 8px;
    font-size: 16px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s ease;
    font-family: inherit;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    margin-top: 10px;
}

.submit-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 20px rgba(90, 181, 212, 0.3);
}

.submit-btn:disabled {
    opacity: 0.6;
    cursor: not-allowed;
    transform: none !important;
}

@media (max-width: 1024px) {
    .contact-wrapper {
        grid-template-columns: 1fr;
        gap: 40px;
    }

    .contact-info {
        grid-template-columns: repeat(2, 1fr);
    }
}

@media (max-width: 768px) {
    .contact-info {
        grid-template-columns: 1fr;
    }

    .form-row {
        grid-template-columns: 1fr;
    }

    .contact-form-wrapper {
        padding: 24px;
    }
}

@media (max-width: 480px) {
    .contact-wrapper {
        gap: 30px;
    }

    .info-card {
        padding: 20px;
    }

    .contact-form-wrapper {
        padding: 20px;
    }
}
</style>

<script>
// Contact form validation
document.getElementById('contactForm')?.addEventListener('submit', function(e) {
    e.preventDefault();
    
    const form = this;
    const name = document.getElementById('contactName').value.trim();
    const email = document.getElementById('contactEmail').value.trim();
    const subject = document.getElementById('contactSubject').value.trim();
    const message = document.getElementById('contactMessage').value.trim();
    const agree = document.getElementById('contactAgree').checked;
    
    let isValid = true;
    
    // Clear previous errors
    document.querySelectorAll('.form-group').forEach(g => g.classList.remove('error'));
    
    // Validate
    if (!name) {
        setError('contactName', 'Vui lòng nhập tên');
        isValid = false;
    }
    
    if (!email || !isValidEmail(email)) {
        setError('contactEmail', 'Vui lòng nhập email hợp lệ');
        isValid = false;
    }
    
    if (!subject) {
        setError('contactSubject', 'Vui lòng nhập tiêu đề');
        isValid = false;
    }
    
    if (!message || message.length < 20) {
        setError('contactMessage', 'Tin nhắn phải có ít nhất 20 ký tự');
        isValid = false;
    }
    
    if (!agree) {
        alert('Vui lòng đồng ý với các điều khoản');
        isValid = false;
    }
    
    if (isValid) {
        submitContactForm(form);
    }
});

function setError(fieldId, message) {
    const field = document.getElementById(fieldId);
    const group = field.parentElement;
    const error = group.querySelector('.form-error');
    
    group.classList.add('error');
    if (error) {
        error.textContent = message;
    }
}

function isValidEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
}

function submitContactForm(form) {
    const submitBtn = form.querySelector('.submit-btn');
    const originalText = submitBtn.innerHTML;
    
    submitBtn.disabled = true;
    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Đang gửi...';
    
    const formData = new FormData(form);
    
    fetch('api/contact.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showNotification('Tin nhắn đã được gửi thành công! Cảm ơn bạn!', 'success');
            form.reset();
        } else {
            showNotification(data.message || 'Có lỗi xảy ra, vui lòng thử lại', 'error');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showNotification('Cảm ơn bạn đã liên hệ! Chúng tôi sẽ phản hồi sớm.', 'success');
        form.reset();
    })
    .finally(() => {
        submitBtn.disabled = false;
        submitBtn.innerHTML = originalText;
    });
}
</script>