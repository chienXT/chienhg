<?php
// api/comment.php - Comment Handler
header('Content-Type: application/json');
require_once dirname(__DIR__) . '/includes/config.php';

// Check login
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Vui lòng đăng nhập']);
    exit;
}

$user_id = $_SESSION['user_id'];
$image_id = isset($_POST['image_id']) ? intval($_POST['image_id']) : 0;
$comment_text = isset($_POST['comment']) ? trim($_POST['comment']) : '';

// Validate
if ($image_id <= 0) {
    echo json_encode(['success' => false, 'message' => 'ID không hợp lệ']);
    exit;
}

if (empty($comment_text) || strlen($comment_text) < 5) {
    echo json_encode(['success' => false, 'message' => 'Bình luận quá ngắn (tối thiểu 5 ký tự)']);
    exit;
}

if (strlen($comment_text) > 1000) {
    echo json_encode(['success' => false, 'message' => 'Bình luận quá dài (tối đa 1000 ký tự)']);
    exit;
}

try {
    // Check if image exists
    $image = getRow("SELECT id FROM artworks WHERE id = ? AND is_public = 1", [$image_id]);
    
    if (!$image) {
        echo json_encode(['success' => false, 'message' => 'Không tìm thấy ảnh']);
        exit;
    }
    
    // Insert comment
    $commentId = insert('comments', [
        'user_id' => $user_id,
        'image_id' => $image_id,
        'text' => $comment_text,
        'status' => 'approved', // Auto-approve, or set 'pending' for moderation
        'created_at' => date('Y-m-d H:i:s')
    ]);
    
    if ($commentId) {
        // Update comment count
        executeQuery("UPDATE artworks SET comments_count = comments_count + 1 WHERE id = ?", [$image_id]);
        
        echo json_encode([
            'success' => true,
            'message' => 'Đã gửi bình luận',
            'comment_id' => $commentId
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Không thể lưu bình luận']);
    }
    
} catch (Exception $e) {
    error_log('Comment error: ' . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Có lỗi xảy ra']);
}
?>