<?php
// api/toggle-visibility.php - Toggle Public/Private Status
header('Content-Type: application/json');
require_once dirname(__DIR__) . '/includes/config.php';

// Check login
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Vui lòng đăng nhập']);
    exit;
}

$user_id = $_SESSION['user_id'];

// Get JSON input
$input = json_decode(file_get_contents('php://input'), true);
$image_id = isset($input['image_id']) ? intval($input['image_id']) : 0;

if ($image_id <= 0) {
    echo json_encode(['success' => false, 'message' => 'ID không hợp lệ']);
    exit;
}

try {
    // Get image
    $image = getRow("SELECT id, user_id, is_public FROM artworks WHERE id = ?", [$image_id]);
    
    if (!$image) {
        echo json_encode(['success' => false, 'message' => 'Không tìm thấy tác phẩm']);
        exit;
    }
    
    // Check ownership
    if ($image['user_id'] != $user_id) {
        echo json_encode(['success' => false, 'message' => 'Bạn không có quyền']);
        exit;
    }
    
    // Toggle visibility
    $new_status = $image['is_public'] ? 0 : 1;
    $updated = update('artworks', 
        ['is_public' => $new_status], 
        'id = ?', 
        [$image_id]
    );
    
    if ($updated) {
        echo json_encode([
            'success' => true,
            'message' => $new_status ? 'Đã công khai' : 'Đã chuyển sang riêng tư',
            'new_status' => $new_status
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Không thể cập nhật']);
    }
    
} catch (Exception $e) {
    error_log('Toggle visibility error: ' . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Có lỗi xảy ra']);
}
?>