<?php
// api/chat.php - CHAT MESSAGE HANDLER
error_reporting(E_ALL);
ini_set('display_errors', 0);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once '../includes/config.php';
require_once '../includes/functions.php';
require_once '../includes/database.php';

header('Content-Type: application/json; charset=utf-8');

// Check authentication
if (!isLoggedIn()) {
    http_response_code(401);
    echo json_encode([
        'success' => false,
        'message' => 'Vui lòng đăng nhập'
    ]);
    exit;
}

// Only POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode([
        'success' => false,
        'message' => 'Method not allowed'
    ]);
    exit;
}

$user = getCurrentUser();
if (!$user) {
    http_response_code(401);
    echo json_encode([
        'success' => false,
        'message' => 'Không xác định được người dùng'
    ]);
    exit;
}

try {
    // Get input
    $input = file_get_contents('php://input');
    $data = json_decode($input, true);

    $action = sanitize($data['action'] ?? '');
    $message = sanitize($data['message'] ?? '');

    if ($action === 'send') {
        handleSendMessage($user, $message);
    } elseif ($action === 'list') {
        handleGetMessages();
    } else {
        http_response_code(400);
        echo json_encode([
            'success' => false,
            'message' => 'Invalid action'
        ]);
    }

} catch (Exception $e) {
    error_log('Chat API error: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Server error'
    ]);
}

exit;

// ==================== HANDLERS ====================

function handleSendMessage($user, $message) {
    // Validate message
    if (empty($message)) {
        http_response_code(400);
        echo json_encode([
            'success' => false,
            'message' => 'Tin nhắn không được để trống'
        ]);
        exit;
    }

    if (strlen($message) > 500) {
        http_response_code(400);
        echo json_encode([
            'success' => false,
            'message' => 'Tin nhắn quá dài (tối đa 500 ký tự)'
        ]);
        exit;
    }

    // Check spam (rate limiting)
    try {
        $lastMsg = getRow("
            SELECT created_at FROM chat_messages 
            WHERE user_id = ? 
            ORDER BY created_at DESC 
            LIMIT 1
        ", [$user['id']]);

        if ($lastMsg) {
            $lastTime = strtotime($lastMsg['created_at']);
            $currentTime = time();
            if ($currentTime - $lastTime < 2) {
                http_response_code(429);
                echo json_encode([
                    'success' => false,
                    'message' => 'Vui lòng đợi một chút trước khi gửi tin nhắn tiếp theo'
                ]);
                exit;
            }
        }
    } catch (Exception $e) {
        error_log('Spam check error: ' . $e->getMessage());
    }

    // Insert message
    try {
        $msgId = insert('chat_messages', [
            'user_id' => $user['id'],
            'message' => $message,
            'created_at' => date('Y-m-d H:i:s')
        ]);

        if (!$msgId) {
            http_response_code(500);
            echo json_encode([
                'success' => false,
                'message' => 'Lỗi khi lưu tin nhắn'
            ]);
            exit;
        }

        // Update user last login
        try {
            update('users', ['last_login' => date('Y-m-d H:i:s')], 'id = ?', [$user['id']]);
        } catch (Exception $e) {
            // Log but don't fail
            error_log('Update last login error: ' . $e->getMessage());
        }

        // Log activity
        try {
            logActivity('Chat message sent', ['message_id' => $msgId], $user['id']);
        } catch (Exception $e) {
            error_log('Activity log error: ' . $e->getMessage());
        }

        http_response_code(201);
        echo json_encode([
            'success' => true,
            'message' => 'Tin nhắn đã được gửi',
            'data' => [
                'message_id' => $msgId,
                'created_at' => date('Y-m-d H:i:s')
            ]
        ]);

    } catch (Exception $e) {
        error_log('Send message error: ' . $e->getMessage());
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'message' => 'Lỗi khi gửi tin nhắn'
        ]);
    }
}

function handleGetMessages() {
    try {
        $messages = getAll("
            SELECT 
                c.id,
                c.user_id,
                c.message,
                c.created_at,
                u.username,
                u.avatar
            FROM chat_messages c
            LEFT JOIN users u ON c.user_id = u.id
            ORDER BY c.created_at DESC
            LIMIT 100
        ", []);

        $messages = array_reverse($messages ?? []);

        $formatted = array_map(function($msg) {
            return [
                'id' => intval($msg['id'] ?? 0),
                'user_id' => intval($msg['user_id'] ?? 0),
                'username' => esc($msg['username'] ?? 'Anonymous'),
                'avatar' => !empty($msg['avatar']) ? UPLOAD_URL . 'profile/' . basename($msg['avatar']) : null,
                'message' => esc($msg['message'] ?? ''),
                'created_at' => $msg['created_at'] ?? ''
            ];
        }, $messages);

        http_response_code(200);
        echo json_encode([
            'success' => true,
            'message' => 'Success',
            'data' => $formatted
        ]);

    } catch (Exception $e) {
        error_log('Get messages error: ' . $e->getMessage());
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'message' => 'Failed to fetch messages'
        ]);
    }
}
?>