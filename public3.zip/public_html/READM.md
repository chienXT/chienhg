public_html/
├─ index.php
├─ config/
│  ├─ database.php
│  └─ settings.php
├─ core/
│  ├─ functions.php
│  ├─ router.php
│  └─ session.php
├─ layouts/
│  └─ main.php
├─ components/
│  ├─ header.php
│  ├─ footer.php
│  ├─ navbar.php
│  └─ card.php
├─ pages/
│  ├─ home.php
│  ├─ blog.php
│  ├─ gallery.php
│  └─ contact.php
├─ admin/
│  ├─ auth/
│  │   └─ login.php
│  ├─ gallery/
│  │   └─ list.php
│  ├─ users/
│  │   └─ list.php
│  └─ contacts/
│      └─ list.php
├─ api/
│  ├─ gallery_list.php
│  ├─ gallery_upload.php
│  ├─ chat.php
│  └─ contact_submit.php
├─ assets/
│  ├─ css/
│  ├─ js/
│  └─ images/
└─ uploads/
   ├─ gallery/
   └─ profile/
   
   
   
   
   chienhg.atspace.cc/              # Document root
├─ .htaccess                     # Bảo mật và routing
├─ index.php                     # Entry point duy nhất
│
├─ assets/                       # Tài nguyên tĩnh
│  ├─ css/
│  │   ├─ style.css
│  │   ├─ modals.css
│  │   └─ gallery.css
│  ├─ js/
│  │   ├─ main.js
│  │   └─ upload.js
│  └─ images/
│
├─ includes/                     # Code PHP (ĐỔI TÊN: app/)
│  ├─ config.php
│  ├─ functions.php
│  ├─ session.php
│  ├─ header.php
│  ├─ footer.php
│  ├─ modals.php
│  ├─ upload_handler.php         # Xử lý upload
│  └─ auth.php                   # Xử lý đăng nhập
│
├─ pages/                        # Trang nội dung
│  ├─ auth/
│  │   ├─ login.php
│  │   └─ register.php
│  ├─ gallery/
│  │   ├─ index.php
│  │   └─ upload.php             # Trang upload riêng
│  ├─ blog/
│  │   └─ index.php
│  └─ contact.php
│
├─ sections/                     # Các section của homepage
│  ├─ home.php
│  ├─ gallery.php
│  ├─ blog.php
│  ├─ contact.php
│  └─ chat.php
│
├─ uploads/                      # File upload
│  ├─ gallery/
│  └─ profile/
│
└─ api/                          # API endpoints
   ├─ upload.php                 # Đổi tên: upload_handler.php -> api/upload.php
   ├─ auth.php
   └─ contact.php
