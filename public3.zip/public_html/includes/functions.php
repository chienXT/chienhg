<?php
// includes/functions.php - OPTIMIZED FOR ATSPACE
require_once __DIR__ . '/database.php'; // Quan trọng: require database.php

/**
 * Sanitize input data - SECURE VERSION
 */
function sanitize($input) {
    if (is_array($input)) {
        return array_map('sanitize', $input);
    }
    
    if ($input === null) {
        return '';
    }
    
    // Strip HTML tags, encode special chars
    $clean = trim($input);
    $clean = htmlspecialchars($clean, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    
    // Remove control characters (except newline, carriage return, tab)
    $clean = preg_replace('/[\x00-\x09\x0B\x0C\x0E-\x1F\x7F]/', '', $clean);
    
    return $clean;
}

/**
 * Escape output - SAFE FOR HTML
 */
function esc($str, $preserve_newlines = false) {
    if ($str === null || $str === false) {
        return '';
    }
    
    $escaped = htmlspecialchars((string)$str, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    
    if ($preserve_newlines) {
        $escaped = nl2br($escaped);
    }
    
    return $escaped;
}

/**
 * Check if user is logged in
 */
function isLoggedIn() {
    return !empty($_SESSION['user_id']) && is_numeric($_SESSION['user_id']);
}

/**
 * Check if user is admin
 */
function isAdmin() {
    return isLoggedIn() && isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin';
}

/**
 * Get current user data from session (lightweight)
 */
function getCurrentUser() {
    if (!isLoggedIn()) {
        return null;
    }
    
    return [
        'id' => (int)$_SESSION['user_id'],
        'username' => $_SESSION['username'] ?? '',
        'email' => $_SESSION['user_email'] ?? '',
        'role' => $_SESSION['user_role'] ?? 'user',
        'avatar' => $_SESSION['user_avatar'] ?? null
    ];
}

/**
 * Get full user data from database (when needed)
 */
function getCurrentUserDetails() {
    $user = getCurrentUser();
    if (!$user) {
        return null;
    }
    
    try {
        $sql = "SELECT * FROM users WHERE id = ? AND status = 'active' LIMIT 1";
        $userDetails = getRow($sql, [$user['id']]);
        
        if ($userDetails) {
            // Update session if needed
            if (empty($_SESSION['user_avatar']) && !empty($userDetails['avatar'])) {
                $_SESSION['user_avatar'] = $userDetails['avatar'];
            }
            
            return $userDetails;
        }
        
        // User not found in DB, clear session
        session_destroy();
        return null;
        
    } catch (Exception $e) {
        error_log('getCurrentUserDetails error: ' . $e->getMessage());
        return $user; // Return session data as fallback
    }
}

/**
 * Redirect to URL with optional message
 */
function redirect($url, $message = '', $message_type = 'success') {
    if (!headers_sent()) {
        if ($message) {
            $_SESSION['flash_message'] = $message;
            $_SESSION['flash_type'] = $message_type;
        }
        header('Location: ' . $url);
        exit;
    } else {
        // Fallback: JavaScript redirect
        echo '<script>window.location.href="' . esc($url) . '";</script>';
        exit;
    }
}

/**
 * Get CSRF token
 */
function getCsrfToken() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/**
 * Generate and output CSRF hidden field
 */
function csrfField() {
    $token = getCsrfToken();
    return '<input type="hidden" name="csrf_token" value="' . esc($token) . '">';
}

/**
 * Validate CSRF token
 */
function validateCsrfToken($token) {
    if (empty($_SESSION['csrf_token']) || empty($token)) {
        return false;
    }
    
    return hash_equals($_SESSION['csrf_token'], $token);
}

/**
 * Get all gallery items - UPDATED for new database.php
 */
function get_all_gallery_items($category = null, $user_id = null, $limit = 50) {
    try {
        $sql = "SELECT 
            a.*,
            u.username,
            u.avatar
        FROM artworks a
        LEFT JOIN users u ON a.user_id = u.id
        WHERE a.is_public = 1";
        
        $params = [];
        
        if ($category !== null && $category !== '') {
            $sql .= " AND a.category = ?";
            $params[] = $category;
        }
        
        if ($user_id !== null && is_numeric($user_id)) {
            $sql .= " AND a.user_id = ?";
            $params[] = (int)$user_id;
        }
        
        $sql .= " ORDER BY a.created_at DESC";
        
        if ($limit > 0) {
            $sql .= " LIMIT " . (int)$limit;
        }
        
        return getAll($sql, $params);
        
    } catch (Exception $e) {
        error_log('Gallery items error: ' . $e->getMessage());
        return [];
    }
}

/**
 * Get time ago string (Vietnamese)
 */
function get_time_ago($datetime) {
    if (empty($datetime)) {
        return 'Vừa xong';
    }
    
    try {
        $time = strtotime($datetime);
        if ($time === false) {
            return $datetime;
        }
        
        $time_diff = time() - $time;
        
        if ($time_diff < 60) {
            return 'Vừa xong';
        } elseif ($time_diff < 3600) {
            $minutes = floor($time_diff / 60);
            return $minutes . ' phút trước';
        } elseif ($time_diff < 86400) {
            $hours = floor($time_diff / 3600);
            return $hours . ' giờ trước';
        } elseif ($time_diff < 2592000) {
            $days = floor($time_diff / 86400);
            return $days . ' ngày trước';
        } elseif ($time_diff < 31536000) {
            $months = floor($time_diff / 2592000);
            return $months . ' tháng trước';
        } else {
            $years = floor($time_diff / 31536000);
            return $years . ' năm trước';
        }
    } catch (Exception $e) {
        return $datetime;
    }
}

/**
 * Upload image file - UPDATED with config constants
 */
function uploadImage($file, $type = 'gallery') {
    // Validate input
    if (!isset($file['error']) || $file['error'] === UPLOAD_ERR_NO_FILE) {
        throw new Exception('Không có file được chọn');
    }
    
    if ($file['error'] !== UPLOAD_ERR_OK) {
        $errors = [
            UPLOAD_ERR_INI_SIZE => 'File vượt quá kích thước cho phép',
            UPLOAD_ERR_FORM_SIZE => 'File vượt quá kích thước form',
            UPLOAD_ERR_PARTIAL => 'File chỉ upload một phần',
            UPLOAD_ERR_NO_TMP_DIR => 'Thiếu thư mục tạm',
            UPLOAD_ERR_CANT_WRITE => 'Không thể ghi file',
            UPLOAD_ERR_EXTENSION => 'Extension PHP dừng upload'
        ];
        throw new Exception($errors[$file['error']] ?? 'Lỗi upload không xác định');
    }
    
    // Check file size
    if ($file['size'] > MAX_FILE_SIZE) {
        throw new Exception('File quá lớn, tối đa ' . (MAX_FILE_SIZE / 1024 / 1024) . 'MB');
    }
    
    // Get file info
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);
    
    // Check MIME type
    $allowed_mimes = [
        'image/jpeg' => 'jpg',
        'image/png' => 'png',
        'image/gif' => 'gif',
        'image/webp' => 'webp'
    ];
    
    if (!isset($allowed_mimes[$mime])) {
        throw new Exception('Chỉ chấp nhận file ảnh: JPG, PNG, GIF, WebP');
    }
    
    // Get extension from MIME type (more secure than from filename)
    $extension = $allowed_mimes[$mime];
    
    // Validate type parameter
    if ($type === 'gallery') {
        $upload_dir = GALLERY_UPLOAD_DIR;
        $web_path = UPLOAD_URL . 'gallery/'; // Sửa: dùng UPLOAD_URL từ config
    } elseif ($type === 'profile') {
        $upload_dir = PROFILE_UPLOAD_DIR;
        $web_path = UPLOAD_URL . 'profile/';
    } else {
        throw new Exception('Loại upload không hợp lệ');
    }
    
    // Create directory if not exists
    if (!file_exists($upload_dir)) {
        if (!mkdir($upload_dir, 0755, true)) {
            throw new Exception('Không thể tạo thư mục upload');
        }
    }
    
    // Check if directory is writable
    if (!is_writable($upload_dir)) {
        throw new Exception('Thư mục upload không có quyền ghi');
    }
    
    // Generate unique filename
    $filename = uniqid($type . '_', true) . '_' . time() . '.' . $extension;
    $target_path = $upload_dir . $filename;
    
    // Move uploaded file
    if (!move_uploaded_file($file['tmp_name'], $target_path)) {
        throw new Exception('Không thể di chuyển file đã upload');
    }
    
    // Verify the file is actually an image
    $image_info = getimagesize($target_path);
    if (!$image_info) {
        @unlink($target_path);
        throw new Exception('File không phải là ảnh hợp lệ');
    }
    
    // Return web-accessible path
    return $web_path . $filename;
}

/**
 * Delete image file - UPDATED with safety checks
 */
function deleteImage($path) {
    if (empty($path)) {
        return false;
    }
    
    // Security: prevent directory traversal
    $path = preg_replace('/\.\.\//', '', $path);
    
    // Only allow deletion from uploads directory
    if (strpos($path, 'uploads/') !== 0) {
        error_log('Security: Attempt to delete file outside uploads: ' . $path);
        return false;
    }
    
    $full_path = $_SERVER['DOCUMENT_ROOT'] . '/' . $path;
    
    if (!file_exists($full_path)) {
        return true; // File doesn't exist, consider it deleted
    }
    
    // Check if file is within uploads directory
    $real_uploads_path = realpath($_SERVER['DOCUMENT_ROOT'] . '/uploads/');
    $real_file_path = realpath($full_path);
    
    if (strpos($real_file_path, $real_uploads_path) !== 0) {
        error_log('Security: Attempt to delete file outside uploads directory: ' . $full_path);
        return false;
    }
    
    return unlink($full_path);
}

/**
 * Get category name by key
 */
function getCategoryName($key) {
    $categories = [
        'painting' => 'Tranh Sơn Dầu',
        'digital' => 'Nghệ Thuật Số',
        'photography' => 'Nhiếp Ảnh',
        'sculpture' => 'Điêu Khắc',
        'illustration' => 'Minh Họa',
        'other' => 'Khác'
    ];
    
    return $categories[$key] ?? 'Khác';
}

/**
 * Get category icon
 */
function getCategoryIcon($key) {
    $icons = [
        'painting' => '🎨',
        'digital' => '💻',
        'photography' => '📸',
        'sculpture' => '🗿',
        'illustration' => '✏️',
        'other' => '🎭'
    ];
    
    return $icons[$key] ?? '🎭';
}

/**
 * Format date - SAFE VERSION
 */
function formatDate($date, $format = 'd/m/Y H:i') {
    if (empty($date) || $date === '0000-00-00 00:00:00') {
        return 'N/A';
    }
    
    try {
        $timestamp = strtotime($date);
        if ($timestamp === false) {
            return $date;
        }
        
        return date($format, $timestamp);
    } catch (Exception $e) {
        return $date;
    }
}

/**
 * JSON response helper - UPDATED for API
 */
function jsonResponse($success, $message, $data = null, $http_code = 200) {
    // Clear any previous output
    if (ob_get_level() > 0) {
        ob_clean();
    }
    
    http_response_code($http_code);
    header('Content-Type: application/json; charset=utf-8');
    
    $response = [
        'success' => (bool)$success,
        'message' => (string)$message,
        'timestamp' => time()
    ];
    
    if ($data !== null) {
        $response['data'] = $data;
    }
    
    // Add debug info in development
    if (ini_get('display_errors') && isset($_SERVER['REQUEST_TIME_FLOAT'])) {
        $response['debug'] = [
            'execution_time' => microtime(true) - $_SERVER['REQUEST_TIME_FLOAT'],
            'memory_usage' => memory_get_usage(true)
        ];
    }
    
    echo json_encode($response, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}

/**
 * Validate email
 */
function validateEmail($email) {
    if (empty($email)) {
        return false;
    }
    
    // Basic format check
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        return false;
    }
    
    // Check domain (simple version)
    $domain = substr(strrchr($email, "@"), 1);
    if (empty($domain)) {
        return false;
    }
    
    return true;
}

/**
 * Validate username
 */
function validateUsername($username) {
    if (empty($username)) {
        return false;
    }
    
    // Length check
    if (strlen($username) < USERNAME_MIN_LENGTH || strlen($username) > 50) {
        return false;
    }
    
    // Allowed characters: letters, numbers, underscore, hyphen
    if (!preg_match('/^[a-zA-Z0-9_-]+$/', $username)) {
        return false;
    }
    
    // Cannot start or end with hyphen/underscore
    if (preg_match('/^[-_]|[-_]$/', $username)) {
        return false;
    }
    
    // Cannot have consecutive hyphens/underscores
    if (preg_match('/[-_]{2,}/', $username)) {
        return false;
    }
    
    return true;
}

/**
 * Validate password
 */
function validatePassword($password) {
    if (empty($password)) {
        return false;
    }
    
    // Minimum length
    if (strlen($password) < PASSWORD_MIN_LENGTH) {
        return false;
    }
    
    // Maximum length (security)
    if (strlen($password) > 72) { // Bcrypt limit
        return false;
    }
    
    return true;
}

/**
 * Hash password
 */
function hashPassword($password) {
    return password_hash($password, PASSWORD_DEFAULT);
}

/**
 * Verify password
 */
function verifyPassword($password, $hash) {
    return password_verify($password, $hash);
}

/**
 * Log activity - ENHANCED
 */
function logActivity($message, $data = [], $user_id = null) {
    if (empty($user_id) && isLoggedIn()) {
        $user_id = $_SESSION['user_id'];
    }
    
    $log_entry = date('Y-m-d H:i:s') . ' | ';
    $log_entry .= 'IP: ' . ($_SERVER['REMOTE_ADDR'] ?? 'unknown') . ' | ';
    
    if ($user_id) {
        $log_entry .= 'User: ' . $user_id . ' | ';
    }
    
    $log_entry .= 'Message: ' . $message;
    
    if (!empty($data)) {
        $log_entry .= ' | Data: ' . json_encode($data, JSON_UNESCAPED_UNICODE);
    }
    
    // Log to file
    $log_file = __DIR__ . '/activity.log';
    file_put_contents($log_file, $log_entry . PHP_EOL, FILE_APPEND | LOCK_EX);
    
    // Also log to PHP error log
    error_log($log_entry);
}

/**
 * Get flash message and clear it
 */
function getFlashMessage() {
    if (!empty($_SESSION['flash_message'])) {
        $message = $_SESSION['flash_message'];
        $type = $_SESSION['flash_type'] ?? 'info';
        
        unset($_SESSION['flash_message']);
        unset($_SESSION['flash_type']);
        
        return [
            'text' => $message,
            'type' => $type
        ];
    }
    
    return null;
}

/**
 * Display flash message if exists
 */
function displayFlashMessage() {
    $flash = getFlashMessage();
    if ($flash) {
        $type_class = $flash['type'] === 'error' ? 'danger' : $flash['type'];
        return '<div class="alert alert-' . esc($type_class) . ' alert-dismissible fade show" role="alert">
            ' . esc($flash['text']) . '
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>';
    }
    
    return '';
}

/**
 * Generate random string
 */
function randomString($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $random_string = '';
    
    for ($i = 0; $i < $length; $i++) {
        $random_string .= $characters[random_int(0, strlen($characters) - 1)];
    }
    
    return $random_string;
}

/**
 * Check if request is AJAX
 */
function isAjax() {
    return isset($_SERVER['HTTP_X_REQUESTED_WITH']) && 
           strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';
}

/**
 * Get current URL
 */
function currentUrl() {
    $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https://' : 'http://';
    return $protocol . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
}
?>