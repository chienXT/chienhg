<?php
// includes/footer.php - Footer (Clean & Simple)
?>

<footer>
    <div class="footer-container">
        <!-- Footer Content -->
        <div class="footer-content">
            <!-- Section 1: About -->
            <div class="footer-section">
                <h3>Về ArtFolio</h3>
                <p>ArtFolio là nền tảng chia sẻ các tác phẩm nghệ thuật cho các nghệ sĩ và những người yêu thích nghệ thuật trên toàn thế giới.</p>
                
            <div class="social-links">
                    <a href="https://facebook.com" class="social-link" title="Facebook" target="_blank" rel="noopener noreferrer">
                        <i class="fab fa-facebook-f"></i>
                    </a>
                    <a href="https://instagram.com" class="social-link" title="Instagram" target="_blank" rel="noopener noreferrer">
                        <i class="fab fa-instagram"></i>
                    </a>
                    <a href="https://twitter.com" class="social-link" title="Twitter" target="_blank" rel="noopener noreferrer">
                        <i class="fab fa-twitter"></i>
                    </a>
                    <a href="https://pinterest.com" class="social-link" title="Pinterest" target="_blank" rel="noopener noreferrer">
                        <i class="fab fa-pinterest-p"></i>
                    </a>
                </div>

            </div>

            <!-- Section 2: Quick Links -->
            <div class="footer-section">
                <h3>Liên Kết Nhanh</h3>
                <ul class="footer-links">
                    <li><a href="#home"><i class="fas fa-home"></i> Trang Chủ</a></li>
                    <li><a href="#gallery"><i class="fas fa-images"></i> Thư Viện</a></li>
                    <li><a href="#blog"><i class="fas fa-blog"></i> Blog</a></li>
                    <li><a href="#contact"><i class="fas fa-envelope"></i> Liên Hệ</a></li>
                    <li><a href="#chat"><i class="fas fa-comments"></i> Chat</a></li>
                </ul>
            </div>

            <!-- Section 3: Support -->
            <div class="footer-section">
                <h3>Hỗ Trợ</h3>
                <ul class="footer-links">
                    <li><a href="#faq"><i class="fas fa-question-circle"></i> Câu Hỏi Thường Gặp</a></li>
                    <li><a href="#help"><i class="fas fa-life-ring"></i> Trợ Giúp</a></li>
                    <li><a href="#terms"><i class="fas fa-file-contract"></i> Điều Khoản</a></li>
                    <li><a href="#privacy"><i class="fas fa-shield-alt"></i> Bảo Mật</a></li>
                    <li><a href="#community"><i class="fas fa-users"></i> Cộng Đồng</a></li>
                </ul>
            </div>

            <!-- Section 4: Newsletter & Contact -->
            <div class="footer-section">
                <h3>Nhận Tin Mới</h3>
                <p>Đăng ký để nhận tin tức và cập nhật mới nhất từ ArtFolio.</p>
                
                <form class="newsletter-form" id="newsletterForm" onsubmit="handleNewsletterSubmit(event)">
                    <input type="email" placeholder="Email của bạn" required>
                    <button type="submit" class="newsletter-btn">Đăng Ký</button>
                </form>

                <!-- Contact Info -->
                <div class="footer-contact">
                    <p>
                        <i class="fas fa-envelope"></i>
                        <a href="mailto:<?php echo esc(SITE_EMAIL); ?>">
                            <?php echo esc(SITE_EMAIL); ?>
                        </a>
                    </p>
                    <p>
                        <i class="fas fa-map-marker-alt"></i>
                        <strong>Takeo, Cambodia</strong>
                    </p>
                    <p>
                        <i class="fas fa-phone"></i>
                        <strong>+855 98 XXX XXXX</strong>
                    </p>
                </div>
            </div>
        </div>

        <!-- Footer Bottom -->
        <div class="footer-bottom">
            <p class="footer-copyright">
                &copy; <?php echo date('Y'); ?> <?php echo esc(SITE_NAME); ?>. 
                Bản quyền thuộc về Chiến Hoàng. Tất cả quyền được bảo lưu.
            </p>
            
            <div class="footer-bottom-links">
                <a href="#terms" class="footer-bottom-link">Điều khoản</a>
                <a href="#privacy" class="footer-bottom-link">Bảo mật</a>
                <a href="#sitemap" class="footer-bottom-link">Sitemap</a>
                <a href="#contact" class="footer-bottom-link">Liên hệ</a>
            </div>
        </div>
    </div>
</footer>

<!-- Footer JavaScript -->
<script>
function handleNewsletterSubmit(event) {
    event.preventDefault();
    const email = event.target.querySelector('input[type="email"]').value;
    
    // Show success message
    showNotification('Cảm ơn bạn đã đăng ký! Vui lòng kiểm tra email.', 'success');
    
    // Reset form
    event.target.reset();
    
    // In production, send to server:
    // fetch('/api/newsletter.php', {
    //     method: 'POST',
    //     headers: { 'Content-Type': 'application/json' },
    //     body: JSON.stringify({ email })
    // })
}
</script>
<script src="<?php echo BASE_URL; ?>assets/js/main.js"></script>
<script src="<?php echo BASE_URL; ?>assets/js/upload.js"></script>
