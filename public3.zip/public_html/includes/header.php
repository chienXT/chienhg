<?php
// includes/header.php

require_once __DIR__ . '/config.php';

// Kiểm tra user đã đăng nhập chưa
$isLoggedIn = isset($_SESSION['user_id']) && $_SESSION['user_id'] > 0;

// Debug - comment sau khi fix
echo "<!-- DEBUG: Session user_id = " . ($_SESSION['user_id'] ?? 'not set') . " -->";
echo "<!-- DEBUG: isLoggedIn = " . ($isLoggedIn ? 'true' : 'false') . " -->";

// Nếu đã đăng nhập, lấy thông tin user
$currentUser = null;
if ($isLoggedIn) {
    $currentUser = [
        'id' => $_SESSION['user_id'],
        'username' => $_SESSION['username'] ?? 'User',
        'email' => $_SESSION['email'] ?? '',
        'role' => $_SESSION['user_role'] ?? 'user',
        'avatar' => $_SESSION['avatar'] ?? ''
    ];
    
    echo "<!-- DEBUG: User data = " . htmlspecialchars(json_encode($currentUser)) . " -->";
}
?>



<!-- Header -->
<header id="header">
    <div class="container">
        <nav class="navbar">
            <!-- Logo -->
            <a href="<?php echo BASE_URL ?? '/'; ?>" class="logo">
                <span class="logo-icon">🎨</span>
                <span class="logo-text">ArtFolio</span>
            </a>

            <!-- Desktop Navigation -->
            <div class="nav-menu" id="navMenu">
                <ul class="nav-links" id="navLinks">
                    <li><a href="#home" class="nav-link">Trang Chủ</a></li>
                    <li><a href="#gallery" class="nav-link">Gallery</a></li>
                    <li><a href="#about" class="nav-link">Về Chúng Tôi</a></li>
                    <li><a href="#contact" class="nav-link">Liên Hệ</a></li>
                    
                    <?php if ($isLoggedIn && $currentUser): ?>
                        <!-- User đã đăng nhập - Hiển thị dropdown -->
                        <li class="nav-dropdown">
                            <a href="#" class="nav-link user-menu">
                                <?php if (!empty($currentUser['avatar'])): ?>
                                    <img src="<?php echo UPLOAD_URL . $currentUser['avatar']; ?>" 
                                         alt="Avatar" 
                                         class="user-avatar-small">
                                <?php else: ?>
                                    <div class="user-avatar-initial">
                                        <?php echo strtoupper(substr($currentUser['username'], 0, 1)); ?>
                                    </div>
                                <?php endif; ?>
                                <span class="username"><?php echo htmlspecialchars($currentUser['username']); ?></span>
                                <i class="fas fa-chevron-down"></i>
                            </a>
                            <ul class="dropdown-menu">
                                <li><a href="<?php echo BASE_URL ?? '/'; ?>pages/profile.php"><i class="fas fa-user"></i> Hồ sơ</a></li>
                                <li><a href="<?php echo BASE_URL ?? '/'; ?>pages/upload.php"><i class="fas fa-upload"></i> Upload ảnh</a></li>
                                <?php if ($currentUser['role'] === 'admin'): ?>
                                    <li><a href="<?php echo BASE_URL ?? '/'; ?>pages/admin/dashboard.php"><i class="fas fa-cog"></i> Quản trị</a></li>
                                <?php endif; ?>
                                <li><hr></li>
                                <li><a href="<?php echo BASE_URL ?? '/'; ?>api/auth.php?action=logout" class="logout-link"><i class="fas fa-sign-out-alt"></i> Đăng xuất</a></li>
                            </ul>
                        </li>
                    <?php else: ?>
                        <!-- User chưa đăng nhập - Hiển thị nút auth -->
                        <li class="auth-buttons">
                            <button id="loginBtn" class="btn-login">
                                <i class="fas fa-sign-in-alt"></i> Đăng nhập
                            </button>
                            <button id="registerBtn" class="btn-register">
                                <i class="fas fa-user-plus"></i> Đăng ký
                            </button>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>

            <!-- Mobile Menu Toggle -->
            <button class="hamburger" id="hamburger" aria-label="Menu">
                <span></span>
                <span></span>
                <span></span>
            </button>
        </nav>
    </div>
</header>

<!-- Mobile Menu Overlay -->
<div class="mobile-overlay" id="mobileOverlay"></div>