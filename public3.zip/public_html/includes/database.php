<?php
// includes/database.php - ULTIMATE FIX FOR ATSPACE
require_once __DIR__ . '/config.php';

// Global variables
$pdo = null;
$connection_attempts = 0;
$max_connection_attempts = 2;

/**
 * Get database connection - ULTRA SAFE VERSION
 */
function getDB() {
    global $pdo, $connection_attempts, $max_connection_attempts;
    
    // Return existing connection
    if ($pdo !== null) {
        try {
            // Quick connection test
            $pdo->query('SELECT 1');
            return $pdo;
        } catch (PDOException $e) {
            // Connection lost, reset and reconnect
            $pdo = null;
        }
    }
    
    // Create new connection
    $connection_attempts = 0;
    
    while ($connection_attempts < $max_connection_attempts) {
        $connection_attempts++;
        
        try {
            $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4";
            
            // MINIMAL options for shared hosting compatibility
            $options = [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
                PDO::ATTR_PERSISTENT => false,
                PDO::ATTR_TIMEOUT => 10
            ];
            
            $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
            
            // Set SQL mode for compatibility
            $pdo->exec("SET SESSION sql_mode = 'TRADITIONAL'");
            
            return $pdo;
            
        } catch (PDOException $e) {
            error_log('[DB CONNECTION ATTEMPT ' . $connection_attempts . '] ' . $e->getMessage());
            
            if ($connection_attempts >= $max_connection_attempts) {
                if (DEBUG_MODE) {
                    throw new Exception("Database Connection Failed: " . $e->getMessage());
                } else {
                    throw new Exception("Service temporarily unavailable. Please try again later.");
                }
            }
            
            // Wait before retry
            sleep(1);
        }
    }
    
    throw new Exception("Failed to connect after {$max_connection_attempts} attempts");
}

/**
 * Execute query with retry logic
 */
function executeQuery($sql, $params = []) {
    // Ensure numeric indexed params
    if (!empty($params) && !isset($params[0])) {
        $params = array_values($params);
    }
    
    $max_retries = 2;
    $retry_count = 0;
    
    while ($retry_count < $max_retries) {
        $retry_count++;
        
        try {
            $stmt = getDB()->prepare($sql);
            
            // Bind parameters with proper types
            if (!empty($params)) {
                foreach ($params as $key => $value) {
                    $type = PDO::PARAM_STR;
                    
                    if (is_int($value)) {
                        $type = PDO::PARAM_INT;
                    } elseif (is_bool($value)) {
                        $type = PDO::PARAM_BOOL;
                    } elseif (is_null($value)) {
                        $type = PDO::PARAM_NULL;
                    }
                    
                    $stmt->bindValue($key + 1, $value, $type);
                }
            }
            
            $stmt->execute();
            return $stmt;
            
        } catch (PDOException $e) {
            error_log('[QUERY ERROR] SQL: ' . $sql . ' | Error: ' . $e->getMessage());
            
            // Check if connection error
            $errorCode = $e->getCode();
            $errorMsg = $e->getMessage();
            
            $connectionErrors = ['2002', '2006', '2013', 'HY000'];
            $needsRetry = false;
            
            // Check error code
            foreach ($connectionErrors as $code) {
                if (strpos((string)$errorCode, $code) !== false) {
                    $needsRetry = true;
                    break;
                }
            }
            
            // Check error message
            if (!$needsRetry) {
                $retryMessages = ['server has gone away', 'lost connection', 'connection was killed'];
                foreach ($retryMessages as $msg) {
                    if (stripos($errorMsg, $msg) !== false) {
                        $needsRetry = true;
                        break;
                    }
                }
            }
            
            if ($needsRetry && $retry_count < $max_retries) {
                global $pdo;
                $pdo = null;
                usleep(500000); // 0.5 seconds
                continue;
            }
            
            // Final error
            if (DEBUG_MODE) {
                throw new Exception("Database query failed: " . $e->getMessage());
            } else {
                throw new Exception("Database operation failed. Please try again.");
            }
        }
    }
    
    throw new Exception("Failed after {$max_retries} attempts");
}

/**
 * Get single row
 */
function getRow($sql, $params = []) {
    try {
        $stmt = executeQuery($sql, $params);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        $stmt->closeCursor();
        return $result ?: null;
    } catch (Exception $e) {
        error_log('getRow error: ' . $e->getMessage());
        return null;
    }
}

/**
 * Get all rows
 */
function getAll($sql, $params = []) {
    try {
        $stmt = executeQuery($sql, $params);
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $stmt->closeCursor();
        return $results ?: [];
    } catch (Exception $e) {
        error_log('getAll error: ' . $e->getMessage());
        return [];
    }
}

/**
 * Insert data
 */
function insert($table, $data) {
    // Validate table name
    if (!preg_match('/^[a-zA-Z_][a-zA-Z0-9_]*$/', $table)) {
        throw new Exception("Invalid table name");
    }
    
    $columns = array_keys($data);
    $placeholders = array_fill(0, count($columns), '?');
    
    // Escape column names
    $escapedColumns = array_map(function($col) {
        return "`{$col}`";
    }, $columns);
    
    $sql = "INSERT INTO `{$table}` (" . implode(', ', $escapedColumns) . ") 
            VALUES (" . implode(', ', $placeholders) . ")";
    
    try {
        $stmt = executeQuery($sql, array_values($data));
        $affected = $stmt->rowCount();
        $stmt->closeCursor();
        
        if ($affected > 0) {
            return getDB()->lastInsertId();
        }
        
        return false;
    } catch (Exception $e) {
        error_log('Insert error: ' . $e->getMessage());
        return false;
    }
}

/**
 * Update data
 */
function update($table, $data, $where, $whereParams = []) {
    // Validate table name
    if (!preg_match('/^[a-zA-Z_][a-zA-Z0-9_]*$/', $table)) {
        throw new Exception("Invalid table name");
    }
    
    $setParts = [];
    foreach (array_keys($data) as $column) {
        $setParts[] = "`{$column}` = ?";
    }
    
    $sql = "UPDATE `{$table}` SET " . implode(', ', $setParts) . " WHERE {$where}";
    $allParams = array_merge(array_values($data), $whereParams);
    
    try {
        $stmt = executeQuery($sql, $allParams);
        $affected = $stmt->rowCount();
        $stmt->closeCursor();
        return $affected;
    } catch (Exception $e) {
        error_log('Update error: ' . $e->getMessage());
        return 0;
    }
}

/**
 * Delete data
 */
function delete($table, $where, $params = []) {
    // Validate table name
    if (!preg_match('/^[a-zA-Z_][a-zA-Z0-9_]*$/', $table)) {
        throw new Exception("Invalid table name");
    }
    
    $sql = "DELETE FROM `{$table}` WHERE {$where}";
    
    try {
        $stmt = executeQuery($sql, $params);
        $affected = $stmt->rowCount();
        $stmt->closeCursor();
        return $affected;
    } catch (Exception $e) {
        error_log('Delete error: ' . $e->getMessage());
        return 0;
    }
}

/**
 * Safe pagination for shared hosting
 */
function getPaginatedSimple($table, $where = '', $params = [], $page = 1, $perPage = 12, $orderBy = 'id DESC') {
    $page = max(1, (int)$page);
    $perPage = max(1, min(100, (int)$perPage)); // Max 100 per page
    $offset = ($page - 1) * $perPage;
    
    try {
        // Count query
        $countSql = "SELECT COUNT(*) as total FROM `{$table}`";
        if ($where) {
            $countSql .= " WHERE {$where}";
        }
        
        $countResult = getRow($countSql, $params);
        $total = $countResult ? (int)$countResult['total'] : 0;
        
        // Main query
        $mainSql = "SELECT * FROM `{$table}`";
        if ($where) {
            $mainSql .= " WHERE {$where}";
        }
        $mainSql .= " ORDER BY {$orderBy} LIMIT {$perPage} OFFSET {$offset}";
        
        $results = getAll($mainSql, $params);
        
        return [
            'data' => $results,
            'total' => $total,
            'page' => $page,
            'per_page' => $perPage,
            'total_pages' => $total > 0 ? ceil($total / $perPage) : 0
        ];
    } catch (Exception $e) {
        error_log('Pagination error: ' . $e->getMessage());
        return [
            'data' => [],
            'total' => 0,
            'page' => 1,
            'per_page' => $perPage,
            'total_pages' => 0
        ];
    }
}

/**
 * Check connection
 */
function checkDBConnection() {
    try {
        getDB();
        return true;
    } catch (Exception $e) {
        return false;
    }
}

/**
 * Close connection
 */
function closeDB() {
    global $pdo;
    $pdo = null;
}

/**
 * Test connection
 */
function testDBConnection() {
    try {
        $result = getRow("SELECT 1 as test");
        return !empty($result) && $result['test'] == 1;
    } catch (Exception $e) {
        return false;
    }
}
?>