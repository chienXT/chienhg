<?php
// includes/session.php - SIMPLE VERSION FOR ATSPACE

/**
 * Simple session start for Atspace
 */
function startAtspaceSession() {
    if (session_status() === PHP_SESSION_NONE) {
        // ========== MINIMAL CONFIG FOR ATSPACE ==========
        $isHttps = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on';
        
        // Use custom session name to avoid conflicts
        session_name('ARTFOLIO_SESS');
        
        // Minimal cookie settings
        session_set_cookie_params([
            'lifetime' => 86400 * 7, // 7 days
            'path' => '/',
            // 'domain' => $_SERVER['HTTP_HOST'], // ⚠️ COMMENT OUT for Atspace
            'secure' => $isHttps,
            'httponly' => true,
            'samesite' => 'Lax' // Use Lax instead of Strict
        ]);
        
        // Start session
        @session_start();
        
        // ========== BASIC INITIALIZATION ==========
        if (!isset($_SESSION['_initialized'])) {
            $_SESSION['_initialized'] = true;
            
            // Initialize user data if not set
            if (!isset($_SESSION['user_id'])) {
                $_SESSION['user_id'] = 0;
                $_SESSION['username'] = '';
                $_SESSION['user_role'] = 'guest';
                $_SESSION['user_email'] = '';
                $_SESSION['avatar'] = '';
            }
            
            // Initialize CSRF token
            if (!isset($_SESSION['csrf_token'])) {
                $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
            }
        }
    }
}

/**
 * Check if user is logged in
 */
function isUserLoggedIn() {
    return isset($_SESSION['user_id']) && $_SESSION['user_id'] > 0;
}

/**
 * Simple login function
 */
function loginUserSimple($userId, $username, $email = '', $role = 'user', $avatar = '') {
    if (empty($userId)) return false;
    
    $_SESSION['user_id'] = (int)$userId;
    $_SESSION['username'] = $username;
    $_SESSION['user_email'] = $email;
    $_SESSION['user_role'] = $role;
    $_SESSION['avatar'] = $avatar;
    $_SESSION['login_time'] = time();
    
    // Regenerate session ID for security
    @session_regenerate_id(true);
    
    return true;
}

/**
 * Simple logout
 */
function logoutUserSimple() {
    // Clear user data
    $_SESSION['user_id'] = 0;
    $_SESSION['username'] = '';
    $_SESSION['user_email'] = '';
    $_SESSION['user_role'] = 'guest';
    $_SESSION['avatar'] = '';
    
    // Keep other session data (like cart, preferences)
    
    return true;
}

/**
 * Get current user ID
 */
function getCurrentUserId() {
    return $_SESSION['user_id'] ?? 0;
}

/**
 * Get current username
 */
function getCurrentUsername() {
    return $_SESSION['username'] ?? '';
}

/**
 * Check if user is admin
 */
function isAdmin() {
    return isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin';
}

/**
 * Generate CSRF token
 */
function getCsrfToken() {
    if (!isset($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/**
 * Validate CSRF token
 */
function validateCsrfToken($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

// ========== AUTO START ==========
// Try to start session, but don't crash if fails
try {
    startAtspaceSession();
} catch (Exception $e) {
    // Silent fail - session may work anyway
    error_log('Session warning: ' . $e->getMessage());
}
?>