<?php
// pages/my-artworks.php - My Artworks Management
require_once dirname(__DIR__) . '/includes/config.php';

// Check login
if (!isset($_SESSION['user_id'])) {
    header('Location: ' . BASE_URL);
    exit;
}

$user_id = $_SESSION['user_id'];
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$per_page = 12;

// Get user info
$user = getRow("SELECT username, avatar FROM users WHERE id = ?", [$user_id]);

// Get artworks
$result = getPaginatedSimple('artworks', 'user_id = ?', [$user_id], $page, $per_page, 'created_at DESC');
$artworks = $result['data'];
$total_pages = $result['total_pages'];
$total = $result['total'];

$pageTitle = 'Tác phẩm của tôi - ' . SITE_NAME;
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle; ?></title>
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .page-container {
            max-width: 1400px;
            margin: 100px auto 60px;
            padding: 0 20px;
        }
        .page-header {
            background: white;
            border-radius: 16px;
            padding: 40px;
            margin-bottom: 30px;
            box-shadow: 0 2px 20px rgba(0,0,0,0.08);
        }
        .header-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 20px;
        }
        .header-left {
            display: flex;
            align-items: center;
            gap: 20px;
        }
        .user-avatar {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            object-fit: cover;
        }
        .avatar-placeholder {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 32px;
            font-weight: bold;
        }
        .header-info h1 {
            font-size: 28px;
            margin-bottom: 10px;
        }
        .stats {
            display: flex;
            gap: 30px;
            color: #666;
        }
        .stat-item {
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .btn-new {
            padding: 12px 24px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s;
        }
        .btn-new:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(102, 126, 234, 0.4);
        }
        .filter-bar {
            background: white;
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        .filter-group {
            display: flex;
            gap: 10px;
            align-items: center;
        }
        .filter-btn {
            padding: 8px 16px;
            border: 1px solid #ddd;
            background: white;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s;
        }
        .filter-btn:hover, .filter-btn.active {
            background: #667eea;
            color: white;
            border-color: #667eea;
        }
        .gallery-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
            gap: 25px;
            margin-bottom: 40px;
        }
        .artwork-card {
            background: white;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 2px 10px rgba(0,0,0,0.08);
            transition: all 0.3s;
            cursor: pointer;
        }
        .artwork-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.15);
        }
        .artwork-image {
            width: 100%;
            height: 250px;
            object-fit: cover;
        }
        .artwork-placeholder {
            width: 100%;
            height: 250px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 48px;
            font-weight: bold;
        }
        .artwork-info {
            padding: 20px;
        }
        .artwork-title {
            font-size: 18px;
            font-weight: 600;
            margin-bottom: 10px;
            color: #333;
        }
        .artwork-meta {
            display: flex;
            justify-content: space-between;
            align-items: center;
            color: #666;
            font-size: 14px;
            margin-bottom: 15px;
        }
        .meta-item {
            display: flex;
            align-items: center;
            gap: 5px;
        }
        .artwork-actions {
            display: flex;
            gap: 8px;
        }
        .action-btn {
            flex: 1;
            padding: 8px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 13px;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 5px;
        }
        .btn-edit {
            background: #667eea;
            color: white;
        }
        .btn-edit:hover {
            background: #5568d3;
        }
        .btn-delete {
            background: #ff4757;
            color: white;
        }
        .btn-delete:hover {
            background: #ee3344;
        }
        .btn-toggle {
            background: #f8f9fa;
            color: #666;
        }
        .btn-toggle:hover {
            background: #e9ecef;
        }
        .status-badge {
            display: inline-block;
            padding: 4px 10px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: 600;
        }
        .status-public {
            background: #d4edda;
            color: #155724;
        }
        .status-private {
            background: #f8d7da;
            color: #721c24;
        }
        .empty-state {
            text-align: center;
            padding: 80px 20px;
            background: white;
            border-radius: 12px;
        }
        .empty-state i {
            font-size: 64px;
            color: #ddd;
            margin-bottom: 20px;
        }
        .empty-state h3 {
            font-size: 24px;
            margin-bottom: 10px;
            color: #666;
        }
        .pagination {
            display: flex;
            justify-content: center;
            gap: 10px;
            margin-top: 40px;
        }
        .page-btn {
            padding: 10px 15px;
            border: 1px solid #ddd;
            background: white;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s;
            text-decoration: none;
            color: #333;
        }
        .page-btn:hover {
            background: #667eea;
            color: white;
            border-color: #667eea;
        }
        .page-btn.active {
            background: #667eea;
            color: white;
            border-color: #667eea;
        }
        .page-btn:disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }
    </style>
</head>
<body>
    <?php include dirname(__DIR__) . '/includes/header.php'; ?>

    <div class="page-container">
        <!-- Header -->
        <div class="page-header">
            <div class="header-content">
                <div class="header-left">
                    <?php if (!empty($user['avatar'])): ?>
                        <img src="<?php echo PROFILE_UPLOAD_URL . basename($user['avatar']); ?>" 
                             class="user-avatar"
                             alt="<?php echo htmlspecialchars($user['username']); ?>">
                    <?php else: ?>
                        <div class="avatar-placeholder">
                            <?php echo strtoupper(substr($user['username'], 0, 1)); ?>
                        </div>
                    <?php endif; ?>
                    <div class="header-info">
                        <h1>Tác phẩm của tôi</h1>
                        <div class="stats">
                            <div class="stat-item">
                                <i class="fas fa-image"></i>
                                <span><?php echo number_format($total); ?> tác phẩm</span>
                            </div>
                        </div>
                    </div>
                </div>
                <a href="<?php echo BASE_URL; ?>pages/upload.php" class="btn-new">
                    <i class="fas fa-plus"></i> Tác phẩm mới
                </a>
            </div>
        </div>

        <!-- Filters -->
        <div class="filter-bar">
            <div class="filter-group">
                <button class="filter-btn active" onclick="filterArtworks('all')">
                    <i class="fas fa-th"></i> Tất cả
                </button>
                <button class="filter-btn" onclick="filterArtworks('public')">
                    <i class="fas fa-eye"></i> Công khai
                </button>
                <button class="filter-btn" onclick="filterArtworks('private')">
                    <i class="fas fa-eye-slash"></i> Riêng tư
                </button>
            </div>
            <div style="color: #666; font-size: 14px;">
                Hiển thị <?php echo count($artworks); ?> / <?php echo $total; ?> tác phẩm
            </div>
        </div>

        <!-- Gallery -->
        <?php if (empty($artworks)): ?>
            <div class="empty-state">
                <i class="fas fa-images"></i>
                <h3>Bạn chưa có tác phẩm nào</h3>
                <p style="color: #999; margin-bottom: 20px;">Hãy tải lên tác phẩm đầu tiên của bạn!</p>
                <a href="<?php echo BASE_URL; ?>pages/upload.php" class="btn-new">
                    <i class="fas fa-cloud-upload-alt"></i> Tải lên ngay
                </a>
            </div>
        <?php else: ?>
            <div class="gallery-grid" id="galleryGrid">
                <?php foreach ($artworks as $artwork): ?>
                    <div class="artwork-card" data-status="<?php echo $artwork['is_public'] ? 'public' : 'private'; ?>">
                        <?php 
                        $imageUrl = '';
                        if (!empty($artwork['image_path'])) {
                            if (strpos($artwork['image_path'], 'http') === 0) {
                                $imageUrl = $artwork['image_path'];
                            } else {
                                $imageUrl = GALLERY_UPLOAD_URL . basename($artwork['image_path']);
                            }
                        }
                        ?>
                        <a href="<?php echo BASE_URL; ?>pages/image-detail.php?id=<?php echo $artwork['id']; ?>">
                            <?php if ($imageUrl): ?>
                                <img src="<?php echo htmlspecialchars($imageUrl); ?>" 
                                     class="artwork-image"
                                     alt="<?php echo htmlspecialchars($artwork['title']); ?>"
                                     onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
                                <div class="artwork-placeholder" style="display:none;">
                                    <?php echo strtoupper(substr($artwork['title'], 0, 2)); ?>
                                </div>
                            <?php else: ?>
                                <div class="artwork-placeholder">
                                    <?php echo strtoupper(substr($artwork['title'], 0, 2)); ?>
                                </div>
                            <?php endif; ?>
                        </a>
                        <div class="artwork-info">
                            <div class="artwork-title"><?php echo htmlspecialchars($artwork['title']); ?></div>
                            <div class="artwork-meta">
                                <div class="meta-item">
                                    <i class="fas fa-eye"></i>
                                    <span><?php echo number_format($artwork['views']); ?></span>
                                </div>
                                <div class="meta-item">
                                    <i class="fas fa-heart"></i>
                                    <span><?php echo number_format($artwork['likes']); ?></span>
                                </div>
                                <span class="status-badge <?php echo $artwork['is_public'] ? 'status-public' : 'status-private'; ?>">
                                    <?php echo $artwork['is_public'] ? 'Công khai' : 'Riêng tư'; ?>
                                </span>
                            </div>
                            <div class="artwork-actions">
                                <button class="action-btn btn-edit" onclick="editArtwork(<?php echo $artwork['id']; ?>)">
                                    <i class="fas fa-edit"></i> Sửa
                                </button>
                                <button class="action-btn btn-toggle" onclick="toggleVisibility(<?php echo $artwork['id']; ?>, <?php echo $artwork['is_public']; ?>)">
                                    <i class="fas fa-<?php echo $artwork['is_public'] ? 'eye-slash' : 'eye'; ?>"></i>
                                </button>
                                <button class="action-btn btn-delete" onclick="deleteArtwork(<?php echo $artwork['id']; ?>, '<?php echo addslashes($artwork['title']); ?>')">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>

            <!-- Pagination -->
            <?php if ($total_pages > 1): ?>
            <div class="pagination">
                <?php if ($page > 1): ?>
                    <a href="?page=<?php echo $page - 1; ?>" class="page-btn">
                        <i class="fas fa-chevron-left"></i> Trước
                    </a>
                <?php endif; ?>

                <?php for ($i = max(1, $page - 2); $i <= min($total_pages, $page + 2); $i++): ?>
                    <a href="?page=<?php echo $i; ?>" class="page-btn <?php echo $i == $page ? 'active' : ''; ?>">
                        <?php echo $i; ?>
                    </a>
                <?php endfor; ?>

                <?php if ($page < $total_pages): ?>
                    <a href="?page=<?php echo $page + 1; ?>" class="page-btn">
                        Sau <i class="fas fa-chevron-right"></i>
                    </a>
                <?php endif; ?>
            </div>
            <?php endif; ?>
        <?php endif; ?>
    </div>

    <?php include dirname(__DIR__) . '/includes/footer.php'; ?>

    <script>
    const BASE_URL = '<?php echo BASE_URL; ?>';

    // Filter artworks
    function filterArtworks(status) {
        const cards = document.querySelectorAll('.artwork-card');
        const buttons = document.querySelectorAll('.filter-btn');

        buttons.forEach(btn => btn.classList.remove('active'));
        event.target.closest('.filter-btn').classList.add('active');

        cards.forEach(card => {
            if (status === 'all') {
                card.style.display = 'block';
            } else {
                card.style.display = card.dataset.status === status ? 'block' : 'none';
            }
        });
    }

    // Edit artwork
    function editArtwork(id) {
        alert('Chức năng chỉnh sửa đang được phát triển');
        // TODO: Navigate to edit page
        // window.location.href = BASE_URL + 'pages/edit-artwork.php?id=' + id;
    }

    // Toggle visibility
    function toggleVisibility(id, currentStatus) {
        if (!confirm('Thay đổi trạng thái hiển thị?')) return;

        fetch(BASE_URL + 'api/toggle-visibility.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({image_id: id})
        })
        .then(r => r.json())
        .then(data => {
            if (data.success) {
                location.reload();
            } else {
                alert(data.message || 'Có lỗi xảy ra');
            }
        })
        .catch(err => {
            console.error(err);
            alert('Không thể kết nối');
        });
    }

    // Delete artwork
    function deleteArtwork(id, title) {
        if (!confirm(`Bạn có chắc muốn xóa "${title}"?\nHành động này không thể hoàn tác!`)) return;

        fetch(BASE_URL + 'api/delete-image.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({image_id: id})
        })
        .then(r => r.json())
        .then(data => {
            if (data.success) {
                alert('Đã xóa thành công!');
                location.reload();
            } else {
                alert(data.message || 'Không thể xóa');
            }
        })
        .catch(err => {
            console.error(err);
            alert('Không thể kết nối');
        });
    }
    </script>
</body>
</html>