<?php
// pages/profile.php
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Include config first
require_once __DIR__ . '/../includes/config.php';

// Get user ID from URL or session
$user_id = isset($_GET['id']) ? intval($_GET['id']) : (isset($_SESSION['user_id']) ? intval($_SESSION['user_id']) : 0);

if ($user_id <= 0) {
    header('Location: ' . BASE_URL . 'index.php');
    exit;
}

// Check if viewing own profile
$isOwnProfile = isset($_SESSION['user_id']) && $_SESSION['user_id'] == $user_id;
$isLoggedIn = isset($_SESSION['user_id']);

// Fetch user data
$userData = null;
$userArtworks = [];
$hasDatabase = false;
$isFollowing = false;

try {
    $pdo = getDB();
    if ($pdo) {
        $hasDatabase = true;
        
        // Get user info with stats
        $sql = "SELECT 
            u.*,
            (SELECT COUNT(*) FROM artworks WHERE user_id = u.id AND is_public = 1) as artworks_count,
            (SELECT COALESCE(SUM(views), 0) FROM artworks WHERE user_id = u.id) as total_views,
            (SELECT COALESCE(SUM(likes), 0) FROM artworks WHERE user_id = u.id) as total_likes
        FROM users u
        WHERE u.id = ?
        LIMIT 1";
        
        $userData = getRow($sql, [$user_id]);
        
        if (!$userData) {
            echo "<!-- User not found in database -->";
            // Continue with fallback
        } else {
            // Get followers count (check if table exists first)
            try {
                $followersResult = getRow("SELECT COUNT(*) as count FROM follows WHERE following_id = ?", [$user_id]);
                $userData['followers_count'] = $followersResult ? $followersResult['count'] : 0;
                
                $followingResult = getRow("SELECT COUNT(*) as count FROM follows WHERE follower_id = ?", [$user_id]);
                $userData['following_count'] = $followingResult ? $followingResult['count'] : 0;
                
                // Check if current user is following this user
                if ($isLoggedIn && !$isOwnProfile) {
                    $followCheck = getRow(
                        "SELECT id FROM follows WHERE follower_id = ? AND following_id = ? LIMIT 1",
                        [$_SESSION['user_id'], $user_id]
                    );
                    $isFollowing = !empty($followCheck);
                }
            } catch (Exception $e) {
                // Follows table doesn't exist yet
                $userData['followers_count'] = 0;
                $userData['following_count'] = 0;
                error_log('Follows table not found: ' . $e->getMessage());
            }
            
            // Get user's artworks
            $artworksSql = "SELECT * FROM artworks 
                           WHERE user_id = ? AND is_public = 1 
                           ORDER BY created_at DESC 
                           LIMIT 50";
            $userArtworks = getAll($artworksSql, [$user_id]);
        }
    }
} catch (Exception $e) {
    error_log('Profile error: ' . $e->getMessage());
    echo "<!-- Profile Error: " . htmlspecialchars($e->getMessage()) . " -->";
    $hasDatabase = false;
}

// Fallback data if no database or user not found
if (!$userData) {
    $userData = [
        'id' => $user_id,
        'username' => 'Demo User #' . $user_id,
        'email' => 'demo@example.com',
        'role' => 'artist',
        'avatar' => '',
        'bio' => 'Nghệ sĩ đam mê sáng tạo và chia sẻ những tác phẩm nghệ thuật độc đáo.',
        'artworks_count' => 12,
        'followers_count' => 150,
        'following_count' => 80,
        'total_views' => 5000,
        'total_likes' => 450,
        'created_at' => date('Y-m-d', strtotime('-6 months'))
    ];
    
    // Generate sample artworks
    $userArtworks = array_map(function($i) use ($user_id) {
        $gradients = [
            'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
            'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)',
            'linear-gradient(135deg, #4facfe 0%, #00f2fe 100%)',
            'linear-gradient(135deg, #43e97b 0%, #38f9d7 100%)',
            'linear-gradient(135deg, #fa709a 0%, #fee140 100%)'
        ];
        
        return [
            'id' => $i,
            'title' => 'Tác phẩm #' . $i,
            'image_path' => '',
            'views' => rand(100, 1000),
            'likes' => rand(10, 100),
            'category' => ['painting', 'digital', 'photography'][rand(0, 2)],
            'gradient' => $gradients[($i - 1) % count($gradients)]
        ];
    }, range(1, 12));
}

$pageTitle = htmlspecialchars($userData['username']) . ' - ' . SITE_NAME;

// Helper function to get image URL
function getImageUrl($imagePath) {
    if (empty($imagePath)) return '';
    
    if (strpos($imagePath, 'http') === 0) {
        return $imagePath;
    }
    
    $possiblePaths = [
        '../uploads/gallery/' . basename($imagePath),
        GALLERY_UPLOAD_URL . basename($imagePath),
    ];
    
    foreach ($possiblePaths as $path) {
        if (strpos($path, 'http') === 0) {
            return $path;
        }
        if (file_exists($path)) {
            return $path;
        }
    }
    
    return '';
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle; ?></title>
    
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>assets/css/style.css">
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>assets/css/profile.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <?php if (!$hasDatabase): ?>
    <style>
        .demo-banner {
            background: #ff9800;
            color: white;
            padding: 10px;
            text-align: center;
            font-weight: bold;
        }
    </style>
    <?php endif; ?>
</head>
<body>
    <?php if (!$hasDatabase): ?>
    <div class="demo-banner">
        🔧 Chế độ Demo - Dữ liệu mẫu | Database: <?php echo $hasDatabase ? 'Connected' : 'Not Connected'; ?>
    </div>
    <?php endif; ?>

    <?php include __DIR__ . '/../includes/header.php'; ?>

    <div class="profile-container">
        <!-- Profile Header -->
        <div class="profile-header">
            <div class="profile-cover"></div>
            
            <div class="profile-info-wrapper">
                <div class="profile-avatar-section">
                    <?php if (!empty($userData['avatar']) && file_exists(PROFILE_UPLOAD_DIR . basename($userData['avatar']))): ?>
                        <img src="<?php echo PROFILE_UPLOAD_URL . basename($userData['avatar']); ?>" 
                             alt="<?php echo htmlspecialchars($userData['username']); ?>"
                             class="profile-avatar">
                    <?php else: ?>
                        <div class="profile-avatar-placeholder">
                            <?php echo strtoupper(substr($userData['username'], 0, 2)); ?>
                        </div>
                    <?php endif; ?>
                </div>

                <div class="profile-details">
                    <div class="profile-name-section">
                        <h1><?php echo htmlspecialchars($userData['username']); ?></h1>
                        <span class="profile-role">
                            <?php if ($userData['role'] === 'artist'): ?>
                                <i class="fas fa-palette"></i> Nghệ sĩ
                            <?php elseif ($userData['role'] === 'admin'): ?>
                                <i class="fas fa-crown"></i> Quản trị viên
                            <?php else: ?>
                                <i class="fas fa-user"></i> Thành viên
                            <?php endif; ?>
                        </span>
                    </div>

                    <?php if (!empty($userData['bio'])): ?>
                        <p class="profile-bio"><?php echo nl2br(htmlspecialchars($userData['bio'])); ?></p>
                    <?php endif; ?>

                    <div class="profile-stats">
                        <div class="stat-item">
                            <strong><?php echo number_format($userData['artworks_count'] ?? 0); ?></strong>
                            <span>Tác phẩm</span>
                        </div>
                        <div class="stat-item">
                            <strong><?php echo number_format($userData['followers_count'] ?? 0); ?></strong>
                            <span>Người theo dõi</span>
                        </div>
                        <div class="stat-item">
                            <strong><?php echo number_format($userData['following_count'] ?? 0); ?></strong>
                            <span>Đang theo dõi</span>
                        </div>
                        <div class="stat-item">
                            <strong><?php echo number_format($userData['total_views'] ?? 0); ?></strong>
                            <span>Lượt xem</span>
                        </div>
                        <div class="stat-item">
                            <strong><?php echo number_format($userData['total_likes'] ?? 0); ?></strong>
                            <span>Lượt thích</span>
                        </div>
                    </div>

                    <div class="profile-actions">
                        <?php if ($isOwnProfile): ?>
                            <button class="btn-primary" onclick="alert('Chức năng đang phát triển')">
                                <i class="fas fa-edit"></i> Chỉnh sửa hồ sơ
                            </button>
                            <button class="btn-secondary" onclick="alert('Chức năng đang phát triển')">
                                <i class="fas fa-cog"></i> Cài đặt
                            </button>
                        <?php elseif ($isLoggedIn): ?>
                            <button class="btn-follow <?php echo $isFollowing ? 'following' : ''; ?>" 
                                    data-user-id="<?php echo $user_id; ?>"
                                    id="followBtn">
                                <i class="fas fa-user-<?php echo $isFollowing ? 'check' : 'plus'; ?>"></i>
                                <?php echo $isFollowing ? 'Đang theo dõi' : 'Theo dõi'; ?>
                            </button>
                            <button class="btn-secondary" onclick="startChat(<?php echo $user_id; ?>)">
                                <i class="fas fa-comment"></i> Nhắn tin
                            </button>
                        <?php else: ?>
                            <button class="btn-primary" onclick="window.location.href='<?php echo BASE_URL; ?>index.php'">
                                <i class="fas fa-sign-in-alt"></i> Đăng nhập để theo dõi
                            </button>
                        <?php endif; ?>
                    </div>

                    <div class="profile-meta">
                        <span><i class="fas fa-calendar"></i> Tham gia <?php echo date('d/m/Y', strtotime($userData['created_at'])); ?></span>
                    </div>
                </div>
            </div>
        </div>

        <!-- Profile Content -->
        <div class="profile-content">
            <!-- Tabs Navigation -->
            <div class="profile-tabs">
                <button class="tab-btn active" data-tab="artworks">
                    <i class="fas fa-images"></i> Tác phẩm (<?php echo count($userArtworks); ?>)
                </button>
                <button class="tab-btn" data-tab="liked">
                    <i class="fas fa-heart"></i> Đã thích
                </button>
                <button class="tab-btn" data-tab="collections">
                    <i class="fas fa-folder"></i> Bộ sưu tập
                </button>
            </div>

            <!-- Artworks Tab -->
            <div class="tab-content active" data-tab-content="artworks">
                <?php if (empty($userArtworks)): ?>
                    <div class="empty-state">
                        <i class="fas fa-image"></i>
                        <h3>Chưa có tác phẩm nào</h3>
                        <?php if ($isOwnProfile): ?>
                            <button class="btn-primary" onclick="window.location.href='<?php echo BASE_URL; ?>index.php#gallery'">
                                <i class="fas fa-plus"></i> Tạo tác phẩm đầu tiên
                            </button>
                        <?php endif; ?>
                    </div>
                <?php else: ?>
                    <div class="artworks-grid">
                        <?php foreach ($userArtworks as $artwork): ?>
                            <a href="<?php echo BASE_URL; ?>pages/image-detail.php?id=<?php echo $artwork['id']; ?>" class="artwork-card">
                                <?php 
                                $artworkImage = getImageUrl($artwork['image_path'] ?? '');
                                if (!empty($artworkImage)): 
                                ?>
                                    <img src="<?php echo htmlspecialchars($artworkImage); ?>" 
                                         alt="<?php echo htmlspecialchars($artwork['title']); ?>"
                                         onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
                                    <div class="artwork-placeholder" style="display:none; background: <?php echo $artwork['gradient'] ?? 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)'; ?>">
                                        <?php echo strtoupper(substr($artwork['title'], 0, 2)); ?>
                                    </div>
                                <?php else: ?>
                                    <div class="artwork-placeholder" style="background: <?php echo $artwork['gradient'] ?? 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)'; ?>">
                                        <?php echo strtoupper(substr($artwork['title'], 0, 2)); ?>
                                    </div>
                                <?php endif; ?>
                                
                                <div class="artwork-overlay">
                                    <h4><?php echo htmlspecialchars($artwork['title']); ?></h4>
                                    <div class="artwork-stats">
                                        <span><i class="fas fa-eye"></i> <?php echo number_format($artwork['views'] ?? 0); ?></span>
                                        <span><i class="fas fa-heart"></i> <?php echo number_format($artwork['likes'] ?? 0); ?></span>
                                    </div>
                                </div>
                            </a>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Other Tabs -->
            <div class="tab-content" data-tab-content="liked">
                <div class="empty-state">
                    <i class="fas fa-heart"></i>
                    <h3>Chưa có tác phẩm đã thích</h3>
                </div>
            </div>

            <div class="tab-content" data-tab-content="collections">
                <div class="empty-state">
                    <i class="fas fa-folder"></i>
                    <h3>Chưa có bộ sưu tập</h3>
                </div>
            </div>
        </div>
    </div>

    <?php include __DIR__ . '/../includes/footer.php'; ?>

    <script>
    console.log('Profile loaded - User ID: <?php echo $user_id; ?>, Has DB: <?php echo $hasDatabase ? "true" : "false"; ?>');

    // Tab switching
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const tab = this.dataset.tab;
            
            document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
            document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
            
            this.classList.add('active');
            document.querySelector(`[data-tab-content="${tab}"]`).classList.add('active');
        });
    });

    // Follow button
    <?php if ($isLoggedIn && !$isOwnProfile): ?>
    document.getElementById('followBtn')?.addEventListener('click', async function() {
        const userId = this.dataset.userId;
        const isFollowing = this.classList.contains('following');
        
        try {
            const response = await fetch('<?php echo BASE_URL; ?>api/follow.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({
                    user_id: userId,
                    action: isFollowing ? 'unfollow' : 'follow'
                })
            });
            
            const data = await response.json();
            if (data.success) {
                this.classList.toggle('following');
                const icon = this.querySelector('i');
                const text = this.childNodes[this.childNodes.length - 1];
                
                if (this.classList.contains('following')) {
                    icon.className = 'fas fa-user-check';
                    text.textContent = ' Đang theo dõi';
                } else {
                    icon.className = 'fas fa-user-plus';
                    text.textContent = ' Theo dõi';
                }
            } else {
                alert(data.message || 'Có lỗi xảy ra');
            }
        } catch (error) {
            console.error('Follow error:', error);
            alert('Không thể kết nối đến server');
        }
    });
    <?php endif; ?>

    function startChat(userId) {
        alert('Tính năng nhắn tin đang được phát triển');
    }
    </script>
</body>
</html>