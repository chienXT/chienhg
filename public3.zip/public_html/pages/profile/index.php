<?php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/session.php';
require_once __DIR__ . '/../../includes/functions.php';

// Kiểm tra đăng nhập
if (!isset($_SESSION['user_id'])) {
    header('Location: /pages/auth/login.php');
    exit();
}

// Lấy thông tin user từ database
try {
    $stmt = $pdo->prepare("
        SELECT u.*, 
               (SELECT COUNT(*) FROM artworks WHERE user_id = u.id) as artwork_count,
               (SELECT COUNT(*) FROM followers WHERE following_id = u.id) as follower_count,
               (SELECT COUNT(*) FROM followers WHERE follower_id = u.id) as following_count
        FROM users u 
        WHERE u.id = ?
    ");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$user) {
        $_SESSION['error'] = 'Không tìm thấy thông tin người dùng';
        header('Location: /');
        exit();
    }
    
    // Lấy các tác phẩm của user
    $stmt = $pdo->prepare("
        SELECT * FROM artworks 
        WHERE user_id = ? 
        ORDER BY created_at DESC 
        LIMIT 6
    ");
    $stmt->execute([$_SESSION['user_id']]);
    $artworks = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
} catch (PDOException $e) {
    error_log('Profile error: ' . $e->getMessage());
    $_SESSION['error'] = 'Đã xảy ra lỗi khi tải thông tin';
    header('Location: /');
    exit();
}

$pageTitle = 'Hồ Sơ - ' . htmlspecialchars($user['username']);
$cssFiles = ['/assets/css/gallery.css'];

include __DIR__ . '/../../includes/header.php';
?>

<div class="profile-page">
    <!-- Profile Header -->
    <div class="profile-header">
        <div class="container">
            <div class="profile-info">
                <div class="profile-avatar">
                    <?php if (!empty($user['avatar'])): ?>
                        <img src="/<?php echo htmlspecialchars($user['avatar']); ?>" 
                             alt="<?php echo htmlspecialchars($user['username']); ?>">
                    <?php else: ?>
                        <div class="avatar-placeholder">
                            <?php echo strtoupper(substr($user['username'], 0, 1)); ?>
                        </div>
                    <?php endif; ?>
                    <button class="edit-avatar-btn" title="Đổi ảnh đại diện">
                        📷
                    </button>
                </div>
                
                <div class="profile-details">
                    <div class="profile-name">
                        <h1><?php echo htmlspecialchars($user['username']); ?></h1>
                        <?php if ($user['role'] === 'admin'): ?>
                            <span class="badge admin-badge">Quản trị viên</span>
                        <?php endif; ?>
                        <?php if (!empty($user['verified'])): ?>
                            <span class="badge verified-badge">✓ Đã xác minh</span>
                        <?php endif; ?>
                    </div>
                    
                    <p class="profile-bio">
                        <?php echo !empty($user['bio']) 
                            ? htmlspecialchars($user['bio'])
                            : 'Chưa có giới thiệu...'; ?>
                    </p>
                    
                    <div class="profile-stats">
                        <div class="stat-item">
                            <span class="stat-number"><?php echo $user['artwork_count']; ?></span>
                            <span class="stat-label">Tác phẩm</span>
                        </div>
                        <div class="stat-item">
                            <span class="stat-number"><?php echo $user['follower_count']; ?></span>
                            <span class="stat-label">Người theo dõi</span>
                        </div>
                        <div class="stat-item">
                            <span class="stat-number"><?php echo $user['following_count']; ?></span>
                            <span class="stat-label">Đang theo dõi</span>
                        </div>
                    </div>
                    
                    <div class="profile-actions">
                        <a href="/pages/profile/edit.php" class="btn btn-outline">
                            ✏️ Chỉnh sửa hồ sơ
                        </a>
                        <a href="/pages/gallery/upload.php" class="btn btn-primary">
                            📤 Upload tác phẩm
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Profile Content -->
    <div class="container">
        <div class="profile-content">
            <!-- User Info -->
            <div class="profile-sidebar">
                <div class="info-card">
                    <h3><span>ℹ️</span> Thông tin cá nhân</h3>
                    
                    <div class="info-item">
                        <span class="info-label">Email:</span>
                        <span class="info-value"><?php echo htmlspecialchars($user['email']); ?></span>
                    </div>
                    
                    <?php if (!empty($user['full_name'])): ?>
                    <div class="info-item">
                        <span class="info-label">Họ tên:</span>
                        <span class="info-value"><?php echo htmlspecialchars($user['full_name']); ?></span>
                    </div>
                    <?php endif; ?>
                    
                    <?php if (!empty($user['location'])): ?>
                    <div class="info-item">
                        <span class="info-label">Địa điểm:</span>
                        <span class="info-value"><?php echo htmlspecialchars($user['location']); ?></span>
                    </div>
                    <?php endif; ?>
                    
                    <?php if (!empty($user['website'])): ?>
                    <div class="info-item">
                        <span class="info-label">Website:</span>
                        <a href="<?php echo htmlspecialchars($user['website']); ?>" 
                           target="_blank" class="info-value">
                            <?php echo htmlspecialchars($user['website']); ?>
                        </a>
                    </div>
                    <?php endif; ?>
                    
                    <div class="info-item">
                        <span class="info-label">Tham gia:</span>
                        <span class="info-value">
                            <?php echo date('d/m/Y', strtotime($user['created_at'])); ?>
                        </span>
                    </div>
                </div>
                
                <?php if (!empty($user['social_links'])): 
                    $social_links = json_decode($user['social_links'], true);
                ?>
                <div class="info-card">
                    <h3><span>🌐</span> Mạng xã hội</h3>
                    
                    <div class="social-links">
                        <?php if (!empty($social_links['facebook'])): ?>
                        <a href="<?php echo htmlspecialchars($social_links['facebook']); ?>" 
                           target="_blank" class="social-link facebook">
                            <span>f</span> Facebook
                        </a>
                        <?php endif; ?>
                        
                        <?php if (!empty($social_links['instagram'])): ?>
                        <a href="<?php echo htmlspecialchars($social_links['instagram']); ?>" 
                           target="_blank" class="social-link instagram">
                            <span>📷</span> Instagram
                        </a>
                        <?php endif; ?>
                        
                        <?php if (!empty($social_links['twitter'])): ?>
                        <a href="<?php echo htmlspecialchars($social_links['twitter']); ?>" 
                           target="_blank" class="social-link twitter">
                            <span>🐦</span> Twitter
                        </a>
                        <?php endif; ?>
                        
                        <?php if (!empty($social_links['youtube'])): ?>
                        <a href="<?php echo htmlspecialchars($social_links['youtube']); ?>" 
                           target="_blank" class="social-link youtube">
                            <span>▶️</span> YouTube
                        </a>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endif; ?>
                
                <div class="info-card">
                    <h3><span>⚙️</span> Cài đặt tài khoản</h3>
                    
                    <div class="settings-list">
                        <a href="/pages/profile/edit.php" class="setting-item">
                            <span>✏️</span> Chỉnh sửa hồ sơ
                        </a>
                        <a href="/pages/profile/change-password.php" class="setting-item">
                            <span>🔒</span> Đổi mật khẩu
                        </a>
                        <a href="/pages/profile/privacy.php" class="setting-item">
                            <span>👁️</span> Quyền riêng tư
                        </a>
                        <button class="setting-item logout-btn" id="profileLogoutBtn">
                            <span>🚪</span> Đăng xuất
                        </button>
                    </div>
                </div>
            </div>
            
            <!-- User Artworks -->
            <div class="profile-main">
                <div class="section-header">
                    <h2>Tác phẩm gần đây</h2>
                    <a href="/pages/gallery/my-gallery.php" class="view-all">
                        Xem tất cả →
                    </a>
                </div>
                
                <?php if (count($artworks) > 0): ?>
                <div class="gallery-grid profile-grid">
                    <?php foreach ($artworks as $artwork): ?>
                    <div class="gallery-item">
                        <div class="gallery-image-container">
                            <?php if (!empty($artwork['image_url'])): ?>
                                <img src="<?php echo htmlspecialchars($artwork['image_url']); ?>" 
                                     alt="<?php echo htmlspecialchars($artwork['title']); ?>"
                                     class="gallery-image">
                            <?php elseif (!empty($artwork['image_path'])): ?>
                                <img src="/<?php echo htmlspecialchars($artwork['image_path']); ?>" 
                                     alt="<?php echo htmlspecialchars($artwork['title']); ?>"
                                     class="gallery-image">
                            <?php else: ?>
                                <div class="gallery-placeholder">
                                    🖼️
                                </div>
                            <?php endif; ?>
                            
                            <div class="gallery-overlay">
                                <div class="gallery-actions">
                                    <a href="/pages/gallery/view.php?id=<?php echo $artwork['id']; ?>" 
                                       class="action-btn" title="Xem chi tiết">
                                        👁️
                                    </a>
                                    <a href="/pages/gallery/edit.php?id=<?php echo $artwork['id']; ?>" 
                                       class="action-btn" title="Chỉnh sửa">
                                        ✏️
                                    </a>
                                    <a href="/pages/gallery/delete.php?id=<?php echo $artwork['id']; ?>" 
                                       class="action-btn" title="Xóa"
                                       onclick="return confirm('Bạn có chắc muốn xóa?')">
                                        🗑️
                                    </a>
                                </div>
                            </div>
                        </div>
                        
                        <div class="gallery-info">
                            <h3 class="gallery-title">
                                <?php echo htmlspecialchars($artwork['title']); ?>
                            </h3>
                            
                            <p class="gallery-description">
                                <?php echo !empty($artwork['description']) 
                                    ? htmlspecialchars(substr($artwork['description'], 0, 100)) . '...'
                                    : 'Không có mô tả'; ?>
                            </p>
                            
                            <div class="gallery-meta">
                                <span class="gallery-category">
                                    <?php 
                                    $categories = [
                                        'painting' => '🎨 Tranh',
                                        'digital' => '💻 Số',
                                        'photography' => '📸 Ảnh',
                                        'sculpture' => '🗿 Điêu khắc',
                                        'illustration' => '✏️ Minh họa',
                                        'other' => '🎭 Khác'
                                    ];
                                    echo $categories[$artwork['category']] ?? '🎭 Khác';
                                    ?>
                                </span>
                                
                                <span class="gallery-date">
                                    <?php echo date('d/m/Y', strtotime($artwork['created_at'])); ?>
                                </span>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
                <?php else: ?>
                <div class="empty-state">
                    <div class="empty-icon">🖼️</div>
                    <h3>Chưa có tác phẩm nào</h3>
                    <p>Bắt đầu sáng tạo và chia sẻ tác phẩm đầu tiên của bạn!</p>
                    <a href="/pages/gallery/upload.php" class="btn btn-primary">
                        📤 Upload tác phẩm đầu tiên
                    </a>
                </div>
                <?php endif; ?>
                
                <!-- Activity Feed -->
                <div class="activity-feed">
                    <div class="section-header">
                        <h2>Hoạt động gần đây</h2>
                    </div>
                    
                    <div class="activities">
                        <!-- Các activity sẽ được load bằng JavaScript -->
                        <div class="loading-spinner"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Logout button
    const logoutBtn = document.getElementById('profileLogoutBtn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', async function() {
            if (confirm('Bạn có chắc chắn muốn đăng xuất?')) {
                try {
                    const response = await fetch('/pages/auth/logout.php', {
                        method: 'POST',
                        credentials: 'same-origin'
                    });
                    
                    const result = await response.json();
                    if (result.success) {
                        window.location.href = '/';
                    }
                } catch (error) {
                    console.error('Logout error:', error);
                    alert('Đã xảy ra lỗi khi đăng xuất');
                }
            }
        });
    }
    
    // Load activities
    const activitiesContainer = document.querySelector('.activities');
    
    async function loadActivities() {
        try {
            const response = await fetch('/api/activities.php?user_id=<?php echo $_SESSION['user_id']; ?>');
            const activities = await response.json();
            
            if (activities.length > 0) {
                activitiesContainer.innerHTML = activities.map(activity => `
                    <div class="activity-item">
                        <div class="activity-icon">
                            ${activity.icon}
                        </div>
                        <div class="activity-content">
                            <p>${activity.content}</p>
                            <span class="activity-time">${activity.time}</span>
                        </div>
                    </div>
                `).join('');
            } else {
                activitiesContainer.innerHTML = `
                    <div class="empty-state">
                        <p>Chưa có hoạt động nào</p>
                    </div>
                `;
            }
        } catch (error) {
            console.error('Error loading activities:', error);
            activitiesContainer.innerHTML = `
                <div class="empty-state">
                    <p>Không thể tải hoạt động</p>
                </div>
            `;
        }
    }
    
    loadActivities();
});
</script>

<style>
.profile-page {
    padding-top: 70px;
}

.profile-header {
    background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
    color: white;
    padding: 60px 0;
}

.profile-info {
    display: grid;
    grid-template-columns: auto 1fr;
    gap: 40px;
    align-items: center;
}

@media (max-width: 768px) {
    .profile-info {
        grid-template-columns: 1fr;
        text-align: center;
    }
}

.profile-avatar {
    position: relative;
    width: 150px;
    height: 150px;
}

.profile-avatar img {
    width: 100%;
    height: 100%;
    border-radius: 50%;
    object-fit: cover;
    border: 5px solid rgba(255, 255, 255, 0.3);
}

.avatar-placeholder {
    width: 100%;
    height: 100%;
    border-radius: 50%;
    background: white;
    color: var(--primary-color);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 60px;
    font-weight: bold;
    border: 5px solid rgba(255, 255, 255, 0.3);
}

.edit-avatar-btn {
    position: absolute;
    bottom: 10px;
    right: 10px;
    width: 40px;
    height: 40px;
    border-radius: 50%;
    background: white;
    border: none;
    cursor: pointer;
    font-size: 18px;
    display: flex;
    align-items: center;
    justify-content: center;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
    transition: var(--transition);
}

.edit-avatar-btn:hover {
    transform: scale(1.1);
    background: #f8f9fa;
}

.profile-name {
    display: flex;
    align-items: center;
    gap: 15px;
    flex-wrap: wrap;
    margin-bottom: 15px;
}

.profile-name h1 {
    font-size: 36px;
    margin: 0;
}

.badge {
    padding: 4px 12px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: 600;
}

.admin-badge {
    background: #ffc107;
    color: #000;
}

.verified-badge {
    background: #28a745;
    color: white;
}

.profile-bio {
    font-size: 18px;
    opacity: 0.9;
    margin-bottom: 25px;
    max-width: 600px;
    line-height: 1.6;
}

.profile-stats {
    display: flex;
    gap: 40px;
    margin-bottom: 30px;
}

.stat-item {
    text-align: center;
}

.stat-number {
    display: block;
    font-size: 28px;
    font-weight: bold;
    margin-bottom: 5px;
}

.stat-label {
    font-size: 14px;
    opacity: 0.8;
}

.profile-actions {
    display: flex;
    gap: 15px;
    flex-wrap: wrap;
}

.btn-outline {
    background: transparent;
    border: 2px solid white;
    color: white;
    padding: 12px 28px;
    border-radius: var(--border-radius);
    font-weight: 600;
    cursor: pointer;
    text-decoration: none;
    transition: var(--transition);
    display: inline-flex;
    align-items: center;
    gap: 8px;
}

.btn-outline:hover {
    background: white;
    color: var(--primary-color);
    transform: translateY(-2px);
}

.profile-content {
    display: grid;
    grid-template-columns: 300px 1fr;
    gap: 40px;
    padding: 60px 0;
}

@media (max-width: 992px) {
    .profile-content {
        grid-template-columns: 1fr;
    }
}

.profile-sidebar {
    position: sticky;
    top: 100px;
    height: fit-content;
}

.info-card {
    background: white;
    border-radius: var(--border-radius);
    box-shadow: var(--shadow);
    padding: 25px;
    margin-bottom: 25px;
}

.info-card h3 {
    font-size: 18px;
    color: var(--text-color);
    margin-bottom: 20px;
    display: flex;
    align-items: center;
    gap: 10px;
}

.info-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 12px 0;
    border-bottom: 1px solid #f5f5f5;
}

.info-item:last-child {
    border-bottom: none;
}

.info-label {
    color: var(--text-light);
    font-size: 14px;
}

.info-value {
    color: var(--text-color);
    font-weight: 500;
    font-size: 14px;
    text-align: right;
    max-width: 150px;
    overflow: hidden;
    text-overflow: ellipsis;
}

.info-value a {
    color: var(--primary-color);
    text-decoration: none;
}

.info-value a:hover {
    text-decoration: underline;
}

.social-links {
    display: flex;
    flex-direction: column;
    gap: 10px;
}

.social-link {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 12px 16px;
    border-radius: var(--border-radius);
    text-decoration: none;
    color: white;
    font-weight: 500;
    transition: var(--transition);
}

.social-link span {
    width: 24px;
    height: 24px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: bold;
}

.facebook {
    background: #4267B2;
}

.instagram {
    background: linear-gradient(45deg, #405DE6, #5851DB, #833AB4, #C13584, #E1306C, #FD1D1D);
}

.twitter {
    background: #1DA1F2;
}

.youtube {
    background: #FF0000;
}

.social-link:hover {
    transform: translateX(5px);
    opacity: 0.9;
}

.settings-list {
    display: flex;
    flex-direction: column;
    gap: 10px;
}

.setting-item {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 12px 16px;
    border-radius: var(--border-radius);
    text-decoration: none;
    color: var(--text-color);
    transition: var(--transition);
    background: none;
    border: none;
    text-align: left;
    cursor: pointer;
    font-size: 15px;
}

.setting-item:hover {
    background: #f8f9fa;
    color: var(--primary-color);
}

.logout-btn:hover {
    background: #fde8e8 !important;
    color: #e74c3c !important;
}

.profile-main {
    flex: 1;
}

.section-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 30px;
}

.section-header h2 {
    font-size: 24px;
    color: var(--text-color);
}

.view-all {
    color: var(--primary-color);
    text-decoration: none;
    font-weight: 500;
    display: flex;
    align-items: center;
    gap: 5px;
}

.view-all:hover {
    text-decoration: underline;
}

.profile-grid {
    grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
    gap: 25px;
    margin-bottom: 50px;
}

.gallery-image-container {
    position: relative;
    height: 200px;
    overflow: hidden;
    border-radius: var(--border-radius) var(--border-radius) 0 0;
}

.gallery-placeholder {
    width: 100%;
    height: 100%;
    background: #f5f5f5;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 60px;
}

.empty-state {
    text-align: center;
    padding: 60px 20px;
    background: white;
    border-radius: var(--border-radius);
    box-shadow: var(--shadow);
}

.empty-icon {
    font-size: 80px;
    margin-bottom: 20px;
    opacity: 0.5;
}

.empty-state h3 {
    font-size: 24px;
    color: var(--text-color);
    margin-bottom: 10px;
}

.empty-state p {
    color: var(--text-light);
    margin-bottom: 30px;
    max-width: 400px;
    margin-left: auto;
    margin-right: auto;
}

.activity-feed {
    background: white;
    border-radius: var(--border-radius);
    box-shadow: var(--shadow);
    padding: 30px;
}

.activity-item {
    display: grid;
    grid-template-columns: auto 1fr;
    gap: 15px;
    padding: 20px 0;
    border-bottom: 1px solid #f5f5f5;
}

.activity-item:last-child {
    border-bottom: none;
}

.activity-icon {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    background: #f8f9fa;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 18px;
}

.activity-content p {
    margin: 0 0 5px 0;
    color: var(--text-color);
}

.activity-time {
    font-size: 12px;
    color: var(--text-light);
}
</style>

<?php
include __DIR__ . '/../../includes/footer.php';
?>