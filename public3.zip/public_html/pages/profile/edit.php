<?php
// pages/profile/edit.php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once '../../includes/config.php';
require_once '../../includes/functions.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: ../../index.php');
    exit;
}

$user_id = $_SESSION['user_id'];
$errors = [];
$success = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $bio = trim($_POST['bio'] ?? '');
    $current_password = $_POST['current_password'] ?? '';
    $new_password = $_POST['new_password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    
    // Validation
    if (empty($username)) {
        $errors[] = 'Tên người dùng không được để trống';
    }
    
    if (empty($email)) {
        $errors[] = 'Email không được để trống';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Email không hợp lệ';
    }
    
    // Check if email/username already exists (except current user)
    try {
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ? AND id != ?");
        $stmt->execute([$email, $user_id]);
        if ($stmt->fetch()) {
            $errors[] = 'Email đã được sử dụng';
        }
        
        $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ? AND id != ?");
        $stmt->execute([$username, $user_id]);
        if ($stmt->fetch()) {
            $errors[] = 'Tên người dùng đã được sử dụng';
        }
    } catch (PDOException $e) {
        $errors[] = 'Lỗi kiểm tra dữ liệu';
    }
    
    // Handle avatar upload
    $avatar_path = null;
    if (isset($_FILES['avatar']) && $_FILES['avatar']['error'] === UPLOAD_ERR_OK) {
        $allowed = ['jpg', 'jpeg', 'png', 'gif'];
        $filename = $_FILES['avatar']['name'];
        $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
        
        if (!in_array($ext, $allowed)) {
            $errors[] = 'Chỉ chấp nhận file ảnh (JPG, PNG, GIF)';
        } elseif ($_FILES['avatar']['size'] > 5 * 1024 * 1024) {
            $errors[] = 'File ảnh không được vượt quá 5MB';
        } else {
            $upload_dir = '../../uploads/avatars/';
            if (!is_dir($upload_dir)) {
                mkdir($upload_dir, 0755, true);
            }
            
            $new_filename = 'avatar_' . $user_id . '_' . time() . '.' . $ext;
            $upload_path = $upload_dir . $new_filename;
            
            if (move_uploaded_file($_FILES['avatar']['tmp_name'], $upload_path)) {
                $avatar_path = 'uploads/avatars/' . $new_filename;
                
                // Delete old avatar
                try {
                    $stmt = $pdo->prepare("SELECT avatar FROM users WHERE id = ?");
                    $stmt->execute([$user_id]);
                    $old_avatar = $stmt->fetchColumn();
                    if ($old_avatar && file_exists('../../' . $old_avatar)) {
                        unlink('../../' . $old_avatar);
                    }
                } catch (PDOException $e) {
                    error_log("Error deleting old avatar: " . $e->getMessage());
                }
            } else {
                $errors[] = 'Lỗi upload ảnh';
            }
        }
    }
    
    // Handle password change
    if (!empty($new_password)) {
        if (empty($current_password)) {
            $errors[] = 'Vui lòng nhập mật khẩu hiện tại';
        } else {
            // Verify current password
            try {
                $stmt = $pdo->prepare("SELECT password FROM users WHERE id = ?");
                $stmt->execute([$user_id]);
                $current_hash = $stmt->fetchColumn();
                
                if (!password_verify($current_password, $current_hash)) {
                    $errors[] = 'Mật khẩu hiện tại không đúng';
                } elseif (strlen($new_password) < 6) {
                    $errors[] = 'Mật khẩu mới phải có ít nhất 6 ký tự';
                } elseif ($new_password !== $confirm_password) {
                    $errors[] = 'Mật khẩu xác nhận không khớp';
                }
            } catch (PDOException $e) {
                $errors[] = 'Lỗi xác thực mật khẩu';
            }
        }
    }
    
    // Update profile if no errors
    if (empty($errors)) {
        try {
            $pdo->beginTransaction();
            
            // Build update query
            $fields = ['username = ?', 'email = ?', 'bio = ?'];
            $params = [$username, $email, $bio];
            
            if ($avatar_path) {
                $fields[] = 'avatar = ?';
                $params[] = $avatar_path;
            }
            
            if (!empty($new_password)) {
                $fields[] = 'password = ?';
                $params[] = password_hash($new_password, PASSWORD_DEFAULT);
            }
            
            $params[] = $user_id;
            
            $sql = "UPDATE users SET " . implode(', ', $fields) . " WHERE id = ?";
            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);
            
            // Update session
            $_SESSION['username'] = $username;
            $_SESSION['email'] = $email;
            if ($avatar_path) {
                $_SESSION['avatar'] = $avatar_path;
            }
            
            $pdo->commit();
            
            $success = 'Cập nhật profile thành công!';
            
        } catch (PDOException $e) {
            $pdo->rollBack();
            error_log("Profile update error: " . $e->getMessage());
            $errors[] = 'Lỗi cập nhật profile';
        }
    }
}

// Get current user data
try {
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$user) {
        die('User not found');
    }
} catch (PDOException $e) {
    error_log("Get user error: " . $e->getMessage());
    die('Error loading user data');
}

$pageTitle = 'Chỉnh sửa Profile';
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle; ?></title>
    
    <link rel="stylesheet" href="../../assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    
    <style>
        .edit-profile-container {
            max-width: 800px;
            margin: 100px auto 50px;
            padding: 0 20px;
        }
        
        .page-header {
            margin-bottom: 30px;
        }
        
        .page-header h1 {
            font-size: 2rem;
            color: #333;
            margin-bottom: 10px;
        }
        
        .breadcrumb {
            display: flex;
            gap: 10px;
            color: #666;
            font-size: 0.95rem;
        }
        
        .breadcrumb a {
            color: #667eea;
            text-decoration: none;
        }
        
        .breadcrumb a:hover {
            text-decoration: underline;
        }
        
        .alert {
            padding: 15px 20px;
            border-radius: 10px;
            margin-bottom: 20px;
        }
        
        .alert-danger {
            background: #ffe5e5;
            border-left: 4px solid #ff4444;
            color: #c00;
        }
        
        .alert-success {
            background: #e5ffe5;
            border-left: 4px solid #00c851;
            color: #060;
        }
        
        .alert ul {
            margin: 0;
            padding-left: 20px;
        }
        
        .edit-form {
            background: white;
            border-radius: 20px;
            padding: 40px;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.08);
        }
        
        .form-section {
            margin-bottom: 35px;
            padding-bottom: 35px;
            border-bottom: 2px solid #f0f0f0;
        }
        
        .form-section:last-child {
            border-bottom: none;
            margin-bottom: 0;
        }
        
        .section-title {
            font-size: 1.3rem;
            font-weight: 600;
            color: #333;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .section-title i {
            color: #667eea;
        }
        
        .avatar-upload {
            display: flex;
            align-items: center;
            gap: 30px;
            margin-bottom: 20px;
        }
        
        .current-avatar {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            object-fit: cover;
            border: 4px solid #667eea;
        }
        
        .current-avatar-initial {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 3rem;
            font-weight: 700;
        }
        
        .avatar-upload-text {
            flex: 1;
        }
        
        .avatar-upload-text p {
            color: #666;
            margin-bottom: 10px;
        }
        
        .file-input-wrapper {
            position: relative;
            display: inline-block;
        }
        
        .file-input-wrapper input[type="file"] {
            position: absolute;
            left: -9999px;
        }
        
        .file-input-label {
            display: inline-block;
            padding: 10px 25px;
            background: #667eea;
            color: white;
            border-radius: 25px;
            cursor: pointer;
            transition: all 0.3s ease;
            font-weight: 600;
        }
        
        .file-input-label:hover {
            background: #5568d3;
            transform: translateY(-2px);
        }
        
        .file-name {
            display: inline-block;
            margin-left: 15px;
            color: #666;
            font-size: 0.9rem;
        }
        
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }
        
        .form-actions {
            display: flex;
            gap: 15px;
            margin-top: 30px;
        }
        
        .btn-save {
            flex: 1;
            padding: 15px;
            background: linear-gradient(90deg, #667eea, #764ba2);
            color: white;
            border: none;
            border-radius: 10px;
            font-size: 1.1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .btn-save:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.3);
        }
        
        .btn-cancel {
            padding: 15px 40px;
            background: white;
            color: #667eea;
            border: 2px solid #667eea;
            border-radius: 10px;
            font-size: 1.1rem;
            font-weight: 600;
            text-decoration: none;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            justify-content: center;
        }
        
        .btn-cancel:hover {
            background: #f5f5f5;
        }
        
        .password-toggle {
            position: relative;
        }
        
        .password-toggle input {
            padding-right: 45px;
        }
        
        .toggle-password {
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            color: #667eea;
            cursor: pointer;
            font-size: 1.1rem;
        }
        
        @media (max-width: 768px) {
            .edit-form {
                padding: 25px;
            }
            
            .form-row {
                grid-template-columns: 1fr;
            }
            
            .avatar-upload {
                flex-direction: column;
                text-align: center;
            }
            
            .form-actions {
                flex-direction: column;
            }
            
            .btn-cancel {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <?php include '../../includes/header.php'; ?>
    
    <div class="edit-profile-container">
        <div class="page-header">
            <h1><i class="fas fa-user-edit"></i> Chỉnh sửa Profile</h1>
            <div class="breadcrumb">
                <a href="../../index.php">Trang chủ</a> /
                <a href="index.php">Profile</a> /
                <span>Chỉnh sửa</span>
            </div>
        </div>
        
        <?php if (!empty($errors)): ?>
            <div class="alert alert-danger">
                <strong><i class="fas fa-exclamation-circle"></i> Lỗi:</strong>
                <ul>
                    <?php foreach ($errors as $error): ?>
                        <li><?php echo htmlspecialchars($error); ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>
        
        <?php if ($success): ?>
            <div class="alert alert-success">
                <strong><i class="fas fa-check-circle"></i> Thành công:</strong>
                <?php echo htmlspecialchars($success); ?>
            </div>
        <?php endif; ?>
        
        <form method="POST" enctype="multipart/form-data" class="edit-form">
            <!-- Avatar Section -->
            <div class="form-section">
                <h2 class="section-title">
                    <i class="fas fa-image"></i> Ảnh đại diện
                </h2>
                
                <div class="avatar-upload">
                    <div>
                        <?php if (!empty($user['avatar'])): ?>
                            <img src="../../<?php echo htmlspecialchars($user['avatar']); ?>" 
                                 alt="Avatar" 
                                 class="current-avatar"
                                 id="avatarPreview">
                        <?php else: ?>
                            <div class="current-avatar-initial" id="avatarPreview">
                                <?php echo strtoupper(substr($user['username'], 0, 1)); ?>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <div class="avatar-upload-text">
                        <p><strong>Chọn ảnh đại diện mới</strong></p>
                        <p style="font-size: 0.9rem;">JPG, PNG hoặc GIF. Kích thước tối đa 5MB</p>
                        <div class="file-input-wrapper">
                            <input type="file" 
                                   name="avatar" 
                                   id="avatarInput" 
                                   accept="image/*"
                                   onchange="previewAvatar(this)">
                            <label for="avatarInput" class="file-input-label">
                                <i class="fas fa-upload"></i> Chọn ảnh
                            </label>
                            <span class="file-name" id="fileName"></span>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Basic Info Section -->
            <div class="form-section">
                <h2 class="section-title">
                    <i class="fas fa-info-circle"></i> Thông tin cơ bản
                </h2>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="username">Tên người dùng *</label>
                        <input type="text" 
                               id="username" 
                               name="username" 
                               value="<?php echo htmlspecialchars($user['username']); ?>" 
                               required>
                    </div>
                    
                    <div class="form-group">
                        <label for="email">Email *</label>
                        <input type="email" 
                               id="email" 
                               name="email" 
                               value="<?php echo htmlspecialchars($user['email']); ?>" 
                               required>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="bio">Tiểu sử</label>
                    <textarea id="bio" 
                              name="bio" 
                              rows="4" 
                              placeholder="Viết vài dòng về bản thân..."><?php echo htmlspecialchars($user['bio'] ?? ''); ?></textarea>
                </div>
            </div>
            
            <!-- Password Section -->
            <div class="form-section">
                <h2 class="section-title">
                    <i class="fas fa-lock"></i> Đổi mật khẩu
                </h2>
                <p style="color: #666; margin-bottom: 20px;">Để trống nếu không muốn đổi mật khẩu</p>
                
                <div class="form-group password-toggle">
                    <label for="current_password">Mật khẩu hiện tại</label>
                    <input type="password" 
                           id="current_password" 
                           name="current_password"
                           autocomplete="current-password">
                    <button type="button" class="toggle-password" onclick="togglePassword('current_password')">
                        <i class="fas fa-eye"></i>
                    </button>
                </div>
                
                <div class="form-row">
                    <div class="form-group password-toggle">
                        <label for="new_password">Mật khẩu mới</label>
                        <input type="password" 
                               id="new_password" 
                               name="new_password"
                               autocomplete="new-password">
                        <button type="button" class="toggle-password" onclick="togglePassword('new_password')">
                            <i class="fas fa-eye"></i>
                        </button>
                    </div>
                    
                    <div class="form-group password-toggle">
                        <label for="confirm_password">Xác nhận mật khẩu</label>
                        <input type="password" 
                               id="confirm_password" 
                               name="confirm_password"
                               autocomplete="new-password">
                        <button type="button" class="toggle-password" onclick="togglePassword('confirm_password')">
                            <i class="fas fa-eye"></i>
                        </button>
                    </div>
                </div>
            </div>
            
            <!-- Form Actions -->
            <div class="form-actions">
                <button type="submit" class="btn-save">
                    <i class="fas fa-save"></i> Lưu thay đổi
                </button>
                <a href="index.php" class="btn-cancel">
                    <i class="fas fa-times"></i> Hủy
                </a>
            </div>
        </form>
    </div>
    
    <?php include '../../includes/footer.php'; ?>
    
    <button class="back-to-top" id="backToTop">
        <i class="fas fa-chevron-up"></i>
    </button>
    
    <script src="../../assets/js/main.js"></script>
    <script>
        // Preview avatar
        function previewAvatar(input) {
            const fileName = document.getElementById('fileName');
            const preview = document.getElementById('avatarPreview');
            
            if (input.files && input.files[0]) {
                fileName.textContent = input.files[0].name;
                
                const reader = new FileReader();
                reader.onload = function(e) {
                    if (preview.tagName === 'IMG') {
                        preview.src = e.target.result;
                    } else {
                        const img = document.createElement('img');
                        img.src = e.target.result;
                        img.className = 'current-avatar';
                        img.id = 'avatarPreview';
                        preview.parentNode.replaceChild(img, preview);
                    }
                };
                reader.readAsDataURL(input.files[0]);
            }
        }
        
        // Toggle password visibility
        function togglePassword(fieldId) {
            const field = document.getElementById(fieldId);
            const button = field.nextElementSibling;
            const icon = button.querySelector('i');
            
            if (field.type === 'password') {
                field.type = 'text';
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            } else {
                field.type = 'password';
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            }
        }
    </script>
</body>
</html>