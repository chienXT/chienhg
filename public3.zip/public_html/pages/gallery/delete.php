<?php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/session.php';
require_once __DIR__ . '/../../includes/functions.php';

// Kiểm tra đăng nhập
if (!isset($_SESSION['user_id'])) {
    header('Location: /pages/auth/login.php');
    exit();
}

// Kiểm tra có ID tác phẩm không
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header('Location: /pages/gallery/');
    exit();
}

$artwork_id = (int)$_GET['id'];

// Lấy thông tin tác phẩm để kiểm tra quyền sở hữu
try {
    $stmt = $pdo->prepare("SELECT * FROM artworks WHERE id = ? AND user_id = ?");
    $stmt->execute([$artwork_id, $_SESSION['user_id']]);
    $artwork = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$artwork) {
        // Nếu không phải tác phẩm của user, kiểm tra nếu là admin
        if ($_SESSION['user_role'] !== 'admin') {
            $_SESSION['error'] = 'Bạn không có quyền xóa tác phẩm này';
            header('Location: /pages/gallery/');
            exit();
        }
        
        // Admin có thể xóa bất kỳ tác phẩm nào
        $stmt = $pdo->prepare("SELECT * FROM artworks WHERE id = ?");
        $stmt->execute([$artwork_id]);
        $artwork = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$artwork) {
            $_SESSION['error'] = 'Tác phẩm không tồn tại';
            header('Location: /pages/gallery/');
            exit();
        }
    }
} catch (PDOException $e) {
    error_log('Database error: ' . $e->getMessage());
    $_SESSION['error'] = 'Đã xảy ra lỗi khi kiểm tra tác phẩm';
    header('Location: /pages/gallery/');
    exit();
}

// Xử lý khi form được submit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['confirm']) || $_POST['confirm'] !== 'yes') {
        $_SESSION['error'] = 'Vui lòng xác nhận xóa';
        header('Location: ' . $_SERVER['REQUEST_URI']);
        exit();
    }
    
    try {
        // Bắt đầu transaction
        $pdo->beginTransaction();
        
        // Xóa các comment liên quan (nếu có)
        $stmt = $pdo->prepare("DELETE FROM comments WHERE artwork_id = ?");
        $stmt->execute([$artwork_id]);
        
        // Xóa các like liên quan (nếu có)
        $stmt = $pdo->prepare("DELETE FROM likes WHERE artwork_id = ?");
        $stmt->execute([$artwork_id]);
        
        // Lấy đường dẫn file để xóa file vật lý (nếu có)
        if (!empty($artwork['image_path']) && strpos($artwork['image_path'], 'uploads/') === 0) {
            $file_path = __DIR__ . '/../../' . $artwork['image_path'];
            if (file_exists($file_path)) {
                unlink($file_path);
            }
        }
        
        // Xóa tác phẩm
        $stmt = $pdo->prepare("DELETE FROM artworks WHERE id = ?");
        $stmt->execute([$artwork_id]);
        
        $pdo->commit();
        
        $_SESSION['success'] = 'Đã xóa tác phẩm thành công';
        
        // Redirect về trang phù hợp
        if (isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin') {
            header('Location: /pages/admin/gallery.php');
        } else {
            header('Location: /pages/gallery/my-gallery.php');
        }
        exit();
        
    } catch (PDOException $e) {
        $pdo->rollBack();
        error_log('Delete error: ' . $e->getMessage());
        $_SESSION['error'] = 'Đã xảy ra lỗi khi xóa tác phẩm';
        header('Location: ' . $_SERVER['REQUEST_URI']);
        exit();
    }
}

$pageTitle = 'Xóa Tác Phẩm - ArtFolio';
$cssFiles = ['/assets/css/modals.css'];

include __DIR__ . '/../../includes/header.php';
?>

<div class="page-header">
    <div class="container">
        <h1>🗑️ Xóa Tác Phẩm</h1>
        <p>Xác nhận xóa tác phẩm nghệ thuật</p>
    </div>
</div>

<div class="container" style="padding: 60px 0;">
    <div class="delete-confirmation">
        <div class="confirmation-card">
            <div class="confirmation-icon">
                <span>⚠️</span>
            </div>
            
            <h2>Bạn có chắc chắn muốn xóa?</h2>
            
            <div class="artwork-preview">
                <div class="preview-image">
                    <?php if (!empty($artwork['image_url'])): ?>
                        <img src="<?php echo htmlspecialchars($artwork['image_url']); ?>" 
                             alt="<?php echo htmlspecialchars($artwork['title']); ?>">
                    <?php elseif (!empty($artwork['image_path'])): ?>
                        <img src="/<?php echo htmlspecialchars($artwork['image_path']); ?>" 
                             alt="<?php echo htmlspecialchars($artwork['title']); ?>">
                    <?php else: ?>
                        <div class="no-image">🖼️ Không có ảnh</div>
                    <?php endif; ?>
                </div>
                
                <div class="preview-info">
                    <h3><?php echo htmlspecialchars($artwork['title']); ?></h3>
                    <p class="preview-description">
                        <?php echo !empty($artwork['description']) 
                            ? htmlspecialchars(substr($artwork['description'], 0, 200)) . '...' 
                            : 'Không có mô tả'; ?>
                    </p>
                    
                    <div class="preview-meta">
                        <span class="meta-item">
                            <strong>Danh mục:</strong> 
                            <?php 
                            $categories = [
                                'painting' => 'Tranh Sơn Dầu',
                                'digital' => 'Nghệ Thuật Số',
                                'photography' => 'Nhiếp Ảnh',
                                'sculpture' => 'Điêu Khắc',
                                'illustration' => 'Minh Họa',
                                'other' => 'Khác'
                            ];
                            echo $categories[$artwork['category']] ?? 'Khác';
                            ?>
                        </span>
                        
                        <span class="meta-item">
                            <strong>Ngày đăng:</strong> 
                            <?php echo date('d/m/Y', strtotime($artwork['created_at'])); ?>
                        </span>
                    </div>
                </div>
            </div>
            
            <div class="warning-box">
                <h4><span>❗</span> Lưu ý quan trọng</h4>
                <ul>
                    <li>Hành động này <strong>không thể hoàn tác</strong></li>
                    <li>Tất cả dữ liệu liên quan (comment, like) sẽ bị xóa</li>
                    <li>Ảnh đã upload sẽ bị xóa khỏi máy chủ</li>
                    <li>Thao tác này sẽ được ghi lại trong nhật ký hệ thống</li>
                </ul>
            </div>
            
            <form method="POST" class="confirmation-form">
                <div class="form-group">
                    <label class="checkbox-label">
                        <input type="checkbox" name="confirm" value="yes" required>
                        <span class="checkmark"></span>
                        <strong>Tôi hiểu và chắc chắn muốn xóa tác phẩm này</strong>
                    </label>
                </div>
                
                <div class="form-actions">
                    <a href="<?php 
                        if (isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin') {
                            echo '/pages/admin/gallery.php';
                        } else {
                            echo '/pages/gallery/my-gallery.php';
                        }
                    ?>" class="btn btn-secondary">
                        👈 Quay lại
                    </a>
                    
                    <button type="submit" class="btn btn-danger" onclick="return confirm('Bạn thực sự muốn xóa?')">
                        🗑️ Xóa Tác Phẩm
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<style>
.delete-confirmation {
    max-width: 800px;
    margin: 0 auto;
}

.confirmation-card {
    background: white;
    border-radius: var(--border-radius);
    box-shadow: var(--shadow-hover);
    padding: 50px;
    text-align: center;
}

.confirmation-icon {
    margin-bottom: 30px;
}

.confirmation-icon span {
    font-size: 80px;
    display: block;
}

.confirmation-card h2 {
    color: #e74c3c;
    margin-bottom: 40px;
    font-size: 32px;
}

.artwork-preview {
    display: grid;
    grid-template-columns: 200px 1fr;
    gap: 30px;
    text-align: left;
    background: #f9f9f9;
    border-radius: var(--border-radius);
    padding: 20px;
    margin-bottom: 30px;
}

@media (max-width: 768px) {
    .artwork-preview {
        grid-template-columns: 1fr;
    }
}

.preview-image {
    width: 200px;
    height: 200px;
    overflow: hidden;
    border-radius: var(--border-radius);
}

.preview-image img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.no-image {
    width: 100%;
    height: 100%;
    background: #ddd;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 40px;
    color: #666;
}

.preview-info h3 {
    font-size: 22px;
    margin-bottom: 10px;
    color: var(--text-color);
}

.preview-description {
    color: var(--text-light);
    margin-bottom: 15px;
    line-height: 1.6;
}

.preview-meta {
    display: flex;
    flex-wrap: wrap;
    gap: 20px;
    font-size: 14px;
}

.meta-item {
    color: #666;
}

.warning-box {
    background: #fff8e1;
    border-left: 4px solid #ffc107;
    padding: 20px;
    border-radius: var(--border-radius);
    text-align: left;
    margin-bottom: 40px;
}

.warning-box h4 {
    color: #e65100;
    margin-bottom: 15px;
    display: flex;
    align-items: center;
    gap: 10px;
}

.warning-box ul {
    list-style: none;
    padding: 0;
}

.warning-box li {
    padding: 8px 0;
    color: #5d4037;
    border-bottom: 1px solid rgba(255, 193, 7, 0.3);
}

.warning-box li:last-child {
    border-bottom: none;
}

.confirmation-form {
    margin-top: 40px;
    padding-top: 30px;
    border-top: 1px solid #eee;
}

.form-actions {
    display: flex;
    justify-content: center;
    gap: 20px;
    margin-top: 30px;
}

.btn-danger {
    background: linear-gradient(135deg, #e74c3c 0%, #c0392b 100%);
    color: white;
    padding: 14px 32px;
    border: none;
    border-radius: var(--border-radius);
    font-size: 16px;
    font-weight: 600;
    cursor: pointer;
    transition: var(--transition);
}

.btn-danger:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 25px rgba(231, 76, 60, 0.3);
}
</style>

<?php
include __DIR__ . '/../../includes/footer.php';
?>