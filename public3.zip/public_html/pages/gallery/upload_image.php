<?php
if (ob_get_level()) {
    ob_end_clean();
}

require_once 'config.php';

header('Content-Type: application/json; charset=utf-8');

if (!isLoggedIn()) {
    echo json_encode([
        'success' => false,
        'message' => 'Bạn cần đăng nhập để upload'
    ]);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Validate input
        $title = trim($_POST['title'] ?? '');
        $description = trim($_POST['description'] ?? '');
        $category = trim($_POST['category'] ?? '');
        $user_id = $_SESSION['user_id'];
        
        if (empty($title)) {
            echo json_encode([
                'success' => false,
                'message' => 'Vui lòng nhập tiêu đề'
            ]);
            exit;
        }
        
        if (empty($category)) {
            echo json_encode([
                'success' => false,
                'message' => 'Vui lòng chọn danh mục'
            ]);
            exit;
        }
        
        // Check if file uploaded
        if (!isset($_FILES['image']) || $_FILES['image']['error'] !== UPLOAD_ERR_OK) {
            echo json_encode([
                'success' => false,
                'message' => 'Vui lòng chọn ảnh'
            ]);
            exit;
        }
        
        $file = $_FILES['image'];
        
        // Validate file type
        $allowed_types = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
        $file_type = mime_content_type($file['tmp_name']);
        
        if (!in_array($file_type, $allowed_types)) {
            echo json_encode([
                'success' => false,
                'message' => 'Chỉ chấp nhận file ảnh (JPG, PNG, GIF, WEBP)'
            ]);
            exit;
        }
        
        // Validate file size (5MB)
        if ($file['size'] > 5 * 1024 * 1024) {
            echo json_encode([
                'success' => false,
                'message' => 'File quá lớn! Vui lòng chọn file nhỏ hơn 5MB'
            ]);
            exit;
        }
        
        // Create uploads directory if not exists
        $upload_dir = __DIR__ . '/../uploads/gallery/';
        if (!file_exists($upload_dir)) {
            mkdir($upload_dir, 0755, true);
        }
        
        // Generate unique filename
        $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
        $filename = uniqid('gallery_', true) . '_' . time() . '.' . $extension;
        $filepath = $upload_dir . $filename;
        
        // Move uploaded file
        if (!move_uploaded_file($file['tmp_name'], $filepath)) {
            echo json_encode([
                'success' => false,
                'message' => 'Lỗi khi upload file'
            ]);
            exit;
        }
        
        // Generate URL
        $image_url = 'uploads/gallery/' . $filename;
        
        // Insert into database
        $query = "INSERT INTO gallery (user_id, title, description, image_url, category, created_at) 
                  VALUES (:user_id, :title, :description, :image_url, :category, NOW())";
        
        $stmt = $pdo->prepare($query);
        
        if ($stmt->execute([
            ':user_id' => $user_id,
            ':title' => $title,
            ':description' => $description,
            ':image_url' => $image_url,
            ':category' => $category
        ])) {
            echo json_encode([
                'success' => true,
                'message' => 'Upload thành công! Tác phẩm của bạn đã được thêm vào gallery.',
                'data' => [
                    'image_url' => $image_url
                ]
            ]);
            exit;
        } else {
            // Delete file if database insert fails
            if (file_exists($filepath)) {
                unlink($filepath);
            }
            
            echo json_encode([
                'success' => false,
                'message' => 'Có lỗi xảy ra khi lưu vào database'
            ]);
            exit;
        }
        
    } catch (Exception $e) {
        error_log("Upload image error: " . $e->getMessage());
        echo json_encode([
            'success' => false,
            'message' => 'Lỗi hệ thống'
        ]);
        exit;
    }
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Chỉ chấp nhận POST request'
    ]);
    exit;
}
?>