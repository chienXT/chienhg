<?php
require_once '../config.php';

if (!isAdmin()) {
    header('Location: login.php');
    exit;
}

// Xử lý xóa gallery
if (isset($_GET['delete']) && !empty($_GET['delete'])) {
    $id = $_GET['delete'];
    try {
        $query = "DELETE FROM gallery WHERE id = :id";
        $stmt = $pdo->prepare($query);
        $stmt->execute([':id' => $id]);
        $_SESSION['success_message'] = 'Xóa gallery thành công!';
    } catch (PDOException $e) {
        $_SESSION['error_message'] = 'Lỗi: ' . $e->getMessage();
    }
    header('Location: gallery_manage.php');
    exit;
}

// Lấy danh sách gallery
try {
    $query = "SELECT g.*, u.username 
              FROM gallery g 
              LEFT JOIN users u ON g.user_id = u.id 
              ORDER BY g.created_at DESC";
    $stmt = $pdo->prepare($query);
    $stmt->execute();
    $gallery_items = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $gallery_items = [];
    $error = $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quản Lý Gallery - ArtFolio Admin</title>
    <link rel="stylesheet" href="../../css/style.css">
    <style>
        .admin-container {
            max-width: 1400px;
            margin: 80px auto 40px;
            padding: 0 20px;
        }
        .admin-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            flex-wrap: wrap;
            gap: 15px;
        }
        .admin-nav {
            display: flex;
            gap: 15px;
            margin-bottom: 30px;
            flex-wrap: wrap;
        }
        .admin-nav a {
            padding: 10px 20px;
            background: #f0f0f0;
            border-radius: 8px;
            text-decoration: none;
            color: #333;
            transition: all 0.3s;
        }
        .admin-nav a.active, .admin-nav a:hover {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        .alert {
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .alert-error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        .stat-card {
            background: white;
            padding: 20px;
            border-radius: 15px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
            text-align: center;
        }
        .stat-number {
            font-size: 32px;
            font-weight: bold;
            color: #667eea;
        }
        .stat-label {
            color: #666;
            margin-top: 5px;
        }
        .gallery-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
            gap: 25px;
        }
        .gallery-card {
            background: white;
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
            transition: all 0.3s;
        }
        .gallery-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 30px rgba(0,0,0,0.15);
        }
        .gallery-image {
            width: 100%;
            height: 220px;
            background-size: cover;
            background-position: center;
            background-color: #f0f0f0;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #999;
        }
        .gallery-content {
            padding: 20px;
        }
        .gallery-title {
            font-weight: bold;
            font-size: 16px;
            margin-bottom: 8px;
            color: #333;
        }
        .gallery-meta {
            font-size: 13px;
            color: #666;
            margin-bottom: 5px;
        }
        .gallery-category {
            display: inline-block;
            padding: 4px 12px;
            background: #667eea;
            color: white;
            border-radius: 20px;
            font-size: 12px;
            margin-top: 10px;
        }
        .gallery-actions {
            margin-top: 15px;
            display: flex;
            gap: 10px;
        }
        .btn-delete {
            flex: 1;
            padding: 8px;
            background: #dc3545;
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 13px;
            transition: all 0.3s;
        }
        .btn-delete:hover {
            background: #c82333;
            transform: translateY(-2px);
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <div class="admin-header">
            <h1>📸 Quản Lý Gallery</h1>
            <div>
                <span>Xin chào, <?php echo htmlspecialchars($_SESSION['username']); ?></span>
                <a href="../../index.php" class="admin-btn" style="margin-left: 10px;">Về Trang Chủ</a>
                <a href="?logout" class="logout-btn" style="margin-left: 10px;">Đăng Xuất</a>
            </div>
        </div>

        <div class="admin-nav">
            <a href="dashboard.php">Dashboard</a>
            <a href="users.php">Users</a>
            <a href="gallery_manage.php" class="active">Gallery</a>
            <a href="contacts_manage.php">Contacts</a>
        </div>

        <?php if (isset($_SESSION['success_message'])): ?>
            <div class="alert alert-success">
                <?php 
                    echo htmlspecialchars($_SESSION['success_message']); 
                    unset($_SESSION['success_message']);
                ?>
            </div>
        <?php endif; ?>

        <?php if (isset($_SESSION['error_message'])): ?>
            <div class="alert alert-error">
                <?php 
                    echo htmlspecialchars($_SESSION['error_message']); 
                    unset($_SESSION['error_message']);
                ?>
            </div>
        <?php endif; ?>

        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-number"><?php echo count($gallery_items); ?></div>
                <div class="stat-label">Tổng Tác Phẩm</div>
            </div>
            <div class="stat-card">
                <div class="stat-number">
                    <?php echo count(array_filter($gallery_items, fn($g) => $g['category'] === 'painting')); ?>
                </div>
                <div class="stat-label">Tranh Sơn Dầu</div>
            </div>
            <div class="stat-card">
                <div class="stat-number">
                    <?php echo count(array_filter($gallery_items, fn($g) => $g['category'] === 'digital')); ?>
                </div>
                <div class="stat-label">Digital Art</div>
            </div>
            <div class="stat-card">
                <div class="stat-number">
                    <?php echo count(array_filter($gallery_items, fn($g) => $g['category'] === 'photography')); ?>
                </div>
                <div class="stat-label">Photography</div>
            </div>
        </div>

        <?php if (empty($gallery_items)): ?>
            <div style="text-align: center; padding: 60px; background: white; border-radius: 15px;">
                <p style="color: #666; font-size: 18px;">Chưa có tác phẩm nào trong gallery</p>
            </div>
        <?php else: ?>
            <div class="gallery-grid">
                <?php foreach ($gallery_items as $item): ?>
                    <div class="gallery-card">
                        <div class="gallery-image" 
                             style="background-image: url('<?php echo htmlspecialchars($item['image_url'] ?? ''); ?>');">
                            <?php if (empty($item['image_url'])): ?>
                                No Image
                            <?php endif; ?>
                        </div>
                        <div class="gallery-content">
                            <div class="gallery-title"><?php echo htmlspecialchars($item['title']); ?></div>
                            
                            <?php if (!empty($item['description'])): ?>
                                <div class="gallery-meta">
                                    <?php echo htmlspecialchars(substr($item['description'], 0, 100)); ?>
                                    <?php echo strlen($item['description']) > 100 ? '...' : ''; ?>
                                </div>
                            <?php endif; ?>
                            
                            <div class="gallery-meta">
                                👤 <strong><?php echo htmlspecialchars($item['username'] ?? 'Unknown'); ?></strong>
                            </div>
                            
                            <div class="gallery-meta">
                                📅 <?php echo date('d/m/Y', strtotime($item['created_at'])); ?>
                            </div>
                            
                            <span class="gallery-category">
                                <?php echo htmlspecialchars($item['category']); ?>
                            </span>
                            
                            <div class="gallery-actions">
                                <button class="btn-delete" 
                                        onclick="if(confirm('Chắc chắn xóa tác phẩm này?')) { window.location.href='?delete=<?php echo $item['id']; ?>'; }">
                                    🗑️ Xóa
                                </button>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>

    <?php
    if (isset($_GET['logout'])) {
        session_destroy();
        header('Location: login.php');
        exit;
    }
    ?>
</body>
</html>