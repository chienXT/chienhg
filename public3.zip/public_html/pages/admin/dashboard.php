<?php
// ========== PHẦN 1: CẤU HÌNH & PATH ==========
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Dùng path đúng từ debug: PATH 1 hoặc PATH 0 đều được
$basePath = '/home/www/public_html/'; // Hoặc '/srv/disk25/3843044/www/public_html/'

// ========== PHẦN 2: INCLUDE FILES ==========
require_once $basePath . 'includes/config.php';
require_once $basePath . 'includes/session.php';
require_once $basePath . 'includes/functions.php';

// ========== PHẦN 3: KIỂM TRA SESSION ==========
// Tạm thời bỏ qua auth check để test


// ========== PHẦN 4: DATABASE QUERIES ==========
// Khởi tạo biến
$total_users = $total_artworks = $total_comments = $total_contacts = 0;
$new_users = $new_artworks = 0;
$recent_users = $recent_artworks = $recent_contacts = [];

try {
    // Tổng số users
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM users");
    $total_users = $stmt->fetch()['total'] ?? 0;
    
    // Tổng số artworks
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM artworks");
    $total_artworks = $stmt->fetch()['total'] ?? 0;
    
    // Tổng số comments
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM comments");
    $total_comments = $stmt->fetch()['total'] ?? 0;
    
    // Tổng số contacts
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM contacts");
    $total_contacts = $stmt->fetch()['total'] ?? 0;
    
    // Users mới trong 7 ngày qua
    $stmt = $pdo->prepare("
        SELECT COUNT(*) as count FROM users 
        WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
    ");
    $stmt->execute();
    $new_users = $stmt->fetch()['count'] ?? 0;
    
    // Artworks mới trong 7 ngày qua
    $stmt = $pdo->prepare("
        SELECT COUNT(*) as count FROM artworks 
        WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
    ");
    $stmt->execute();
    $new_artworks = $stmt->fetch()['count'] ?? 0;
    
    // Lấy users mới nhất
    $stmt = $pdo->query("
        SELECT id, username, email, role, created_at 
        FROM users 
        ORDER BY created_at DESC 
        LIMIT 5
    ");
    $recent_users = $stmt->fetchAll() ?: [];
    
    // Lấy artworks mới nhất
    $stmt = $pdo->query("
        SELECT a.id, a.title, a.category, a.created_at, u.username 
        FROM artworks a 
        JOIN users u ON a.user_id = u.id 
        ORDER BY a.created_at DESC 
        LIMIT 5
    ");
    $recent_artworks = $stmt->fetchAll() ?: [];
    
    // Lấy contacts mới nhất
    $stmt = $pdo->query("
        SELECT id, name, email, subject, created_at, status 
        FROM contacts 
        ORDER BY created_at DESC 
        LIMIT 5
    ");
    $recent_contacts = $stmt->fetchAll() ?: [];
    
} catch (PDOException $e) {
    error_log('Dashboard error: ' . $e->getMessage());
    $_SESSION['error'] = 'Đã xảy ra lỗi khi tải thống kê';
}

// ========== PHẦN 5: PAGE SETTINGS ==========
$pageTitle = 'Bảng Điều Khiển Quản Trị - ArtFolio';
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($pageTitle); ?></title>
    
    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="/assets/images/favicon.ico">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    
    <!-- CSS Files -->
    <link rel="stylesheet" href="/assets/css/style.css">
    <link rel="stylesheet" href="/assets/css/admin.css">
</head>
<body>
<!-- ========== PHẦN 7: HTML CONTENT ========== -->
<div class="admin-dashboard">
    <!-- Admin Header -->
    <div class="admin-header">
        <div class="container">
            <div class="admin-header-content">
              <div class="admin-header-top">
                <a href="/index.php" class="home-btn">
                    ← Trang chủ
                </a>
                <div class="admin-user">
                    <span>👤 <?php echo htmlspecialchars($_SESSION['username'] ?? 'Admin'); ?></span>
                </div>
              </div>
                <h1>⚙️ Bảng Điều Khiển Quản Trị</h1>
                <p>Quản lý hệ thống ArtFolio</p>
                
                <div class="admin-actions">
                    <a href="/pages/admin/users.php" class="admin-action-btn">
                        👥 Quản lý người dùng
                    </a>
                    <a href="/pages/admin/gallery.php" class="admin-action-btn">
                        🖼️ Quản lý tác phẩm
                    </a>
                    <a href="/pages/admin/contacts.php" class="admin-action-btn">
                        📧 Quản lý liên hệ
                    </a>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Dashboard Stats -->
    <div class="container">
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-icon users">
                    👥
                </div>
                <div class="stat-info">
                    <h3><?php echo number_format($total_users); ?></h3>
                    <p>Tổng người dùng</p>
                    <small>+<?php echo $new_users; ?> trong 7 ngày qua</small>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon artworks">
                    🖼️
                </div>
                <div class="stat-info">
                    <h3><?php echo number_format($total_artworks); ?></h3>
                    <p>Tổng tác phẩm</p>
                    <small>+<?php echo $new_artworks; ?> trong 7 ngày qua</small>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon comments">
                    💬
                </div>
                <div class="stat-info">
                    <h3><?php echo number_format($total_comments); ?></h3>
                    <p>Tổng bình luận</p>
                    <small>Hoạt động cộng đồng</small>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon contacts">
                    📧
                </div>
                <div class="stat-info">
                    <h3><?php echo number_format($total_contacts); ?></h3>
                    <p>Tin nhắn liên hệ</p>
                    <small>Cần xử lý</small>
                </div>
            </div>
        </div>
        
        <!-- Dashboard Content -->
        <div class="dashboard-content">
            <!-- Recent Users -->
            <div class="dashboard-section">
                <div class="section-header">
                    <h2>👤 Người dùng mới nhất</h2>
                    <a href="/pages/admin/users.php" class="view-all">
                        Xem tất cả →
                    </a>
                </div>
                
                <div class="table-container">
                    <table class="admin-table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Tên người dùng</th>
                                <th>Email</th>
                                <th>Vai trò</th>
                                <th>Ngày tham gia</th>
                                <th>Thao tác</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($recent_users as $user): ?>
                            <tr>
                                <td><?php echo $user['id']; ?></td>
                                <td>
                                    <div class="user-cell">
                                        <?php echo htmlspecialchars($user['username']); ?>
                                        <?php if ($user['role'] === 'admin'): ?>
                                            <span class="role-badge admin">Admin</span>
                                        <?php endif; ?>
                                    </div>
                                </td>
                                <td><?php echo htmlspecialchars($user['email']); ?></td>
                                <td>
                                    <span class="role-badge <?php echo $user['role']; ?>">
                                        <?php echo $user['role']; ?>
                                    </span>
                                </td>
                                <td><?php echo date('d/m/Y', strtotime($user['created_at'])); ?></td>
                                <td>
                                    <div class="table-actions">
                                        <a href="/pages/admin/users.php?action=view&id=<?php echo $user['id']; ?>" 
                                           class="action-btn view" title="Xem chi tiết">
                                            👁️
                                        </a>
                                        <a href="/pages/admin/users.php?action=edit&id=<?php echo $user['id']; ?>" 
                                           class="action-btn edit" title="Chỉnh sửa">
                                            ✏️
                                        </a>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <!-- Recent Artworks -->
            <div class="dashboard-section">
                <div class="section-header">
                    <h2>🖼️ Tác phẩm mới nhất</h2>
                    <a href="/pages/admin/gallery.php" class="view-all">
                        Xem tất cả →
                    </a>
                </div>
                
                <div class="table-container">
                    <table class="admin-table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Tiêu đề</th>
                                <th>Tác giả</th>
                                <th>Danh mục</th>
                                <th>Ngày đăng</th>
                                <th>Thao tác</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($recent_artworks as $artwork): ?>
                            <tr>
                                <td><?php echo $artwork['id']; ?></td>
                                <td><?php echo htmlspecialchars($artwork['title']); ?></td>
                                <td><?php echo htmlspecialchars($artwork['username']); ?></td>
                                <td>
                                    <span class="category-badge">
                                        <?php 
                                        $categories = [
                                            'painting' => '🎨 Tranh',
                                            'digital' => '💻 Số',
                                            'photography' => '📸 Ảnh',
                                            'sculpture' => '🗿 Điêu khắc'
                                        ];
                                        echo $categories[$artwork['category']] ?? '🎭 Khác';
                                        ?>
                                    </span>
                                </td>
                                <td><?php echo date('d/m/Y', strtotime($artwork['created_at'])); ?></td>
                                <td>
                                    <div class="table-actions">
                                        <a href="/pages/gallery/view.php?id=<?php echo $artwork['id']; ?>" 
                                           class="action-btn view" title="Xem chi tiết">
                                            👁️
                                        </a>
                                        <a href="/pages/admin/gallery.php?action=edit&id=<?php echo $artwork['id']; ?>" 
                                           class="action-btn edit" title="Chỉnh sửa">
                                            ✏️
                                        </a>
                                        <a href="/pages/gallery/delete.php?id=<?php echo $artwork['id']; ?>" 
                                           class="action-btn delete" title="Xóa"
                                           onclick="return confirm('Bạn có chắc muốn xóa?')">
                                            🗑️
                                        </a>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <!-- Recent Contacts -->
            <div class="dashboard-section">
                <div class="section-header">
                    <h2>📧 Tin nhắn liên hệ mới</h2>
                    <a href="/pages/admin/contacts.php" class="view-all">
                        Xem tất cả →
                    </a>
                </div>
                
                <div class="table-container">
                    <table class="admin-table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Người gửi</th>
                                <th>Email</th>
                                <th>Tiêu đề</th>
                                <th>Ngày gửi</th>
                                <th>Trạng thái</th>
                                <th>Thao tác</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($recent_contacts as $contact): ?>
                            <tr>
                                <td><?php echo $contact['id']; ?></td>
                                <td><?php echo htmlspecialchars($contact['name']); ?></td>
                                <td><?php echo htmlspecialchars($contact['email']); ?></td>
                                <td><?php echo htmlspecialchars($contact['subject']); ?></td>
                                <td><?php echo date('d/m/Y', strtotime($contact['created_at'])); ?></td>
                                <td>
                                    <span class="status-badge <?php echo $contact['status']; ?>">
                                        <?php 
                                        $status_text = [
                                            'pending' => '⏳ Chờ xử lý',
                                            'read' => '👁️ Đã đọc',
                                            'replied' => '📩 Đã trả lời',
                                            'closed' => '✅ Đã đóng'
                                        ];
                                        echo $status_text[$contact['status']] ?? '❓ Không xác định';
                                        ?>
                                    </span>
                                </td>
                                <td>
                                    <div class="table-actions">
                                        <a href="/pages/admin/contacts.php?action=view&id=<?php echo $contact['id']; ?>" 
                                           class="action-btn view" title="Xem chi tiết">
                                            👁️
                                        </a>
                                        <button class="action-btn mark-read" 
                                                data-id="<?php echo $contact['id']; ?>"
                                                title="Đánh dấu đã đọc">
                                            📖
                                        </button>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <!-- Quick Actions -->
            <div class="dashboard-section">
                <h2>⚡ Thao tác nhanh</h2>
                
                <div class="quick-actions">
                    <a href="/pages/admin/users.php?action=create" class="quick-action">
                        <span>➕</span>
                        <h3>Thêm người dùng mới</h3>
                        <p>Tạo tài khoản mới</p>
                    </a>
                    
                    <a href="/pages/gallery/upload.php" class="quick-action">
                        <span>📤</span>
                        <h3>Upload tác phẩm</h3>
                        <p>Thêm tác phẩm mới</p>
                    </a>
                    
                    <a href="/pages/admin/settings.php" class="quick-action">
                        <span>⚙️</span>
                        <h3>Cài đặt hệ thống</h3>
                        <p>Cấu hình website</p>
                    </a>
                    
                    <a href="/api/export.php?type=users" class="quick-action">
                        <span>📊</span>
                        <h3>Xuất báo cáo</h3>
                        <p>Xuất dữ liệu CSV</p>
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- ========== PHẦN 8: JAVASCRIPT ========== -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Mark contact as read
    const markReadBtns = document.querySelectorAll('.mark-read');
    markReadBtns.forEach(btn => {
        btn.addEventListener('click', async function() {
            const contactId = this.dataset.id;
            
            try {
                const response = await fetch('/pages/admin/contacts.php?action=mark_read&id=' + contactId, {
                    method: 'POST',
                    credentials: 'same-origin'
                });
                
                const result = await response.json();
                
                if (result.success) {
                    const statusCell = this.closest('tr').querySelector('.status-badge');
                    statusCell.textContent = '👁️ Đã đọc';
                    statusCell.className = 'status-badge read';
                    this.remove();
                    alert('Đã đánh dấu là đã đọc');
                } else {
                    alert('Lỗi: ' + (result.message || 'Không xác định'));
                }
            } catch (error) {
                console.error('Error:', error);
                alert('Đã xảy ra lỗi');
            }
        });
    });
});
</script>

<?php
// ========== PHẦN 10: INCLUDE FOOTER ==========
include $basePath . 'includes/footer.php';
?>

</body>
</html>