<?php
// sections/blog.php - Blog từ Database
$userLoggedIn = !empty($_SESSION['user_id']) && is_numeric($_SESSION['user_id']);

// Get blog posts từ database
try {
    $blog_posts = getAll("
        SELECT 
            b.*,
            u.username,
            u.avatar
        FROM blog_posts b
        LEFT JOIN users u ON b.user_id = u.id
        WHERE b.status = 'published'
        ORDER BY b.created_at DESC
        LIMIT 12
    ", []);
} catch (Exception $e) {
    error_log('Blog query error: ' . $e->getMessage());
    $blog_posts = [];
}
?>

<section id="blog" class="section" style="background: var(--gray-50);">
    <div class="container">
        <div style="text-align: center; margin-bottom: 50px;">
            <h2 class="section-title">Blog & Bài Viết</h2>
            <p class="section-subtitle">Cập nhật những bài viết mới nhất về thiết kế, nghệ thuật và công nghệ</p>
        </div>

        <!-- Blog Grid -->
        <div class="blog-grid">
            <?php if (empty($blog_posts)): ?>
                <div style="grid-column: 1/-1; text-align: center; padding: 60px 20px;">
                    <p style="font-size: 18px; color: #999;">
                        📭 Chưa có bài viết nào. Hãy quay lại sau!
                    </p>
                </div>
            <?php else: ?>
                <?php foreach ($blog_posts as $post): ?>
                    <article class="blog-card">
                        <div class="blog-image-wrapper">
                            <?php 
                                $imageUrl = !empty($post['featured_image']) 
                                    ? esc($post['featured_image']) 
                                    : 'https://via.placeholder.com/500x300?text=' . urlencode($post['title'] ?? 'Blog');
                            ?>
                            <img 
                                src="<?php echo $imageUrl; ?>" 
                                alt="<?php echo esc($post['title'] ?? 'Untitled'); ?>"
                                class="blog-image"
                                loading="lazy"
                            >
                            <div class="blog-overlay">
                                <span class="blog-category"><?php echo esc($post['category'] ?? 'Chung'); ?></span>
                            </div>
                        </div>

                        <div class="blog-content">
                            <div class="blog-icon" style="font-size: 28px; margin-bottom: 12px;">
                                <?php 
                                    $icons = [
                                        'design' => '🎨',
                                        'art' => '🖌️',
                                        'tech' => '💻',
                                        'tutorial' => '📚',
                                        'tips' => '💡',
                                        'inspiration' => '✨'
                                    ];
                                    echo $icons[$post['category'] ?? ''] ?? '📝';
                                ?>
                            </div>
                            
                            <h3 class="blog-title"><?php echo esc($post['title'] ?? 'Untitled'); ?></h3>
                            
                            <p class="blog-excerpt">
                                <?php 
                                    $excerpt = $post['excerpt'] ?? substr($post['content'] ?? '', 0, 150);
                                    echo esc($excerpt);
                                    if (strlen($excerpt) > 150) echo '...';
                                ?>
                            </p>

                            <div class="blog-meta">
                                <span class="blog-author">
                                    <i class="fas fa-user-circle"></i>
                                    <?php echo esc($post['username'] ?? 'Admin'); ?>
                                </span>
                                <span class="blog-date">
                                    <i class="fas fa-calendar"></i>
                                    <?php echo date('d/m/Y', strtotime($post['created_at'] ?? 'now')); ?>
                                </span>
                            </div>

                            <a href="#" class="blog-read-more" onclick="return false;">
                                Đọc Tiếp
                                <i class="fas fa-arrow-right"></i>
                            </a>
                        </div>
                    </article>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>

        <!-- Load More -->
        <?php if (count($blog_posts) >= 12): ?>
            <div style="text-align: center; margin-top: 50px;">
                <button style="
                    padding: 14px 40px;
                    background: #5AB5D4;
                    color: white;
                    border: none;
                    border-radius: 8px;
                    font-size: 16px;
                    font-weight: 600;
                    cursor: pointer;
                    transition: all 0.3s ease;
                " onmouseover="this.style.transform='translateY(-2px)'" onmouseout="this.style.transform='translateY(0)'">
                    <i class="fas fa-chevron-down"></i> Xem Thêm Bài Viết
                </button>
            </div>
        <?php endif; ?>
    </div>
</section>

<style>
.blog-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
    gap: 30px;
    margin-bottom: 40px;
}

.blog-card {
    background: white;
    border-radius: 12px;
    overflow: hidden;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    transition: all 0.3s ease;
    display: flex;
    flex-direction: column;
    height: 100%;
}

.blog-card:hover {
    transform: translateY(-8px);
    box-shadow: 0 12px 32px rgba(0, 0, 0, 0.15);
}

.blog-image-wrapper {
    position: relative;
    width: 100%;
    height: 220px;
    overflow: hidden;
    background: #f0f0f0;
}

.blog-image {
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: transform 0.4s ease;
}

.blog-card:hover .blog-image {
    transform: scale(1.08);
}

.blog-overlay {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(90, 181, 212, 0.8);
    display: flex;
    align-items: center;
    justify-content: center;
    opacity: 0;
    transition: opacity 0.3s ease;
}

.blog-card:hover .blog-overlay {
    opacity: 1;
}

.blog-category {
    background: white;
    color: #5AB5D4;
    padding: 8px 16px;
    border-radius: 20px;
    font-weight: 600;
    font-size: 12px;
    text-transform: uppercase;
}

.blog-content {
    padding: 25px;
    flex-grow: 1;
    display: flex;
    flex-direction: column;
}

.blog-title {
    font-size: 18px;
    font-weight: 700;
    color: #212121;
    line-height: 1.4;
    margin-bottom: 12px;
    flex-grow: 1;
}

.blog-excerpt {
    font-size: 14px;
    color: #616161;
    line-height: 1.6;
    margin-bottom: 16px;
    display: -webkit-box;
    -webkit-line-clamp: 3;
    -webkit-box-orient: vertical;
    overflow: hidden;
}

.blog-meta {
    display: flex;
    gap: 16px;
    margin-bottom: 16px;
    padding: 12px 0;
    border-top: 1px solid #e0e0e0;
    border-bottom: 1px solid #e0e0e0;
    font-size: 12px;
    color: #757575;
}

.blog-author,
.blog-date {
    display: flex;
    align-items: center;
    gap: 6px;
}

.blog-meta i {
    color: #5AB5D4;
}

.blog-read-more {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    color: #5AB5D4;
    text-decoration: none;
    font-weight: 600;
    font-size: 14px;
    transition: all 0.3s ease;
    margin-top: auto;
    cursor: pointer;
}

.blog-read-more:hover {
    color: #3A7E9F;
    gap: 12px;
}

@media (max-width: 768px) {
    .blog-grid {
        grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
        gap: 20px;
    }

    .blog-card {
        margin-bottom: 10px;
    }
}

@media (max-width: 480px) {
    .blog-grid {
        grid-template-columns: 1fr;
    }

    .blog-content {
        padding: 20px;
    }
}
</style>