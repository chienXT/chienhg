<section id="home" class="enhanced-hero">
        <canvas id="hero-canvas"></canvas>
        
        <div class="floating-elements">
            <div class="floating-element">🎨</div>
            <div class="floating-element">✨</div>
            <div class="floating-element">🖼️</div>
        </div>
        
        <div class="hero-content enhanced">
            <h1 class="gradient-text text-glow fade-in-up">
                <span class="text-line">Chào Mừng Đến</span>
                <span class="text-line">Portfolio Nghệ Thuật</span>
            </h1>
            
            <p class="typing-text fade-in-up delay-1">
                Khám phá những tác phẩm nghệ thuật độc đáo và sáng tạo
            </p>
            
            <a href="#gallery" class="cta-btn enhanced-btn fade-in-up delay-2">
                <span class="btn-text">Xem Tác Phẩm</span>
                <span class="btn-icon">→</span>
            </a>
        </div>
        
        <div class="scroll-indicator enhanced">
            <div class="mouse"></div>
            <span>Scroll</span>
        </div>
    </section>