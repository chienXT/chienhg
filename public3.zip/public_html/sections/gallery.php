<?php
// sections/gallery.php
$userLoggedIn = !empty($_SESSION['user_id']) && is_numeric($_SESSION['user_id']);

// Get gallery items
try {
    $gallery_items = get_all_gallery_items(null, null, 12);
} catch (Exception $e) {
    error_log('Gallery error: ' . $e->getMessage());
    $gallery_items = [];
}
?>

<section id="gallery" class="section">
    <div class="container">
        <div style="text-align: center; margin-bottom: 50px;">
            <h2 class="section-title">Thư Viện Tác Phẩm</h2>
            <p class="section-subtitle">Khám phá hàng ngàn tác phẩm từ các nghệ sĩ tài năng trên toàn thế giới</p>
        </div>

        <!-- Filter Buttons -->
        <div class="gallery-filters">
            <button class="filter-btn active" data-filter="all">Tất Cả</button>
            <button class="filter-btn" data-filter="painting">🎨 Tranh Sơn Dầu</button>
            <button class="filter-btn" data-filter="digital">💻 Nghệ Thuật Số</button>
            <button class="filter-btn" data-filter="photography">📸 Nhiếp Ảnh</button>
            <button class="filter-btn" data-filter="sculpture">🗿 Điêu Khắc</button>
            <button class="filter-btn" data-filter="illustration">✏️ Minh Họa</button>
        </div>

        <!-- Gallery Grid -->
        <div class="gallery-grid" id="galleryGrid">
            <?php if (empty($gallery_items)): ?>
                <div style="grid-column: 1/-1; text-align: center; padding: 60px 20px;">
                    <p style="font-size: 18px; color: #999;">
                        📭 Chưa có tác phẩm nào. Hãy là người đầu tiên chia sẻ!
                    </p>
                    <?php if ($userLoggedIn): ?>
                        <button id="uploadBtnGallery" style="
                            margin-top: 20px;
                            padding: 12px 30px;
                            background: #5AB5D4;
                            color: white;
                            border: none;
                            border-radius: 8px;
                            cursor: pointer;
                            font-weight: 600;
                            transition: all 0.3s ease;
                        " onmouseover="this.style.background='#3A7E9F'" onmouseout="this.style.background='#5AB5D4'">
                            Tải Lên Tác Phẩm Ngay
                        </button>
                    <?php else: ?>
                        <button id="loginBtnGallery" style="
                            margin-top: 20px;
                            padding: 12px 30px;
                            background: #5AB5D4;
                            color: white;
                            border: none;
                            border-radius: 8px;
                            cursor: pointer;
                            font-weight: 600;
                            transition: all 0.3s ease;
                        " onmouseover="this.style.background='#3A7E9F'" onmouseout="this.style.background='#5AB5D4'">
                            Đăng Nhập để Tải Lên
                        </button>
                    <?php endif; ?>
                </div>
            <?php else: ?>
                <?php foreach ($gallery_items as $item): ?>
                    <?php
                    // Lấy ID item
                    $item_id = $item['id'] ?? 0;
                    
                    // Xử lý URL ảnh
                    $imageUrl = !empty($item['image_path'] ?? $item['image']) 
                        ? esc($item['image_path'] ?? $item['image'])
                        : 'https://via.placeholder.com/400x300/0084ff/ffffff?text=ArtFolio';
                    
                    // Nếu không phải URL đầy đủ
                    if (strpos($imageUrl, 'http') !== 0 && strpos($imageUrl, 'uploads/') === false) {
                        // Kiểm tra file tồn tại
                        $possible_paths = [
                            'uploads/gallery/' . basename($imageUrl),
                            'uploads/' . basename($imageUrl),
                            $imageUrl
                        ];
                        
                        $found = false;
                        foreach ($possible_paths as $path) {
                            if (file_exists($path)) {
                                $imageUrl = $path;
                                $found = true;
                                break;
                            }
                        }
                        
                        if (!$found) {
                            $imageUrl = 'https://via.placeholder.com/400x300/0084ff/ffffff?text=ArtFolio';
                        }
                    }
                    ?>
                    
                    <!-- ITEM GALLERY - LINK BAO QUANH TOÀN BỘ -->
                    <a href="pages/image-detail.php?id=<?php echo $item_id; ?>" 
                       class="gallery-link"
                       style="text-decoration: none; color: inherit; display: block;">
                        
                        <div class="gallery-item" data-category="<?php echo esc($item['category'] ?? 'other'); ?>"
                             style="
                                background: white;
                                border-radius: 12px;
                                overflow: hidden;
                                box-shadow: 0 5px 15px rgba(0, 0, 0, 0.08);
                                transition: all 0.3s ease;
                                height: 100%;
                             "
                             onmouseover="this.style.transform='translateY(-5px)'; this.style.boxShadow='0 10px 25px rgba(0, 0, 0, 0.15)'"
                             onmouseout="this.style.transform='translateY(0)'; this.style.boxShadow='0 5px 15px rgba(0, 0, 0, 0.08)'">
                            
                            <div class="gallery-img-container">
                                <img 
                                    src="<?php echo $imageUrl; ?>" 
                                    alt="<?php echo esc($item['title'] ?? 'Untitled'); ?>"
                                    class="gallery-img"
                                    loading="lazy"
                                    style="
                                        width: 100%;
                                        height: 250px;
                                        object-fit: cover;
                                        transition: transform 0.5s ease;
                                    "
                                    onmouseover="this.style.transform='scale(1.05)'"
                                    onmouseout="this.style.transform='scale(1)'"
                                    onerror="this.src='https://via.placeholder.com/400x300/0084ff/ffffff?text=Image+Error'"
                                >
                                
                                <!-- Hover overlay -->
                                <div class="gallery-hover-overlay"
                                     style="
                                        position: absolute;
                                        top: 0;
                                        left: 0;
                                        right: 0;
                                        bottom: 0;
                                        background: rgba(0, 132, 255, 0.1);
                                        display: flex;
                                        align-items: center;
                                        justify-content: center;
                                        opacity: 0;
                                        transition: opacity 0.3s ease;
                                     "
                                     onmouseover="this.style.opacity='1'"
                                     onmouseout="this.style.opacity='0'">
                                    <div style="
                                        background: white;
                                        color: #0084ff;
                                        padding: 10px 20px;
                                        border-radius: 50px;
                                        font-weight: 600;
                                        font-size: 14px;
                                        display: flex;
                                        align-items: center;
                                        gap: 8px;
                                    ">
                                        <i class="fas fa-external-link-alt"></i>
                                        Xem chi tiết
                                    </div>
                                </div>
                            </div>
                            
                            <div class="gallery-content" style="padding: 20px;">
                                <h3 class="gallery-title" style="
                                    margin: 0 0 10px 0;
                                    font-size: 18px;
                                    color: #1a1a2e;
                                    font-weight: 600;
                                ">
                                    <?php echo esc($item['title'] ?? 'Untitled'); ?>
                                </h3>
                                
                                <p class="gallery-description" style="
                                    color: #666;
                                    font-size: 14px;
                                    line-height: 1.5;
                                    margin-bottom: 15px;
                                ">
                                    <?php 
                                        $desc = $item['description'] ?? '';
                                        echo esc(substr($desc, 0, 100));
                                        if (strlen($desc) > 100) echo '...';
                                    ?>
                                </p>
                                
                                <div class="gallery-meta" style="
                                    display: flex;
                                    justify-content: space-between;
                                    color: #888;
                                    font-size: 13px;
                                ">
                                    <span style="display: flex; align-items: center; gap: 5px;">
                                        <i class="fas fa-user" style="color: #0084ff;"></i>
                                        <?php echo esc($item['username'] ?? 'Anonymous'); ?>
                                    </span>
                                    <span style="display: flex; align-items: center; gap: 5px;">
                                        <i class="fas fa-eye"></i>
                                        <?php echo intval($item['views'] ?? 0); ?>
                                    </span>
                                    <span style="display: flex; align-items: center; gap: 5px;">
                                        <i class="fas fa-heart" style="color: #ff4444;"></i>
                                        <?php echo intval($item['likes'] ?? 0); ?>
                                    </span>
                                </div>
                            </div>
                        </div>
                        
                    </a>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>

        <!-- Load More Button -->
        <?php if (count($gallery_items) >= 12): ?>
            <div style="text-align: center; margin-top: 50px;">
                <button id="loadMoreBtn" style="
                    padding: 14px 40px;
                    background: #5AB5D4;
                    color: white;
                    border: none;
                    border-radius: 8px;
                    font-size: 16px;
                    font-weight: 600;
                    cursor: pointer;
                    transition: all 0.3s ease;
                " onmouseover="this.style.transform='translateY(-2px)'" 
                   onmouseout="this.style.transform='translateY(0)'">
                    <i class="fas fa-redo"></i> Xem Thêm
                </button>
            </div>
        <?php endif; ?>
    </div>
</section>

<style>
/* CSS cho gallery */
.gallery-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
    gap: 30px;
}

.gallery-item {
    cursor: pointer;
}

.gallery-img-container {
    position: relative;
    overflow: hidden;
}

.gallery-hover-overlay {
    pointer-events: none; /* Cho phép click xuyên qua overlay */
}

/* Filter buttons */
.gallery-filters {
    display: flex;
    justify-content: center;
    flex-wrap: wrap;
    gap: 10px;
    margin-bottom: 30px;
}

.filter-btn {
    padding: 12px 24px;
    background: #f0f0f0;
    border: none;
    border-radius: 50px;
    cursor: pointer;
    font-weight: 500;
    transition: all 0.3s ease;
}

.filter-btn:hover {
    background: #e0e0e0;
}

.filter-btn.active {
    background: #0084ff;
    color: white;
}

/* Responsive */
@media (max-width: 768px) {
    .gallery-grid {
        grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
        gap: 20px;
    }
    
    .gallery-filters {
        gap: 8px;
    }
    
    .filter-btn {
        padding: 10px 18px;
        font-size: 14px;
    }
}
</style>

<script>
// Gallery filter functionality
document.addEventListener('DOMContentLoaded', function() {
    const filterBtns = document.querySelectorAll('.filter-btn');
    const galleryItems = document.querySelectorAll('.gallery-item');

    filterBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            const filter = this.getAttribute('data-filter');
            
            // Update active button
            filterBtns.forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            
            // Filter items
            galleryItems.forEach(item => {
                const category = item.getAttribute('data-category');
                if (filter === 'all' || category === filter) {
                    item.parentElement.style.display = 'block';
                    setTimeout(() => item.style.opacity = '1', 10);
                } else {
                    item.style.opacity = '0';
                    setTimeout(() => item.parentElement.style.display = 'none', 300);
                }
            });
        });
    });

    // Upload button
    const uploadBtn = document.getElementById('uploadBtnGallery');
    if (uploadBtn) {
        uploadBtn.addEventListener('click', function() {
            window.location.href = 'pages/upload.php';
        });
    }

    // Login button
    const loginBtn = document.getElementById('loginBtnGallery');
    if (loginBtn) {
        loginBtn.addEventListener('click', function() {
            window.location.href = 'pages/login.php';
        });
    }

    // Load more button
    const loadMoreBtn = document.getElementById('loadMoreBtn');
    if (loadMoreBtn) {
        loadMoreBtn.addEventListener('click', function() {
            alert('Tính năng xem thêm sẽ sớm được cập nhật!');
        });
    }
});
</script>