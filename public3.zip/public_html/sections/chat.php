<?php
// sections/chat.php - Community Chat Room
$userLoggedIn = !empty($_SESSION['user_id']) && is_numeric($_SESSION['user_id']);
$currentUser = $userLoggedIn ? getCurrentUser() : null;

// Get recent chat messages
try {
    $chatMessages = getAll("
        SELECT 
            c.id,
            c.user_id,
            c.message,
            c.created_at,
            u.username,
            u.avatar
        FROM chat_messages c
        LEFT JOIN users u ON c.user_id = u.id
        ORDER BY c.created_at DESC
        LIMIT 50
    ", []);
    $chatMessages = array_reverse($chatMessages ?? []);
} catch (Exception $e) {
    error_log('Chat query error: ' . $e->getMessage());
    $chatMessages = [];
}

// Count online users (users with messages in last 5 minutes or recent login)
try {
    $onlineCount = intval((getRow("
        SELECT COUNT(DISTINCT user_id) as count 
        FROM chat_messages 
        WHERE created_at > DATE_SUB(NOW(), INTERVAL 5 MINUTE)
    ", [])['count'] ?? 0));
} catch (Exception $e) {
    $onlineCount = 0;
}
?>

<section id="chat" class="section" style="background: linear-gradient(135deg, #E8F4F8 0%, #F0F5FF 100%);">
    <div class="container">
        <div style="text-align: center; margin-bottom: 40px;">
            <h2 class="section-title">💬 Cộng Đồng Chat</h2>
            <p class="section-subtitle">Kết nối & giao lưu với các thành viên cộng đồng ArtFolio</p>
        </div>

        <div class="chat-room-wrapper">
            <!-- Chat Sidebar -->
            <div class="chat-sidebar">
                <div class="chat-header-info">
                    <h3>Thành Viên Online</h3>
                    <span class="online-badge">
                        <span class="online-dot"></span>
                        <?php echo $onlineCount; ?> đang hoạt động
                    </span>
                </div>

                <div class="users-list">
                    <?php 
                        // Lấy danh sách users online (placeholder)
                        $onlineUsers = getAll("
                            SELECT id, username, avatar 
                            FROM users 
                            WHERE last_login > DATE_SUB(NOW(), INTERVAL 5 MINUTE)
                            LIMIT 20
                        ", []);
                    ?>
                    <?php if (empty($onlineUsers)): ?>
                        <p style="color: #999; font-size: 12px; padding: 10px;">Chưa có thành viên nào online</p>
                    <?php else: ?>
                        <?php foreach ($onlineUsers as $user): ?>
                            <div class="user-item">
                                <div class="user-avatar">
                                    <?php 
                                        if (!empty($user['avatar'])) {
                                            echo '<img src="' . esc(PROFILE_UPLOAD_URL . basename($user['avatar'])) . '" alt="' . esc($user['username']) . '">';
                                        } else {
                                            echo '<span>' . strtoupper(substr($user['username'], 0, 1)) . '</span>';
                                        }
                                    ?>
                                </div>
                                <div class="user-info">
                                    <p class="user-name"><?php echo esc($user['username']); ?></p>
                                    <span class="online-indicator">Online</span>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Chat Main -->
            <div class="chat-main">
                <!-- Chat Messages -->
                <div class="chat-messages-container" id="chatMessagesContainer">
                    <?php if (empty($chatMessages)): ?>
                        <div class="no-messages">
                            <i class="fas fa-comments"></i>
                            <p>Chưa có tin nhắn nào. Hãy là người đầu tiên bắt đầu cuộc trò chuyện!</p>
                        </div>
                    <?php else: ?>
                        <?php foreach ($chatMessages as $msg): ?>
                            <div class="chat-message-item <?php echo ($userLoggedIn && $msg['user_id'] == $_SESSION['user_id']) ? 'own' : ''; ?>">
                                <div class="message-avatar">
                                    <?php 
                                        if (!empty($msg['avatar'])) {
                                            echo '<img src="' . esc(PROFILE_UPLOAD_URL . basename($msg['avatar'])) . '" alt="' . esc($msg['username']) . '">';
                                        } else {
                                            echo '<span>' . strtoupper(substr($msg['username'] ?? 'A', 0, 1)) . '</span>';
                                        }
                                    ?>
                                </div>
                                <div class="message-bubble">
                                    <div class="message-header">
                                        <strong><?php echo esc($msg['username'] ?? 'Anonymous'); ?></strong>
                                        <span class="message-time"><?php echo get_time_ago($msg['created_at']); ?></span>
                                    </div>
                                    <p class="message-text"><?php echo esc($msg['message']); ?></p>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>

                <!-- Chat Input -->
                <div class="chat-input-section">
                    <?php if ($userLoggedIn): ?>
                        <form id="chatFormSubmit" class="chat-form-send">
                            <input 
                                type="text" 
                                id="chatMessageInput" 
                                name="message" 
                                placeholder="Nhập tin nhắn của bạn..."
                                class="chat-input-field"
                                maxlength="500"
                            >
                            <button type="submit" class="chat-send-btn">
                                <i class="fas fa-paper-plane"></i>
                            </button>
                        </form>
                        <p style="font-size: 11px; color: #999; text-align: center; margin-top: 8px;">
                            Hãy lịch sự và tôn trọng các thành viên khác
                        </p>
                    <?php else: ?>
                        <div class="login-prompt">
                            <i class="fas fa-lock"></i>
                            <p>Vui lòng <a href="#" onclick="showModal('login'); return false;" style="color: #5AB5D4; font-weight: 600;">đăng nhập</a> để tham gia trò chuyện</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</section>

<style>
.chat-room-wrapper {
    display: grid;
    grid-template-columns: 250px 1fr;
    gap: 20px;
    background: white;
    border-radius: 12px;
    overflow: hidden;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    height: 600px;
    margin-bottom: 40px;
}

.chat-sidebar {
    background: #f8f9fa;
    border-right: 1px solid #e0e0e0;
    display: flex;
    flex-direction: column;
    overflow-y: auto;
}

.chat-header-info {
    padding: 20px;
    border-bottom: 1px solid #e0e0e0;
    position: sticky;
    top: 0;
    background: white;
    z-index: 10;
}

.chat-header-info h3 {
    margin: 0 0 8px;
    font-size: 14px;
    color: #212121;
}

.online-badge {
    display: flex;
    align-items: center;
    gap: 6px;
    font-size: 12px;
    color: #4CAF50;
    font-weight: 600;
}

.online-dot {
    width: 8px;
    height: 8px;
    background: #4CAF50;
    border-radius: 50%;
    animation: blink 2s infinite;
}

@keyframes blink {
    0%, 100% { opacity: 1; }
    50% { opacity: 0.5; }
}

.users-list {
    flex: 1;
    overflow-y: auto;
    padding: 0;
}

.user-item {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 12px;
    border-bottom: 1px solid #e0e0e0;
    cursor: pointer;
    transition: background 0.3s ease;
}

.user-item:hover {
    background: white;
}

.user-avatar {
    width: 36px;
    height: 36px;
    border-radius: 50%;
    background: linear-gradient(135deg, #5AB5D4 0%, #3A7E9F 100%);
    color: white;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 600;
    overflow: hidden;
    flex-shrink: 0;
}

.user-avatar img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.user-info {
    flex: 1;
    min-width: 0;
}

.user-name {
    margin: 0;
    font-size: 13px;
    font-weight: 600;
    color: #212121;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.online-indicator {
    font-size: 11px;
    color: #4CAF50;
    font-weight: 600;
}

.chat-main {
    display: flex;
    flex-direction: column;
    overflow: hidden;
}

.chat-messages-container {
    flex: 1;
    overflow-y: auto;
    padding: 20px;
    display: flex;
    flex-direction: column;
    gap: 12px;
}

.no-messages {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    height: 100%;
    color: #999;
    text-align: center;
}

.no-messages i {
    font-size: 48px;
    margin-bottom: 16px;
    opacity: 0.3;
}

.no-messages p {
    max-width: 300px;
}

.chat-message-item {
    display: flex;
    gap: 10px;
    animation: messageSlideIn 0.3s ease;
}

.chat-message-item.own {
    flex-direction: row-reverse;
}

@keyframes messageSlideIn {
    from {
        opacity: 0;
        transform: translateY(10px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.message-bubble {
    max-width: 70%;
}

.message-header {
    display: flex;
    gap: 8px;
    align-items: baseline;
    margin-bottom: 4px;
}

.message-header strong {
    font-size: 13px;
    color: #212121;
}

.message-time {
    font-size: 11px;
    color: #999;
}

.message-text {
    margin: 0;
    padding: 10px 12px;
    background: #f5f5f5;
    border-radius: 8px;
    font-size: 14px;
    color: #333;
    word-break: break-word;
}

.chat-message-item.own .message-text {
    background: #5AB5D4;
    color: white;
}

.chat-input-section {
    padding: 16px;
    border-top: 1px solid #e0e0e0;
    background: white;
}

.chat-form-send {
    display: flex;
    gap: 8px;
}

.chat-input-field {
    flex: 1;
    padding: 10px 12px;
    border: 1px solid #ddd;
    border-radius: 6px;
    font-size: 14px;
    font-family: inherit;
    transition: all 0.3s ease;
}

.chat-input-field:focus {
    outline: none;
    border-color: #5AB5D4;
    box-shadow: 0 0 0 3px rgba(90, 181, 212, 0.1);
}

.chat-send-btn {
    width: 40px;
    height: 40px;
    background: #5AB5D4;
    color: white;
    border: none;
    border-radius: 6px;
    cursor: pointer;
    font-size: 14px;
    transition: all 0.3s ease;
    display: flex;
    align-items: center;
    justify-content: center;
}

.chat-send-btn:hover {
    background: #3A7E9F;
    transform: translateY(-1px);
}

.chat-send-btn:disabled {
    opacity: 0.5;
    cursor: not-allowed;
}

.login-prompt {
    text-align: center;
    padding: 20px;
    color: #999;
}

.login-prompt i {
    font-size: 32px;
    margin-bottom: 10px;
    opacity: 0.3;
}

.login-prompt p {
    margin: 0;
    font-size: 14px;
}

@media (max-width: 1024px) {
    .chat-room-wrapper {
        grid-template-columns: 200px 1fr;
    }

    .message-bubble {
        max-width: 80%;
    }
}

@media (max-width: 768px) {
    .chat-room-wrapper {
        grid-template-columns: 1fr;
        height: auto;
        min-height: 500px;
    }

    .chat-sidebar {
        display: none;
    }

    .message-bubble {
        max-width: 85%;
    }
}

@media (max-width: 480px) {
    .chat-room-wrapper {
        height: auto;
        min-height: 400px;
    }

    .chat-messages-container {
        padding: 12px;
    }

    .message-bubble {
        max-width: 90%;
    }
}
</style>

<script>
// Chat functionality
document.addEventListener('DOMContentLoaded', function() {
    const chatForm = document.getElementById('chatFormSubmit');
    const chatInput = document.getElementById('chatMessageInput');
    const messagesContainer = document.getElementById('chatMessagesContainer');
    
    if (chatForm) {
        chatForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const message = chatInput.value.trim();
            if (!message) return;
            
            const sendBtn = chatForm.querySelector('.chat-send-btn');
            sendBtn.disabled = true;
            
            // Send message via API
            fetch('api/chat.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    action: 'send',
                    message: message
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    chatInput.value = '';
                    // Reload messages
                    setTimeout(() => {
                        location.reload();
                    }, 500);
                } else {
                    alert(data.message || 'Lỗi khi gửi tin nhắn');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Lỗi kết nối');
            })
            .finally(() => {
                sendBtn.disabled = false;
            });
        });
        
        // Auto scroll to bottom
        if (messagesContainer) {
            messagesContainer.scrollTop = messagesContainer.scrollHeight;
        }
    }
});
</script>