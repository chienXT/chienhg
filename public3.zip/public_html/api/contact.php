<?php
// api/contact.php - CONTACT FORM HANDLER
error_reporting(E_ALL);
ini_set('display_errors', 0);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once '../includes/config.php';
require_once '../includes/functions.php';
require_once '../includes/database.php';

header('Content-Type: application/json; charset=utf-8');

// Only accept POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode([
        'success' => false,
        'message' => 'Method not allowed'
    ]);
    exit;
}

try {
    // Get data
    $name = sanitize($_POST['name'] ?? '');
    $email = sanitize($_POST['email'] ?? '');
    $subject = sanitize($_POST['subject'] ?? '');
    $category = sanitize($_POST['category'] ?? 'general');
    $message = sanitize($_POST['message'] ?? '');

    // Validate
    if (empty($name) || empty($email) || empty($subject) || empty($message)) {
        http_response_code(400);
        echo json_encode([
            'success' => false,
            'message' => 'Vui lòng điền đầy đủ thông tin'
        ]);
        exit;
    }

    // Validate email
    if (!validateEmail($email)) {
        http_response_code(400);
        echo json_encode([
            'success' => false,
            'message' => 'Email không hợp lệ'
        ]);
        exit;
    }

    // Validate message length
    if (strlen($message) < 20) {
        http_response_code(400);
        echo json_encode([
            'success' => false,
            'message' => 'Tin nhắn phải có ít nhất 20 ký tự'
        ]);
        exit;
    }

    // Check if table exists
    $tableExists = false;
    try {
        $result = getRow("SELECT 1 FROM contact_messages LIMIT 1");
        $tableExists = true;
    } catch (Exception $e) {
        error_log('Contact table check: ' . $e->getMessage());
    }

    // Insert into database if table exists
    if ($tableExists) {
        try {
            $insertId = insert('contact_messages', [
                'name' => $name,
                'email' => $email,
                'subject' => $subject,
                'category' => $category ?: 'general',
                'message' => $message,
                'status' => 'new',
                'created_at' => date('Y-m-d H:i:s')
            ]);

            if (!$insertId) {
                throw new Exception('Failed to insert contact message');
            }
        } catch (Exception $e) {
            error_log('Contact insert error: ' . $e->getMessage());
            // Continue anyway, just log the error
        }
    }

    // Try to send email
    $emailSent = false;
    try {
        $to = SITE_EMAIL;
        $subject_email = "Tin nhắn mới từ ArtFolio: " . $subject;
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type: text/html; charset=UTF-8" . "\r\n";
        $headers .= "From: " . $email . "\r\n";
        $headers .= "Reply-To: " . $email . "\r\n";

        $body = "<html><body>";
        $body .= "<h2>Tin nhắn mới từ " . htmlspecialchars($name) . "</h2>";
        $body .= "<p><strong>Email:</strong> " . htmlspecialchars($email) . "</p>";
        $body .= "<p><strong>Danh mục:</strong> " . htmlspecialchars($category) . "</p>";
        $body .= "<p><strong>Tiêu đề:</strong> " . htmlspecialchars($subject) . "</p>";
        $body .= "<hr>";
        $body .= "<p><strong>Tin nhắn:</strong></p>";
        $body .= "<p>" . nl2br(htmlspecialchars($message)) . "</p>";
        $body .= "<hr>";
        $body .= "<p><em>Gửi từ ArtFolio</em></p>";
        $body .= "</body></html>";

        if (mail($to, $subject_email, $body, $headers)) {
            $emailSent = true;
        }
    } catch (Exception $e) {
        error_log('Email send error: ' . $e->getMessage());
    }

    // Log activity
    try {
        logActivity('Contact form submitted', [
            'name' => $name,
            'email' => $email,
            'category' => $category
        ]);
    } catch (Exception $e) {
        error_log('Activity log error: ' . $e->getMessage());
    }

    // Response
    http_response_code(201);
    echo json_encode([
        'success' => true,
        'message' => 'Cảm ơn bạn đã liên hệ! Chúng tôi sẽ phản hồi sớm nhất có thể.'
    ]);

} catch (Exception $e) {
    error_log('Contact form error: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Có lỗi xảy ra. Vui lòng thử lại sau.'
    ]);
}

exit;
?>