<?php
// api/auth.php - PDO VERSION (SAFE MIGRATION)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Start session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// KHÔNG require config.php vì không dùng $conn
require_once '../includes/database.php'; // Sửa: dùng database.php thay config.php
require_once '../includes/functions.php'; // Để dùng validateEmail, hashPassword, etc

// Set headers
header('Content-Type: application/json');

// Get request data
$input = file_get_contents('php://input');
$data = json_decode($input, true);

// Debug log
error_log("Auth API called with action: " . ($data['action'] ?? 'none'));

// Default response
$response = [
    'success' => false,
    'message' => 'Invalid request'
];

// Handle different actions
$action = $data['action'] ?? $_GET['action'] ?? '';

switch ($action) {
    case 'login':
        $response = handleLogin($data);
        break;
        
    case 'register':
        $response = handleRegister($data);
        break;
        
    case 'logout':
        $response = handleLogout();
        break;
        
    case 'check_auth':
        $response = checkAuth();
        break;
        
    default:
        $response = [
            'success' => false,
            'message' => 'Action không hợp lệ'
        ];
}

echo json_encode($response, JSON_UNESCAPED_UNICODE);
exit;

// ==================== PDO FUNCTIONS ====================

function handleLogin($data) {
    $email = trim($data['email'] ?? '');
    $password = $data['password'] ?? '';
    $remember = ($data['remember'] ?? '0') === '1';
    
    // Validate input
    if (empty($email) || empty($password)) {
        return [
            'success' => false,
            'message' => 'Vui lòng nhập đầy đủ thông tin'
        ];
    }
    
    if (!validateEmail($email)) {
        return [
            'success' => false,
            'message' => 'Email không hợp lệ'
        ];
    }
    
    try {
        // Query user với PDO (dùng getRow từ database.php)
        $user = getRow("SELECT * FROM users WHERE email = ? AND status = 'active' LIMIT 1", [$email]);
        
        if (!$user) {
            error_log("User not found: " . $email);
            return [
                'success' => false,
                'message' => 'Email hoặc mật khẩu không đúng'
            ];
        }
        
        // Verify password
        if (!password_verify($password, $user['password'])) {
            error_log("Password verification failed for user: " . $email);
            return [
                'success' => false,
                'message' => 'Email hoặc mật khẩu không đúng'
            ];
        }
        
        // Login successful - Set session
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['email'] = $user['email'];
        $_SESSION['user_role'] = $user['role'];
        $_SESSION['avatar'] = $user['avatar'] ?? '';
        $_SESSION['login_time'] = time();
        
        // Update last login
        update('users', ['last_login' => date('Y-m-d H:i:s')], 'id = ?', [$user['id']]);
        
        // Set remember me cookie
        if ($remember) {
            $token = bin2hex(random_bytes(32));
            setcookie('remember_token', $token, time() + (86400 * 30), '/', '', false, true);
            
            // Save token to database
            update('users', ['remember_token' => $token], 'id = ?', [$user['id']]);
        }
        
        // Log for debugging
        error_log("Login successful - User ID: " . $user['id']);
        
        return [
            'success' => true,
            'message' => 'Đăng nhập thành công!',
            'data' => [
                'user' => [
                    'id' => $user['id'],
                    'username' => $user['username'],
                    'email' => $user['email'],
                    'role' => $user['role']
                ],
                'redirect' => 'index.php'
            ]
        ];
        
    } catch (Exception $e) {
        error_log("Login error: " . $e->getMessage());
        return [
            'success' => false,
            'message' => 'Lỗi hệ thống. Vui lòng thử lại sau.'
        ];
    }
}

function handleRegister($data) {
    $username = trim($data['username'] ?? '');
    $email = trim($data['email'] ?? '');
    $password = $data['password'] ?? '';
    $password_confirm = $data['password_confirm'] ?? '';
    
    // Validate input
    if (empty($username) || empty($email) || empty($password)) {
        return [
            'success' => false,
            'message' => 'Vui lòng nhập đầy đủ thông tin'
        ];
    }
    
    if (!validateUsername($username)) {
        return [
            'success' => false,
            'message' => 'Tên người dùng không hợp lệ. Phải từ 3-50 ký tự, chỉ chứa chữ cái, số, gạch dưới và gạch ngang'
        ];
    }
    
    if (!validateEmail($email)) {
        return [
            'success' => false,
            'message' => 'Email không hợp lệ'
        ];
    }
    
    if (!validatePassword($password)) {
        return [
            'success' => false,
            'message' => 'Mật khẩu phải có ít nhất 6 ký tự'
        ];
    }
    
    if ($password !== $password_confirm) {
        return [
            'success' => false,
            'message' => 'Mật khẩu xác nhận không khớp'
        ];
    }
    
    try {
        // Check if email exists
        $existingEmail = getRow("SELECT id FROM users WHERE email = ? LIMIT 1", [$email]);
        if ($existingEmail) {
            return [
                'success' => false,
                'message' => 'Email đã được sử dụng'
            ];
        }
        
        // Check if username exists
        $existingUser = getRow("SELECT id FROM users WHERE username = ? LIMIT 1", [$username]);
        if ($existingUser) {
            return [
                'success' => false,
                'message' => 'Tên người dùng đã được sử dụng'
            ];
        }
        
        // Hash password
        $hashed_password = hashPassword($password);
        
        // Insert user
        $userId = insert('users', [
            'username' => $username,
            'email' => $email,
            'password' => $hashed_password,
            'role' => 'user',
            'status' => 'active',
            'created_at' => date('Y-m-d H:i:s')
        ]);
        
        if ($userId) {
            error_log("User registered successfully: " . $email . " - ID: " . $userId);
            
            return [
                'success' => true,
                'message' => 'Đăng ký thành công! Vui lòng đăng nhập.'
            ];
        } else {
            return [
                'success' => false,
                'message' => 'Lỗi khi đăng ký. Vui lòng thử lại.'
            ];
        }
        
    } catch (Exception $e) {
        error_log("Registration error: " . $e->getMessage());
        return [
            'success' => false,
            'message' => 'Lỗi hệ thống. Vui lòng thử lại sau.'
        ];
    }
}

function handleLogout() {
    $userId = $_SESSION['user_id'] ?? null;
    
    // Clear session
    $_SESSION = array();
    
    // Destroy session cookie
    if (isset($_COOKIE[session_name()])) {
        setcookie(session_name(), '', time() - 3600, '/');
    }
    
    // Clear remember token cookie
    if (isset($_COOKIE['remember_token'])) {
        setcookie('remember_token', '', time() - 3600, '/');
    }
    
    // Destroy session
    if (session_status() === PHP_SESSION_ACTIVE) {
        session_destroy();
    }
    
    error_log("User logged out - User ID: " . $userId);
    
    return [
        'success' => true,
        'message' => 'Đã đăng xuất thành công',
        'data' => [
            'redirect' => 'index.php'
        ]
    ];
}

function checkAuth() {
    if (isset($_SESSION['user_id']) && $_SESSION['user_id'] > 0) {
        try {
            // Get fresh user data from database
            $user = getRow("SELECT id, username, email, role, avatar FROM users WHERE id = ?", [$_SESSION['user_id']]);
            
            if ($user) {
                return [
                    'success' => true,
                    'data' => [
                        'user' => [
                            'id' => $user['id'],
                            'username' => $user['username'],
                            'email' => $user['email'],
                            'role' => $user['role'],
                            'avatar' => !empty($user['avatar']) ? UPLOAD_URL . 'profile/' . basename($user['avatar']) : null
                        ]
                    ]
                ];
            } else {
                // User not found in database, clear session
                session_destroy();
            }
        } catch (Exception $e) {
            error_log("checkAuth error: " . $e->getMessage());
        }
    }
    
    return [
        'success' => false,
        'message' => 'Not authenticated'
    ];
}