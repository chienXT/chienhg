<?php
// api/like.php - Like/Unlike Handler
header('Content-Type: application/json');
require_once dirname(__DIR__) . '/includes/config.php';

// Check login
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Vui lòng đăng nhập']);
    exit;
}

$user_id = $_SESSION['user_id'];

// Get JSON input
$input = json_decode(file_get_contents('php://input'), true);
$image_id = isset($input['image_id']) ? intval($input['image_id']) : 0;

if ($image_id <= 0) {
    echo json_encode(['success' => false, 'message' => 'ID không hợp lệ']);
    exit;
}

try {
    // Check if image exists
    $image = getRow("SELECT id, likes FROM artworks WHERE id = ? AND is_public = 1", [$image_id]);
    
    if (!$image) {
        echo json_encode(['success' => false, 'message' => 'Không tìm thấy ảnh']);
        exit;
    }
    
    // Check if already liked
    $existingLike = getRow("SELECT id FROM likes WHERE user_id = ? AND image_id = ?", [$user_id, $image_id]);
    
    if ($existingLike) {
        // Unlike
        delete('likes', 'id = ?', [$existingLike['id']]);
        executeQuery("UPDATE artworks SET likes = GREATEST(0, likes - 1) WHERE id = ?", [$image_id]);
        
        echo json_encode([
            'success' => true,
            'action' => 'unliked',
            'message' => 'Đã bỏ thích'
        ]);
    } else {
        // Like
        insert('likes', [
            'user_id' => $user_id,
            'image_id' => $image_id,
            'created_at' => date('Y-m-d H:i:s')
        ]);
        executeQuery("UPDATE artworks SET likes = likes + 1 WHERE id = ?", [$image_id]);
        
        echo json_encode([
            'success' => true,
            'action' => 'liked',
            'message' => 'Đã thích'
        ]);
    }
    
} catch (Exception $e) {
    error_log('Like error: ' . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Có lỗi xảy ra']);
}
?>