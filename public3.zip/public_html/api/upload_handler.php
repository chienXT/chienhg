<?php
// api/upload.php - Upload Handler
header('Content-Type: application/json');
require_once dirname(__DIR__) . '/includes/config.php';

// Check login
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Vui lòng đăng nhập']);
    exit;
}

$user_id = $_SESSION['user_id'];

// Check if file was uploaded
if (!isset($_FILES['image']) || $_FILES['image']['error'] !== UPLOAD_ERR_OK) {
    $error_msg = 'Không có file hoặc có lỗi upload';
    if (isset($_FILES['image']['error'])) {
        switch ($_FILES['image']['error']) {
            case UPLOAD_ERR_INI_SIZE:
            case UPLOAD_ERR_FORM_SIZE:
                $error_msg = 'File quá lớn';
                break;
            case UPLOAD_ERR_PARTIAL:
                $error_msg = 'File upload không hoàn chỉnh';
                break;
            case UPLOAD_ERR_NO_FILE:
                $error_msg = 'Không có file nào được chọn';
                break;
        }
    }
    echo json_encode(['success' => false, 'message' => $error_msg]);
    exit;
}

// Get form data
$title = isset($_POST['title']) ? trim($_POST['title']) : '';
$description = isset($_POST['description']) ? trim($_POST['description']) : '';
$category = isset($_POST['category']) ? trim($_POST['category']) : '';
$tags = isset($_POST['tags']) ? trim($_POST['tags']) : '';
$is_public = isset($_POST['is_public']) ? 1 : 0;

// Validate
$errors = [];

if (empty($title) || strlen($title) < 5) {
    $errors[] = 'Tiêu đề phải có ít nhất 5 ký tự';
}

if (strlen($title) > 200) {
    $errors[] = 'Tiêu đề quá dài (tối đa 200 ký tự)';
}

if (empty($category)) {
    $errors[] = 'Vui lòng chọn danh mục';
}

$allowed_categories = ['painting', 'digital', 'photography', 'sculpture', 'illustration', '3d', 'other'];
if (!in_array($category, $allowed_categories)) {
    $errors[] = 'Danh mục không hợp lệ';
}

if (strlen($description) > 1000) {
    $errors[] = 'Mô tả quá dài (tối đa 1000 ký tự)';
}

if (strlen($tags) > 200) {
    $errors[] = 'Tags quá dài (tối đa 200 ký tự)';
}

if (!empty($errors)) {
    echo json_encode(['success' => false, 'message' => implode(', ', $errors)]);
    exit;
}

// Validate file
$file = $_FILES['image'];
$file_size = $file['size'];
$file_tmp = $file['tmp_name'];
$file_name = $file['name'];
$file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));

// Check extension
if (!in_array($file_ext, ALLOWED_EXTENSIONS)) {
    echo json_encode(['success' => false, 'message' => 'Định dạng file không hợp lệ. Chỉ chấp nhận: ' . implode(', ', ALLOWED_EXTENSIONS)]);
    exit;
}

// Check size
if ($file_size > MAX_FILE_SIZE) {
    echo json_encode(['success' => false, 'message' => 'File quá lớn. Tối đa ' . round(MAX_FILE_SIZE / 1048576, 1) . 'MB']);
    exit;
}

// Check if it's really an image
$check = @getimagesize($file_tmp);
if ($check === false) {
    echo json_encode(['success' => false, 'message' => 'File không phải là ảnh hợp lệ']);
    exit;
}

// Check MIME type
$allowed_types = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp'];
if (!in_array($check['mime'], $allowed_types)) {
    echo json_encode(['success' => false, 'message' => 'Loại ảnh không được hỗ trợ']);
    exit;
}

try {
    // Create upload directory if not exists
    if (!file_exists(GALLERY_UPLOAD_DIR)) {
        mkdir(GALLERY_UPLOAD_DIR, 0755, true);
    }

    // Generate unique filename
    $new_filename = uniqid('img_', true) . '_' . time() . '.' . $file_ext;
    $upload_path = GALLERY_UPLOAD_DIR . $new_filename;

    // Move uploaded file
    if (!move_uploaded_file($file_tmp, $upload_path)) {
        echo json_encode(['success' => false, 'message' => 'Không thể lưu file']);
        exit;
    }

    // Set file permissions
    @chmod($upload_path, 0644);

    // Insert into database
    $image_id = insert('artworks', [
        'user_id' => $user_id,
        'title' => $title,
        'description' => $description,
        'category' => $category,
        'tags' => $tags,
        'image_path' => $new_filename,
        'is_public' => $is_public,
        'views' => 0,
        'likes' => 0,
        'comments_count' => 0,
        'created_at' => date('Y-m-d H:i:s'),
        'updated_at' => date('Y-m-d H:i:s')
    ]);

    if ($image_id) {
        // Create thumbnail (optional, for optimization)
        createThumbnail($upload_path, $file_ext);

        echo json_encode([
            'success' => true,
            'message' => 'Tải lên thành công!',
            'image_id' => $image_id,
            'filename' => $new_filename
        ]);
    } else {
        // Delete file if database insert failed
        @unlink($upload_path);
        echo json_encode(['success' => false, 'message' => 'Không thể lưu vào database']);
    }

} catch (Exception $e) {
    // Clean up file if exists
    if (isset($upload_path) && file_exists($upload_path)) {
        @unlink($upload_path);
    }
    
    error_log('Upload error: ' . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Có lỗi xảy ra khi tải lên']);
}

/**
 * Create thumbnail (optional optimization)
 */
function createThumbnail($source, $ext) {
    try {
        $thumb_dir = GALLERY_UPLOAD_DIR . 'thumbs/';
        if (!file_exists($thumb_dir)) {
            mkdir($thumb_dir, 0755, true);
        }

        $thumb_path = $thumb_dir . basename($source);
        $thumb_width = 400;
        $thumb_height = 400;

        // Get original dimensions
        list($orig_width, $orig_height) = @getimagesize($source);
        
        if (!$orig_width || !$orig_height) {
            return false;
        }

        // Calculate aspect ratio
        $ratio = min($thumb_width / $orig_width, $thumb_height / $orig_height);
        $new_width = round($orig_width * $ratio);
        $new_height = round($orig_height * $ratio);

        // Create image resource based on extension
        switch ($ext) {
            case 'jpg':
            case 'jpeg':
                $src_img = @imagecreatefromjpeg($source);
                break;
            case 'png':
                $src_img = @imagecreatefrompng($source);
                break;
            case 'gif':
                $src_img = @imagecreatefromgif($source);
                break;
            case 'webp':
                $src_img = @imagecreatefromwebp($source);
                break;
            default:
                return false;
        }

        if (!$src_img) {
            return false;
        }

        // Create thumbnail
        $thumb_img = imagecreatetruecolor($new_width, $new_height);
        
        // Preserve transparency for PNG and GIF
        if ($ext == 'png' || $ext == 'gif') {
            imagealphablending($thumb_img, false);
            imagesavealpha($thumb_img, true);
            $transparent = imagecolorallocatealpha($thumb_img, 255, 255, 255, 127);
            imagefilledrectangle($thumb_img, 0, 0, $new_width, $new_height, $transparent);
        }

        // Resample
        imagecopyresampled($thumb_img, $src_img, 0, 0, 0, 0, $new_width, $new_height, $orig_width, $orig_height);

        // Save thumbnail
        switch ($ext) {
            case 'jpg':
            case 'jpeg':
                imagejpeg($thumb_img, $thumb_path, 85);
                break;
            case 'png':
                imagepng($thumb_img, $thumb_path, 8);
                break;
            case 'gif':
                imagegif($thumb_img, $thumb_path);
                break;
            case 'webp':
                imagewebp($thumb_img, $thumb_path, 85);
                break;
        }

        // Free memory
        imagedestroy($src_img);
        imagedestroy($thumb_img);

        return true;
    } catch (Exception $e) {
        error_log('Thumbnail creation error: ' . $e->getMessage());
        return false;
    }
}
?>