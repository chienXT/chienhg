<?php
// api/gallery.php - OPTIMIZED PDO VERSION
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Require database and functions
require_once '../includes/database.php'; // Sửa: dùng database.php
require_once '../includes/functions.php'; // Để dùng get_all_gallery_items từ functions.php

header('Content-Type: application/json; charset=utf-8');

// CORS headers
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Access-Control-Allow-Credentials: true");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

try {
    $action = $_GET['action'] ?? 'get_all';
    $category = $_GET['category'] ?? 'all';
    $user_id = $_GET['user_id'] ?? null;
    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
    $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 12;
    
    switch ($action) {
        case 'get_all':
            // Sử dụng hàm từ functions.php
            $items = get_all_gallery_items(
                $category !== 'all' ? $category : null, 
                $user_id, 
                $limit
            );
            break;
            
        case 'get_paginated':
            // Paginated version
            $result = getPaginatedSimple(
                'artworks',
                "is_public = 1" . ($category !== 'all' ? " AND category = ?" : ""),
                $category !== 'all' ? [$category] : [],
                $page,
                $limit,
                'created_at DESC'
            );
            
            $items = $result['data'];
            $pagination = [
                'total' => $result['total'],
                'page' => $result['page'],
                'per_page' => $result['per_page'],
                'total_pages' => $result['total_pages']
            ];
            break;
            
        default:
            throw new Exception('Action không hợp lệ');
    }
    
    // Format data for frontend
    $formatted_items = [];
    foreach ($items as $item) {
        $formatted_items[] = [
            'id' => $item['id'] ?? 0,
            'title' => $item['title'] ?? 'Không có tiêu đề',
            'description' => $item['description'] ?? '',
            'category' => $item['category'] ?? 'other',
            'category_name' => getCategoryName($item['category'] ?? 'other'),
            'category_icon' => getCategoryIcon($item['category'] ?? 'other'),
            'image_url' => !empty($item['image_path']) 
                ? UPLOAD_URL . 'gallery/' . basename($item['image_path']) 
                : ($item['image_url'] ?? ''),
            'image_path' => $item['image_path'] ?? '',
            'views' => $item['views'] ?? 0,
            'likes' => $item['likes'] ?? 0,
            'comments' => $item['comments'] ?? 0,
            'downloads' => $item['downloads'] ?? 0,
            'user_id' => $item['user_id'] ?? 0,
            'username' => $item['username'] ?? 'Ẩn danh',
            'avatar' => !empty($item['avatar']) ? UPLOAD_URL . 'profile/' . basename($item['avatar']) : '',
            'created_at' => $item['created_at'] ?? date('Y-m-d H:i:s'),
            'time_ago' => get_time_ago($item['created_at'] ?? ''),
            'is_public' => $item['is_public'] ?? 1,
            'tags' => !empty($item['tags']) ? explode(',', $item['tags']) : []
        ];
    }
    
    $response = [
        'success' => true,
        'message' => 'Gallery loaded successfully',
        'data' => $formatted_items,
        'count' => count($formatted_items)
    ];
    
    if (isset($pagination)) {
        $response['pagination'] = $pagination;
    }
    
    echo json_encode($response, JSON_UNESCAPED_UNICODE);
    
} catch (Exception $e) {
    http_response_code(500);
    error_log('Gallery API Error: ' . $e->getMessage());
    
    echo json_encode([
        'success' => false,
        'message' => 'Không thể tải gallery',
        'error' => ini_get('display_errors') ? $e->getMessage() : null,
        'data' => [],
        'count' => 0
    ], JSON_UNESCAPED_UNICODE);
}
?>